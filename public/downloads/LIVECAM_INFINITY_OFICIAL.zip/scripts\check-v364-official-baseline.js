/**
 * check-v364-official-baseline.js
 * Script de Auditoria Somente Leitura para a Baseline LiveCam Infinity v3.6.4 Official
 * Valora Negócios - Todos os direitos reservados.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const BASELINE_FILE = path.join(__dirname, '..', 'LIVECAM_V364_OFFICIAL_BASELINE.json');
const TARGET_DIR = path.join(__dirname, '..');

console.log('================================================================');
console.log('AUDITORIA DE INTEGRIDADE DA BASELINE — LIVECAM INFINITY v3.6.4');
console.log('================================================================\n');

if (!fs.existsSync(BASELINE_FILE)) {
  console.error('[ERRO] Arquivo de baseline não encontrado:', BASELINE_FILE);
  process.exit(1);
}

const baselineData = JSON.parse(fs.readFileSync(BASELINE_FILE, 'utf8'));
let totalFiles = 0;
let validFiles = 0;
let divergenceCount = 0;

for (const item of baselineData.files) {
  totalFiles++;
  const filePath = path.join(TARGET_DIR, item.relPath);
  
  if (!fs.existsSync(filePath)) {
    console.error(`[DIVERGÊNCIA - ARQUIVO AUSENTE] ${item.relPath}`);
    divergenceCount++;
    continue;
  }

  const buffer = fs.readFileSync(filePath);
  const currentSize = buffer.length;
  const currentHash = crypto.createHash('sha256').update(buffer).digest('hex');

  let itemHasError = false;

  if (currentSize !== item.size) {
    console.error(`[DIVERGÊNCIA - TAMANHO ALTERADO] ${item.relPath}: Esperado ${item.size} bytes | Encontrado ${currentSize} bytes`);
    itemHasError = true;
  }

  if (currentHash !== item.sha256) {
    console.error(`[DIVERGÊNCIA - HASH SHA256 INTEGRIDADE] ${item.relPath}`);
    console.error(`  - Esperado : ${item.sha256}`);
    console.error(`  - Encontrado: ${currentHash}`);
    itemHasError = true;
  }

  if (itemHasError) {
    divergenceCount++;
  } else {
    validFiles++;
    console.log(`[OK] ${item.relPath} (Tamanho: ${currentSize} B, Hash: ${currentHash.substring(0, 8)}...)`);
  }
}

console.log('\n----------------------------------------------------------------');
console.log(`RESUMO DA AUDITORIA: ${validFiles}/${totalFiles} arquivos íntegros.`);
if (divergenceCount > 0) {
  console.log(`[ATENÇÃO] Foram encontradas ${divergenceCount} divergências na baseline!`);
} else {
  console.log('[SUCESSO] Baseline 100% integra. Nenhuma alteração detectada.');
}
console.log('================================================================');
