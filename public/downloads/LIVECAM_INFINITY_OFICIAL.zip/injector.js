// LiveCam Infinity — v3.5.1 (Design System LiveCam Infinity - Vermelho + Dourado Premium)
// Motor Real de Fatiamento e Embaralhamento de Trechos de Áudio em Tempo Real (Slice Shuffler Engine)

(function () {
  'use strict';

  if (window.__livecamInstalada) return;
  window.__livecamInstalada = true;

  let VERSAO = '3.5.1';
  let ASSINATURA = { email: '', key: '', exp: 0 };

  // ---------- Native Code Masking (Bypass de Anti-Tamper RTC_AMBULANCE) ----------
  const origToString = Function.prototype.toString;
  const nativeMap = new WeakMap();

  function maskNative(fn, originalFn) {
    const nativeStr = originalFn
      ? origToString.call(originalFn)
      : `function ${fn.name || ''}() { [native code] }`;
    nativeMap.set(fn, nativeStr);
    try {
      if (originalFn && originalFn.name) {
        Object.defineProperty(fn, 'name', { value: originalFn.name, configurable: true });
      }
    } catch (e) {}
    return fn;
  }

  Function.prototype.toString = maskNative(function toString() {
    if (nativeMap.has(this)) {
      return nativeMap.get(this);
    }
    return origToString.apply(this, arguments);
  }, origToString);

  // ---------- Ícones SVG ----------
  const IC = {
    gear:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
    power:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>',
    min:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" width="16" height="16"><line x1="5" y1="12" x2="19" y2="12"/></svg>',
    back:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>',
    play:'<svg viewBox="0 0 24 24" fill="currentColor" width="15" height="15"><path d="M8 5v14l11-7z"/></svg>',
    pause:'<svg viewBox="0 0 24 24" fill="currentColor" width="15" height="15"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>',
    restart:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>',
    volOn:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>',
    volOff:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>',
    plus:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
    sync:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>',
    micOn:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0"/><line x1="12" y1="19" x2="12" y2="22"/></svg>',
    micOff:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><line x1="2" y1="2" x2="22" y2="22"/><path d="M9 9v3a3 3 0 0 0 5.94-.6"/><path d="M17 16.95A7 7 0 0 1 5 12"/><line x1="12" y1="19" x2="12" y2="22"/></svg>',
    fx:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>',
    infinito:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><path d="M18.178 8c5.096 0 5.096 8 0 8-5.095 0-7.133-8-12.739-8-4.585 0-4.585 8 0 8 5.606 0 7.644-8 12.74-8z"/></svg>',
    image:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
    type:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/></svg>',
    speed:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
    tools:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>',
    download:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    mute:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><path d="M11 5L6 9H2v6h4l5 4V5z"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>',
    shuffle:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/><line x1="4" y1="4" x2="9" y2="9"/></svg>'
  };

  // ---------- Estado ----------
  let videoEl = null;
  let playlist = [];
  let idxAtual = -1;
  let watchdog = null, ultimoTempo = -1;
  let wakeLock = null;
  let ativo = false;
  let autoSync = true, syncIntervalS = 60, syncTimer = null;
  let velocidadeRate = 1.0; try { velocidadeRate = parseFloat(localStorage.getItem('lc-speed') || '1.0'); } catch (e) {}
  let loopInfinito = true; try { loopInfinito = (localStorage.getItem('lc-loop') || '1') === '1'; } catch (e) {}
  try { autoSync = (localStorage.getItem('lc-autosync2') || '1') === '1'; } catch (e) {}
  try { syncIntervalS = parseInt(localStorage.getItem('lc-syncint') || '60', 10); } catch (e) {}

  // ---------- Detecção de Hardware e Modo Leve (ECO PRO) ----------
  let isLowEndPC = false;
  try {
    const cores = navigator.hardwareConcurrency || 4;
    const mem = navigator.deviceMemory || 4;
    if (cores <= 4 || mem <= 4) isLowEndPC = true;
  } catch (e) {}
  // ---------- Perfis de Qualidade de Vídeo (Leve, Equilibrado, Alta) ----------
  const PERFIS_QUALIDADE = {
    leve: {
      id: 'leve',
      nome: 'Leve',
      label: 'Leve — 540p / 20 FPS',
      width: 540,
      height: 960,
      fps: 20
    },
    equilibrado: {
      id: 'equilibrado',
      nome: 'Equilibrado',
      label: 'Equilibrado — 720p / 24 FPS',
      width: 720,
      height: 1280,
      fps: 24
    },
    alta: {
      id: 'alta',
      nome: 'Alta',
      label: 'Alta — 1080p / 30 FPS',
      width: 1080,
      height: 1920,
      fps: 30
    }
  };

  let qualidadeAtual = 'equilibrado';
  let modoLeve = (qualidadeAtual === 'leve');
  try {
    const savedQual = localStorage.getItem('lc-qualidade');
    if (savedQual && PERFIS_QUALIDADE[savedQual]) {
      qualidadeAtual = savedQual;
    } else {
      const oldML = localStorage.getItem('lc-modoleve');
      if (oldML !== null) {
        qualidadeAtual = oldML === '1' ? 'leve' : 'equilibrado';
        localStorage.setItem('lc-qualidade', qualidadeAtual);
      } else {
        localStorage.setItem('lc-qualidade', 'equilibrado');
      }
    }
  } catch (e) {
    qualidadeAtual = 'equilibrado';
  }

  const INFO_QUALIDADE = {
    leve: {
      nome: 'LEVE',
      resolucao: '540p / 20 FPS',
      selo: 'Maior desempenho',
      descricao: 'Recomendado para computadores com 4 GB de RAM ou configurações básicas.',
      statusVideo: '⚡ Modo Leve — maior desempenho',
      cor: '#00e676',
      bgStatus: 'rgba(0,230,118,.12)',
      borderStatus: 'rgba(0,230,118,.3)',
      bgTag: 'rgba(0,230,118,.15)',
      borderTag: 'rgba(0,230,118,.3)'
    },
    equilibrado: {
      nome: 'EQUILIBRADO',
      resolucao: '720p / 24 FPS',
      selo: 'Padrão recomendado',
      descricao: 'Melhor equilíbrio entre qualidade e desempenho. Recomendado para a maioria dos computadores.',
      statusVideo: '⚖️ Modo Equilibrado — qualidade e desempenho',
      cor: '#ffcc00',
      bgStatus: 'rgba(255,204,0,.12)',
      borderStatus: 'rgba(255,204,0,.3)',
      bgTag: 'rgba(255,204,0,.15)',
      borderTag: 'rgba(255,204,0,.3)'
    },
    alta: {
      nome: 'ALTA',
      resolucao: '1080p / 30 FPS',
      selo: 'Máxima qualidade',
      descricao: 'Recomendado para computadores com placa de vídeo dedicada e 8 GB ou mais de RAM.',
      statusVideo: '🚀 Modo Alta Qualidade — 1080p / 30 FPS',
      cor: '#ff4b2b',
      bgStatus: 'rgba(255,75,43,.12)',
      borderStatus: 'rgba(255,75,43,.3)',
      bgTag: 'rgba(255,75,43,.15)',
      borderTag: 'rgba(255,75,43,.3)'
    }
  };

  let atualizarTodosIndicadoresQualidade = function() {
    const inf = INFO_QUALIDADE[qualidadeAtual] || INFO_QUALIDADE.equilibrado;

    const selQual = $('cv-qualidade-sel');
    if (selQual) {
      selQual.value = qualidadeAtual;
      selQual.disabled = ativo;
      if (ativo) {
        selQual.title = '🔒 Qualidade bloqueada durante a transmissão. Encerre a transmissão para alterar.';
      } else {
        selQual.title = 'Selecione o perfil de qualidade';
      }
    }

    // Sincroniza os 3 Cards de Perfil no padrão Master Template
    ['leve', 'equilibrado', 'alta'].forEach(key => {
      const card = $('cv-prof-card-' + key);
      const radio = $('cv-prof-radio-' + key);
      const dot = $('cv-prof-dot-' + key);
      const badge = $('cv-prof-badge-' + key);
      const isSelected = (qualidadeAtual === key);

      if (card) {
        card.style.background = isSelected ? '#181820' : '#14141A';
        card.style.borderColor = isSelected ? '#D4AF37' : 'rgba(212,175,55,0.15)';
        card.style.boxShadow = isSelected ? '0 4px 14px rgba(212,175,55,0.25)' : 'none';
        card.style.opacity = (ativo && !isSelected) ? '0.5' : '1';
      }
      if (radio) {
        radio.style.borderColor = isSelected ? '#D4AF37' : '#A0A0B0';
      }
      if (dot) {
        dot.style.background = isSelected ? '#D4AF37' : 'transparent';
      }
      if (badge) {
        badge.style.display = isSelected ? 'inline-block' : 'none';
        badge.textContent = ativo ? '🔒 ATIVO' : 'ATIVO';
      }
    });

    const licQual = $('cv-lic-qual-val');
    if (licQual) {
      licQual.textContent = inf.nome + (ativo ? ' (Fixa)' : '');
      licQual.style.color = '#D4AF37';
    }

    const ecoPill = $('cv-eco-status');
    if (ecoPill) {
      ecoPill.style.display = 'flex';
      ecoPill.textContent = inf.statusVideo + (ativo ? ' [LOCK]' : '');
      ecoPill.style.color = inf.cor;
      ecoPill.style.background = inf.bgStatus;
      ecoPill.style.borderColor = inf.borderStatus;
    }
  };

  let atualizarQualidadeUI = function() {
    atualizarTodosIndicadoresQualidade();
  };

  function obterPerfilQualidade() {
    return PERFIS_QUALIDADE[qualidadeAtual] || PERFIS_QUALIDADE.equilibrado;
  }

  async function aplicarQualidadeAoVivo(novaQual) {
    if (ativo) {
      atualizarQualidadeUI();
      status('⚠️ Para alterar a qualidade, encerre a transmissão e inicie novamente.');
      return;
    }

    if (!PERFIS_QUALIDADE[novaQual] || novaQual === qualidadeAtual) return;

    qualidadeAtual = novaQual;
    try { localStorage.setItem('lc-qualidade', qualidadeAtual); } catch (e) {}
    atualizarQualidadeUI();
    status('⚡ Qualidade ajustada para ' + (INFO_QUALIDADE[qualidadeAtual] ? INFO_QUALIDADE[qualidadeAtual].nome : qualidadeAtual));
  }

  function mudarQualidadeTransmissao(novaQual) {
    aplicarQualidadeAoVivo(novaQual);
  }

  const handedStreams = new Set();
  const nossasTracks = new WeakSet();

  const origGUM = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
  const origEnum = navigator.mediaDevices.enumerateDevices.bind(navigator.mediaDevices);

  const FAKE_VIDEO_ID = 'a7c3f9e21b8d4a6c9e5f1d3b7a2c8e4f6d9b1a3c5e7f2d4b6a8c1e3f5d7b9a2c';
  const FAKE_AUDIO_ID = 'b2e8d4a6c1f7b3e9d5a1c7f3b9e5d2a8c4f1b7e3d9a5c2f8b4e1d7a3c9f5b2e8';
  const FAKE_GROUP_ID = 'c9f5b1e7d3a8c4f2b6e9d1a7c3f8b5e2d9a4c1f7b3e8d5a2c9f4b1e6d3a7c5f9';
  const FAKE_VIDEO_LABEL = 'LiveCam Infinity HD (1080p)';
  const FAKE_AUDIO_LABEL = 'Microfone Virtual (LiveCam Infinity)';

  // ---------- Canvas Compositor 1080x1920 (1:1 Exact Aspect Replica Engine) ----------
  const compCanvas = document.createElement('canvas');
  compCanvas.width = 1080;
  compCanvas.height = 1920;
  const compCtx = compCanvas.getContext('2d');
  let compStream = null;
  let compAnimFrame = null;

  // Lista de Overlays (Textos e Imagens)
  let overlays = [];
  let selectedOverlayId = null;

  function temOverlaysAtivos() {
    return overlays && overlays.some(o => o.visible);
  }

  let lastFrameTime = 0;
  function renderCompositor(now) {
    try {
      if (now && lastFrameTime && (now - lastFrameTime < 28)) {
        return;
      }
      lastFrameTime = now || 0;

      compCtx.fillStyle = '#000000';
      compCtx.fillRect(0, 0, 1080, 1920);

      if (videoEl && videoEl.readyState >= 2) {
        try {
          compCtx.drawImage(videoEl, 0, 0, 1080, 1920);
        } catch (e) {}
      }

      if (temOverlaysAtivos()) {
        for (const ov of overlays) {
          if (!ov.visible) continue;
          try {
            const x = ov.x * 1080;
            const y = ov.y * 1920;
            const w = ov.w * 1080;
            const h = ov.h * 1920;

            if (ov.type === 'image' && ov.imgEl && ov.imgEl.complete && ov.imgEl.naturalWidth) {
              const imgW = ov.imgEl.naturalWidth;
              const imgH = ov.imgEl.naturalHeight;
              const imgRatio = imgW / imgH;
              const boxRatio = w / h;
              let drawW = w, drawH = h, drawX = x, drawY = y;

              if (imgRatio > boxRatio) {
                drawH = w / imgRatio;
                drawY = y + (h - drawH) / 2;
              } else {
                drawW = h * imgRatio;
                drawX = x + (w - drawW) / 2;
              }
              compCtx.drawImage(ov.imgEl, drawX, drawY, drawW, drawH);
            } else if (ov.type === 'text' && ov.text) {
              compCtx.save();
              if (ov.hasBg && ov.bgColor) {
                compCtx.fillStyle = ov.bgColor;
                compCtx.fillRect(x, y, w, h);
              }

              const fontSizePx = Math.max(20, Math.round((ov.fontSize || 36) * 1.92));
              compCtx.font = `bold ${fontSizePx}px 'Outfit', 'Inter', sans-serif`;
              compCtx.fillStyle = ov.fontColor || '#ffffff';
              compCtx.textAlign = 'center';
              compCtx.textBaseline = 'middle';

              compCtx.fillText(ov.text, x + w / 2, y + h / 2, w - 10);
              compCtx.restore();
            }
          } catch (errOv) {}
        }
      }
    } catch (errFrame) {
    } finally {
      compAnimFrame = requestAnimationFrame(renderCompositor);
    }
  }

  function initCompositor() {
    if (!compStream) {
      compStream = compCanvas.captureStream(obterPerfilQualidade().fps);
    }
    if (!compAnimFrame) {
      renderCompositor();
    }
    return compStream;
  }

  function notificarAlteracaoOverlays() {
    renderOverlayDOM();
    renderOverlayListUI();
  }

  function pedirId(c) {
    if (!c || typeof c !== 'object') return null;
    let d = c.deviceId;
    if (!d) return null;
    if (typeof d === 'string') return d;
    if (Array.isArray(d)) return d[0] || null;
    if (typeof d === 'object') {
      const v = d.exact !== undefined ? d.exact : d.ideal;
      return Array.isArray(v) ? v[0] : (v || null);
    }
    return null;
  }

  function trackVideoAudio() {
    if (!videoEl || !videoEl.__cvStream) return null;
    const list = videoEl.__cvStream.getAudioTracks();
    return list[0] || null;
  }

  function trackAtual(kind) {
    if (kind === 'audio') return audioParaLive();
    initCompositor();
    const list = compStream ? compStream.getVideoTracks() : [];
    return list[0] || null;
  }

  function novoClone(kind) {
    if (kind === 'audio') return audioParaLive();
    const t = trackAtual('video');
    if (!t) return null;
    const c = t.clone();
    if (modoLeve && c && typeof c.applyConstraints === 'function') {
      try {
        c.applyConstraints({
          width: { ideal: 720, max: 1080 },
          height: { ideal: 1280, max: 1920 },
          frameRate: { ideal: 20, max: 24 }
        }).catch(() => {});
      } catch (e) {}
    }
    nossasTracks.add(c);
    return c;
  }

  // ---------- Mixer de Áudio ----------
  let actx = null, mixDest = null, gVideo = null, gFx = null, gMic = null, gMaster = null, gMonitor = null;
  let monOn = false; try { monOn = localStorage.getItem('lc-mon') === '1'; } catch (e) {}
  let vSrc = null, vSrcTrackId = null;
  let micStream = null, micSrc = null, micOn = false;
  let fxVol = 0.2;
  let audioSepEl = null, audioSepSrc = null, gAudioSep = null, audioSepOn = false, audioSepReady = false, audioSepURL = null;
  let audioSepFileObj = null;

  // Estado do Motor de Fatiamento e Embaralhamento de Áudio
  let audioSepEmbaralhar = false; try { audioSepEmbaralhar = localStorage.getItem('lc-audshuf') === '1'; } catch (e) {}
  let audioSepSlices = []; // Lista de trechos do áudio
  let audioSepSliceOrder = [];
  let currentSliceIndex = 0;
  let sliceSourceNode = null;
  let isPlayingSlicedAudio = false;

  let audSepLoop = false; try { audSepLoop = localStorage.getItem('lc-audseploop') === '1'; } catch (e) {}
  let fxAuto = false, fxAutoTimer = null, fxAutoIntervalS = 60, fxSeq = [], fxSeqI = 0;
  try { fxAutoIntervalS = parseInt(localStorage.getItem('lc-fxint') || '60', 10); } catch (e) {}

  function initMix() {
    if (actx) return;
    try {
      actx = new (window.AudioContext || window.webkitAudioContext)();
      mixDest = actx.createMediaStreamDestination();
      gMaster = actx.createGain(); gMaster.gain.value = 1.0; gMaster.connect(mixDest);
      gMonitor = actx.createGain(); gMonitor.gain.value = monOn ? 1 : 0; try { gMaster.connect(gMonitor); gMonitor.connect(actx.destination); } catch (e) {}
      gVideo = actx.createGain(); gVideo.gain.value = 1.0; gVideo.connect(gMaster);
      gFx = actx.createGain(); gFx.gain.value = fxVol; gFx.connect(gMaster);
      gMic = actx.createGain(); gMic.gain.value = 1.0; gMic.connect(gMaster);
      gAudioSep = actx.createGain(); gAudioSep.gain.value = 0; gAudioSep.connect(gMaster);
    } catch (e) { actx = null; }
  }

  function resumeMix() { try { if (actx && actx.state === 'suspended') actx.resume(); } catch (e) {} }

  function conectarVideoNoMix() {
    initMix(); if (!actx) return;
    resumeMix();
    const t = trackVideoAudio();
    if (!t) {
      if (vSrc) { try { vSrc.disconnect(); } catch (e) {} vSrc = null; vSrcTrackId = null; }
      return;
    }
    if (vSrcTrackId === t.id && vSrc) return;
    try { if (vSrc) vSrc.disconnect(); } catch (e) {}
    try { vSrc = actx.createMediaStreamSource(new MediaStream([t])); vSrc.connect(gVideo); vSrcTrackId = t.id; } catch (e) {}
  }

  function audioParaLive() {
    initMix();
    if (!actx || !mixDest) return null;
    conectarVideoNoMix();
    resumeMix();
    aplicarAudioSep();
    const mt = mixDest.stream.getAudioTracks()[0];
    if (!mt) return null;
    const c = mt.clone();
    nossasTracks.add(c);
    return c;
  }

  // ---------- Geradores de Som Sintéticos ----------
  function bufRuido(dur) {
    const n = Math.max(1, Math.floor(actx.sampleRate * dur));
    const b = actx.createBuffer(1, n, actx.sampleRate), d = b.getChannelData(0);
    let last = 0;
    for (let i = 0; i < n; i++) { const w = Math.random() * 2 - 1; last = (last + 0.02 * w) / 1.02; d[i] = last * 3.5; }
    return b;
  }

  function fxRespiracao() {
    initMix(); if (!actx) return; resumeMix();
    try {
      const src = actx.createBufferSource(); src.buffer = bufRuido(10.6);
      const f = actx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1050; f.Q.value = 0.5;
      const g = actx.createGain(); const t = actx.currentTime;
      g.gain.setValueAtTime(0.0001, t);
      let cur = t;
      for (let i = 0; i < 4; i++) {
        g.gain.linearRampToValueAtTime(0.9, cur + 1.0);
        g.gain.linearRampToValueAtTime(0.08, cur + 2.4);
        cur += 2.5;
      }
      g.gain.linearRampToValueAtTime(0.0001, cur);
      src.connect(f); f.connect(g); g.connect(gFx);
      src.start(t); src.stop(t + 10.6);
    } catch (e) {}
  }

  function fxTelefone() {
    initMix(); if (!actx) return; resumeMix();
    try {
      const t0 = actx.currentTime;
      const master = actx.createGain(); master.gain.value = 0.0001; master.connect(gFx);
      const o1 = actx.createOscillator(); o1.type = 'sine'; o1.frequency.value = 440;
      const o2 = actx.createOscillator(); o2.type = 'sine'; o2.frequency.value = 480;
      const lfo = actx.createOscillator(); lfo.type = 'sine'; lfo.frequency.value = 22;
      const lfoGain = actx.createGain(); lfoGain.gain.value = 0.5;
      const trem = actx.createGain(); trem.gain.value = 0.5;
      lfo.connect(lfoGain); lfoGain.connect(trem.gain);
      o1.connect(trem); o2.connect(trem); trem.connect(master);
      let cur = t0;
      for (let i = 0; i < 3; i++) {
        master.gain.setValueAtTime(0.0001, cur);
        master.gain.linearRampToValueAtTime(0.8, cur + 0.05);
        master.gain.setValueAtTime(0.8, cur + 1.3);
        master.gain.linearRampToValueAtTime(0.0001, cur + 1.45);
        cur += 3.3;
      }
      const stopT = cur + 0.1;
      o1.start(t0); o2.start(t0); lfo.start(t0);
      o1.stop(stopT); o2.stop(stopT); lfo.stop(stopT);
    } catch (e) {}
  }

  function fxClique() {
    initMix(); if (!actx) return; resumeMix();
    try {
      const t0 = actx.currentTime;
      for (let i = 0; i < 2; i++) {
        const t = t0 + i * 0.11;
        const o = actx.createOscillator(); o.type = 'triangle';
        o.frequency.setValueAtTime(1900, t); o.frequency.exponentialRampToValueAtTime(950, t + 0.03);
        const g = actx.createGain();
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(0.9, t + 0.002);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
        o.connect(g); g.connect(gFx);
        o.start(t); o.stop(t + 0.07);
      }
    } catch (e) {}
  }

  function fxSalaBurst() {
    initMix(); if (!actx) return; resumeMix();
    try {
      const src = actx.createBufferSource(); src.buffer = bufRuido(10.4);
      const f = actx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 900;
      const g = actx.createGain(); const t = actx.currentTime;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.47, t + 0.6);
      g.gain.setValueAtTime(0.47, t + 9.2);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 10.0);
      src.connect(f); f.connect(g); g.connect(gFx);
      src.start(t); src.stop(t + 10.1);
    } catch (e) {}
  }

  async function toggleMic() {
    initMix(); if (!actx) return micOn;
    if (micOn) {
      try { if (micSrc) micSrc.disconnect(); } catch (e) {}
      if (micStream) micStream.getTracks().forEach(t => t.stop());
      micStream = null; micSrc = null; micOn = false;
      try { if (gVideo) gVideo.gain.setTargetAtTime(audioSepOn ? 0 : 1.0, actx.currentTime, 0.15); } catch (e) {}
    } else {
      try { micStream = await origGUM({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); }
      catch (e) { return micOn; }
      resumeMix();
      try { micSrc = actx.createMediaStreamSource(micStream); micSrc.connect(gMic); } catch (e) {}
      micOn = true;
      try { if (gVideo) gVideo.gain.setTargetAtTime(audioSepOn ? 0 : 0.15, actx.currentTime, 0.15); } catch (e) {}
    }
    return micOn;
  }

  // ---------- ALGORITMO REAL DE FATIAMENTO E EMBARALHAMENTO DE TRECHOS ----------
  function embaralharArray(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const tmp = a[i]; a[i] = a[j]; a[j] = tmp;
    }
    return a;
  }

  async function fatiarArquivoAudio(file) {
    initMix(); if (!actx) return [];
    try {
      const buf = await file.arrayBuffer();
      const decoded = await actx.decodeAudioData(buf);
      const channelData = decoded.getChannelData(0);
      const sampleRate = decoded.sampleRate;
      const totalSamples = channelData.length;

      const slices = [];
      let startSample = 0;
      const minSilenceLength = Math.floor(sampleRate * 0.20); // 200ms silêncio
      const threshold = 0.015;
      let silenceSamples = 0;

      for (let i = 0; i < totalSamples; i++) {
        const val = Math.abs(channelData[i]);
        if (val < threshold) {
          silenceSamples++;
        } else {
          if (silenceSamples >= minSilenceLength && (i - startSample) > sampleRate * 1.8) {
            const sliceLen = i - startSample;
            const sliceBuf = actx.createBuffer(decoded.numberOfChannels, sliceLen, sampleRate);
            for (let ch = 0; ch < decoded.numberOfChannels; ch++) {
              sliceBuf.getChannelData(ch).set(decoded.getChannelData(ch).subarray(startSample, i));
            }
            slices.push(sliceBuf);
            startSample = i;
          }
          silenceSamples = 0;
        }
      }

      if (startSample < totalSamples - sampleRate * 0.5) {
        const sliceLen = totalSamples - startSample;
        const sliceBuf = actx.createBuffer(decoded.numberOfChannels, sliceLen, sampleRate);
        for (let ch = 0; ch < decoded.numberOfChannels; ch++) {
          sliceBuf.getChannelData(ch).set(decoded.getChannelData(ch).subarray(startSample, totalSamples));
        }
        slices.push(sliceBuf);
      }

      // Se não encontrou pausas suficientes (música ou áudio sem silêncio), fatiar a cada 5 segundos
      if (slices.length < 2) {
        slices.length = 0;
        const blockSize = Math.floor(sampleRate * 5.0);
        for (let pos = 0; pos < totalSamples; pos += blockSize) {
          const len = Math.min(blockSize, totalSamples - pos);
          if (len < sampleRate * 0.8) break;
          const sliceBuf = actx.createBuffer(decoded.numberOfChannels, len, sampleRate);
          for (let ch = 0; ch < decoded.numberOfChannels; ch++) {
            sliceBuf.getChannelData(ch).set(decoded.getChannelData(ch).subarray(pos, pos + len));
          }
          slices.push(sliceBuf);
        }
      }

      return slices;
    } catch (e) {
      return [];
    }
  }

  function pararSlicesEmbaralhados() {
    isPlayingSlicedAudio = false;
    if (sliceSourceNode) {
      try { sliceSourceNode.onended = null; sliceSourceNode.stop(); } catch (e) {}
      sliceSourceNode = null;
    }
  }

  function tocarProximoSliceEmbaralhado() {
    if (!audioSepOn || !audioSepEmbaralhar || !isPlayingSlicedAudio || !audioSepSlices.length) return;

    if (currentSliceIndex >= audioSepSliceOrder.length) {
      if (!audSepLoop) {
        status('🔀 Áudio embaralhado finalizado.');
        return;
      }
      // Re-embaralhar totalmente a ordem dos trechos para o novo ciclo!
      audioSepSliceOrder = embaralharArray(Array.from({ length: audioSepSlices.length }, (_, i) => i));
      currentSliceIndex = 0;
    }

    const sliceBufIdx = audioSepSliceOrder[currentSliceIndex++];
    const sliceBuf = audioSepSlices[sliceBufIdx];
    if (!sliceBuf || !actx) return;

    sliceSourceNode = actx.createBufferSource();
    sliceSourceNode.buffer = sliceBuf;
    // Micro-variação de velocidade (0.988x a 1.012x) extra
    sliceSourceNode.playbackRate.value = 0.988 + Math.random() * 0.024;
    sliceSourceNode.connect(gAudioSep);

    sliceSourceNode.onended = () => {
      if (isPlayingSlicedAudio && audioSepEmbaralhar) {
        tocarProximoSliceEmbaralhado();
      }
    };

    sliceSourceNode.start(0);
    status('🔀 Tocando trecho ' + (currentSliceIndex) + ' de ' + audioSepSlices.length + ' (Ordem Embaralhada)');
  }

  async function aplicarAudioSep() {
    initMix(); if (!actx) return;
    if (audioSepOn && audioSepReady && audioSepFileObj) {
      resumeMix();
      if (gAudioSep) gAudioSep.gain.value = 1.0;
      try { if (gVideo) gVideo.gain.value = 0; } catch (e) {}

      if (audioSepEmbaralhar) {
        // Modo Embaralhado Ativo: Pausar player linear e ativar o Motor de Slices
        if (audioSepEl) { try { audioSepEl.pause(); } catch (e) {} }
        pararSlicesEmbaralhados();

        status('⏳ Fatiando áudio em trechos para embaralhar...');
        if (!audioSepSlices.length) {
          audioSepSlices = await fatiarArquivoAudio(audioSepFileObj);
        }

        if (audioSepSlices.length >= 2) {
          audioSepSliceOrder = embaralharArray(Array.from({ length: audioSepSlices.length }, (_, i) => i));
          currentSliceIndex = 0;
          isPlayingSlicedAudio = true;
          tocarProximoSliceEmbaralhado();
        } else {
          // Fallback para player normal se não foi possível fatiar
          if (audioSepEl) { audioSepEl.loop = audSepLoop; try { audioSepEl.play().catch(() => {}); } catch (e) {} }
        }
      } else {
        // Modo Normal: Parar motor de slices e usar player linear
        pararSlicesEmbaralhados();
        if (!audioSepSrc && audioSepEl) {
          try {
            audioSepSrc = actx.createMediaElementSource(audioSepEl);
            audioSepSrc.connect(gAudioSep);
          } catch (e) {}
        }
        if (audioSepEl) {
          audioSepEl.loop = audSepLoop;
          audioSepEl.onended = () => {
            if (!audSepLoop && audioSepOn) {
              audioSepOn = false;
              if (gAudioSep) gAudioSep.gain.value = 0;
              try { if (gVideo && actx) gVideo.gain.value = micOn ? 0.15 : 1.0; } catch (ex) {}
              pintaAS2();
            }
          };
          try { audioSepEl.play().catch(() => {}); } catch (e) {}
        }
      }
    } else {
      if (gAudioSep) gAudioSep.gain.value = 0;
      if (audioSepEl) { try { audioSepEl.pause(); } catch (e) {} }
      pararSlicesEmbaralhados();
      try { if (gVideo && actx) gVideo.gain.value = micOn ? 0.15 : 1.0; } catch (e) {}
    }
  }

  // ---------- WebRTC Interceptions com Stealth Masking ----------
  const fakeGUM = async function getUserMedia(constraints) {
    if (!ativo) return origGUM(constraints);
    const s = new MediaStream();
    let usouFake = false;
    if (constraints && constraints.video) {
      const id = pedirId(constraints.video);
      let ct = (!id || id === FAKE_VIDEO_ID || (typeof id === 'string' && (id.includes('fake') || id.includes('infinity') || id.includes('live')))) ? novoClone('video') : null;
      if (ct) {
        s.addTrack(ct);
        usouFake = true;
      } else {
        try {
          const realStream = await origGUM({ video: constraints.video });
          realStream.getVideoTracks().forEach(t => s.addTrack(t));
        } catch (e) {}
        if (s.getVideoTracks().length === 0) {
          ct = novoClone('video');
          if (ct) { s.addTrack(ct); usouFake = true; }
        }
      }
    }
    if (constraints && constraints.audio) {
      const id = pedirId(constraints.audio);
      let ct = (!id || id === FAKE_AUDIO_ID || (typeof id === 'string' && (id.includes('fake') || id.includes('infinity') || id.includes('live')))) ? audioParaLive() : null;
      if (ct) {
        s.addTrack(ct);
        usouFake = true;
      } else {
        try {
          const realAudio = await origGUM({ audio: constraints.audio });
          realAudio.getAudioTracks().forEach(t => s.addTrack(t));
        } catch (e) {}
        if (s.getAudioTracks().length === 0) {
          ct = audioParaLive();
          if (ct) { s.addTrack(ct); usouFake = true; }
        }
      }
    }

    if (s.getTracks().length === 0) {
      return origGUM(constraints);
    }

    if (usouFake) { handedStreams.add(s); status('🔴 No ar! Transmitindo LiveCam Infinity.'); }
    return s;
  };
  navigator.mediaDevices.getUserMedia = maskNative(fakeGUM, origGUM);

  const fakeEnum = async function enumerateDevices() {
    const devices = await origEnum();
    if (!ativo) return devices;
    const mk = (id, kind, label) => ({
      deviceId: id, groupId: FAKE_GROUP_ID, kind, label,
      toJSON() { return { deviceId: id, groupId: FAKE_GROUP_ID, kind, label }; }
    });
    const extras = [
      mk(FAKE_VIDEO_ID, 'videoinput', FAKE_VIDEO_LABEL),
      mk(FAKE_AUDIO_ID, 'audioinput', FAKE_AUDIO_LABEL)
    ];
    return [...extras, ...devices];
  };
  navigator.mediaDevices.enumerateDevices = maskNative(fakeEnum, origEnum);

  function atualizarConsumidores() {
    for (const s of handedStreams) {
      for (const kind of ['video', 'audio']) {
        const olds = kind === 'video' ? s.getVideoTracks() : s.getAudioTracks();
        const mortas = olds.filter(t => nossasTracks.has(t) && t.readyState === 'ended');
        if (mortas.length) {
          mortas.forEach(t => s.removeTrack(t));
          const nt = kind === 'video' ? novoClone('video') : audioParaLive();
          if (nt) s.addTrack(nt);
        }
      }
    }
  }

  function recapturarForcado() {
    try {
      if (videoEl) {
        videoEl.__cvStream = videoEl.captureStream(obterPerfilQualidade().fps);
      }
      for (const s of handedStreams) {
        for (const kind of ['video', 'audio']) {
          const olds = kind === 'video' ? s.getVideoTracks() : s.getAudioTracks();
          olds.forEach(t => {
            try { s.removeTrack(t); t.stop(); } catch (e) {}
          });
          const nt = kind === 'video' ? novoClone('video') : audioParaLive();
          if (nt) s.addTrack(nt);
        }
      }
      conectarVideoNoMix();
    } catch (e) {}
  }

  function recapturar() {
    recapturarForcado();
  }

  function ressincronizar(manual) {
    if (!videoEl || !videoEl.src || !videoEl.duration) return;
    const t = videoEl.currentTime;
    try { videoEl.currentTime = Math.min(videoEl.duration - 0.05, t + 0.06); } catch (e) {}
    if (videoEl.paused) videoEl.play().catch(() => {});
    if (manual) status('🔁 Áudio sincronizado.');
  }

  function reprogramarSync() {
    if (syncTimer) { clearInterval(syncTimer); syncTimer = null; }
    if (autoSync && syncIntervalS > 0) {
      syncTimer = setInterval(() => {
        if (ativo && videoEl && !videoEl.paused && videoEl.src) ressincronizar(false);
      }, syncIntervalS * 1000);
    }
  }

  setInterval(() => {
    if (!ativo || !videoEl || !videoEl.__cvStream || videoEl.paused) return;
    const at = videoEl.__cvStream.getAudioTracks()[0];
    if (at && (at.id !== vSrcTrackId || !vSrc)) { conectarVideoNoMix(); }
  }, 1000);

  // ---------- Playlist Multi-Vídeo Sequencial em Loop ----------
  function medirDuracao(item) {
    return new Promise((res) => {
      try {
        const v = document.createElement('video');
        v.preload = 'metadata'; v.muted = true;
        v.onloadedmetadata = () => { item.dur = isFinite(v.duration) ? v.duration : 0; try { v.removeAttribute('src'); v.load(); } catch (e) {} res(); };
        v.onerror = () => { item.dur = 0; res(); };
        v.src = item.url;
      } catch (e) { item.dur = 0; res(); }
    });
  }

  async function addArquivos(files) {
    for (const f of files) {
      status('⏳ Carregando vídeo…');
      let url;
      try {
        const buf = await f.arrayBuffer();
        url = URL.createObjectURL(new Blob([buf], { type: f.type || 'video/mp4' }));
      } catch (e) { url = URL.createObjectURL(f); }
      const item = { url, nome: f.name, dur: 0 };
      playlist.push(item);
      medirDuracao(item).then(() => { renderPlaylist(); atualizarBarra(); });
    }
    renderPlaylist();
    if (idxAtual === -1 && playlist.length) tocar(0);
  }

  let userPaused = false;

  async function tocar(i) {
    if (!playlist[i]) return;
    userPaused = false;
    resumeMix();
    idxAtual = i;
    videoEl.src = playlist[i].url;
    videoEl.load();
    try {
      await videoEl.play();
    } catch (e) {
      videoEl.muted = true; atualizarAudioBtn();
      try { await videoEl.play(); } catch (e2) { status('❌ Erro ao tocar vídeo.'); return; }
    }
    videoEl.playbackRate = velocidadeRate;
    videoEl.__cvStream = videoEl.captureStream(obterPerfilQualidade().fps);
    recapturarForcado();
    ativo = true;
    iniciarVigia();
    pedirWakeLock();
    try { navigator.mediaDevices.dispatchEvent(new Event('devicechange')); } catch (e) {}
    renderPlaylist();
    atualizarEstado();
    status('Transmitindo: Vídeo ' + (idxAtual + 1) + ' de ' + playlist.length + (velocidadeRate !== 1.0 ? ' (' + velocidadeRate + 'x)' : ''));
  }

  function ligar() {
    userPaused = false;
    if (playlist.length) tocar(idxAtual >= 0 ? idxAtual : 0);
    else { status('Adicione um vídeo primeiro.'); abrirSeletorArquivo(); }
  }

  function abrirSeletorArquivo() {
    const el = document.getElementById('cv-arquivo');
    if (el) el.click();
  }

  function proximo() {
    if (!playlist.length) return;
    const proxIndex = (idxAtual + 1) % playlist.length;
    tocar(proxIndex);
  }

  function aplicarVelocidade(rate) {
    velocidadeRate = parseFloat(rate) || 1.0;
    if (videoEl) videoEl.playbackRate = velocidadeRate;
    try { localStorage.setItem('lc-speed', String(velocidadeRate)); } catch (e) {}
    atualizarSpeedUI();
    if (ativo && playlist.length) {
      status('⚡ Velocidade alterada para ' + velocidadeRate + 'x');
    }
  }

  function removerItem(i) {
    URL.revokeObjectURL(playlist[i].url);
    playlist.splice(i, 1);
    if (i === idxAtual) {
      idxAtual = -1;
      if (playlist.length) tocar(Math.min(i, playlist.length - 1));
      else desligar();
    } else if (i < idxAtual) idxAtual--;
    renderPlaylist();
  }



  // ---------- Trava Anti-Pausa ao Fixar Produtos no TikTok Shop ----------
  const origHTMLPause = HTMLVideoElement.prototype.pause;
  HTMLVideoElement.prototype.pause = function () {
    if (videoEl && this === videoEl && ativo && !userPaused) {
      // Bloqueia tentativas do script do TikTok de pausar o vídeo ao fixar produtos
      return;
    }
    return origHTMLPause.apply(this, arguments);
  };

  function despausarForcado() {
    if (userPaused) return;
    if (origHTMLPause && videoEl && ativo && videoEl.src) {
      if (videoEl.paused) {
        try { videoEl.play().catch(() => {}); } catch (e) {}
      }
    }
  }

  // ---------- Vigia de Alta Velocidade (400ms) ----------
  function iniciarVigia() {
    if (watchdog) return;
    watchdog = setInterval(() => {
      if (!ativo || !videoEl || !videoEl.src || userPaused) return;
      if (videoEl.ended) return;
      if (videoEl.paused) {
        despausarForcado();
      }
      if (videoEl.currentTime === ultimoTempo && !videoEl.paused) {
        despausarForcado();
      }
      ultimoTempo = videoEl.currentTime;
    }, 400);
  }

  // Ouvinte global para despausar ao clicar em botões de produtos ou modais do TikTok
  document.addEventListener('click', () => {
    if (ativo && !userPaused) despausarForcado();
  }, true);

  async function pedirWakeLock() {
    try { if ('wakeLock' in navigator) wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {}
  }

  document.addEventListener('visibilitychange', () => {
    if (ativo && document.visibilityState === 'visible' && !userPaused) {
      pedirWakeLock();
      despausarForcado();
    }
  });

  function desligar() {
    ativo = false;
    userPaused = false;
    if (micOn) { try { if (micSrc) micSrc.disconnect(); } catch (e) {} if (micStream) micStream.getTracks().forEach(t => t.stop()); micStream = null; micSrc = null; micOn = false; const mb = document.getElementById('cv-mic'); if (mb) { mb.innerHTML = IC.micOff + ' Abrir microfone (falar)'; mb.style.borderColor = '#28304c'; mb.style.color = '#e2e8ff'; mb.style.background = '#141829'; } }
    if (fxAuto || fxAutoTimer) { if (fxAutoTimer) { clearTimeout(fxAutoTimer); fxAutoTimer = null; } fxAuto = false; const ab = document.getElementById('cv-auto'); if (ab) { ab.style.borderColor = '#28304c'; } const asw = document.getElementById('cv-auto-sw'); if (asw) { asw.textContent = 'OFF'; asw.style.background = '#1c223a'; asw.style.color = '#8791bd'; } }
    if (audioSepOn) { audioSepOn = false; if (gAudioSep) gAudioSep.gain.value = 0; if (audioSepEl) { try { audioSepEl.pause(); } catch (e) {} } try { if (gVideo && actx) gVideo.gain.value = 1.0; } catch (e) {} const asw2 = document.getElementById('cv-audsep-sw'); if (asw2) { asw2.textContent = 'OFF'; asw2.style.background = '#1c223a'; asw2.style.color = '#8791bd'; } const asc = document.getElementById('cv-audsep-card'); if (asc) asc.style.borderColor = 'rgba(255,204,0,.2)'; }
    if (videoEl) { videoEl.pause(); videoEl.removeAttribute('src'); videoEl.load(); videoEl.__cvStream = null; }
    if (wakeLock) { wakeLock.release().catch(() => {}); wakeLock = null; }
    pararSlicesEmbaralhados();
    atualizarEstado(); atualizarToggle();
    status('Câmera virtual desligada. Clique no botão de Ligar para reativar.');
    renderPlaylist();
  }

  // ---------- Gerenciador de Overlays na UI (Drag & Drop 60FPS Ultra Fluido) ----------
  const overlayElementsMap = new Map();

  function renderOverlayDOM() {
    const stage = document.getElementById('cv-overlay-stage');
    if (!stage) return;

    for (const [id, el] of overlayElementsMap.entries()) {
      if (!overlays.some(o => o.id === id)) {
        if (el.parentNode) el.parentNode.removeChild(el);
        overlayElementsMap.delete(id);
      }
    }

    overlays.forEach((ov) => {
      if (!ov.visible) return;
      let el = overlayElementsMap.get(ov.id);

      if (!el) {
        el = document.createElement('div');
        el.id = 'ov-el-' + ov.id;
        el.style.cssText = [
          'position:absolute !important',
          'box-sizing:border-box !important',
          'cursor:grab !important',
          'user-select:none !important',
          'display:flex !important',
          'align-items:center !important',
          'justify-content:center !important',
          'touch-action:none !important'
        ].join(';');

        const handle = document.createElement('div');
        handle.className = 'ov-resizer-handle';
        handle.style.cssText = 'position:absolute;right:-5px;bottom:-5px;width:12px;height:12px;background:#ffcc00;border:1.5px solid #000;border-radius:50%;cursor:nwse-resize;z-index:10;';
        el.appendChild(handle);

        let isDragging = false, isResizing = false;
        let startX = 0, startY = 0, startLeftPx = 0, startTopPx = 0, startWPx = 0, startHPx = 0;

        handle.addEventListener('mousedown', (e) => {
          e.stopPropagation();
          e.preventDefault();
          isResizing = true;
          selectedOverlayId = ov.id;
          startX = e.clientX;
          startY = e.clientY;
          startWPx = el.offsetWidth;
          startHPx = el.offsetHeight;
          renderOverlayListUI();
          updateSelectionBorders();
        });

        el.addEventListener('mousedown', (e) => {
          if (e.target.classList.contains('ov-resizer-handle')) return;
          e.preventDefault();
          isDragging = true;
          el.style.cursor = 'grabbing';
          selectedOverlayId = ov.id;
          startX = e.clientX;
          startY = e.clientY;
          startLeftPx = el.offsetLeft;
          startTopPx = el.offsetTop;
          renderOverlayListUI();
          updateSelectionBorders();
        });

        window.addEventListener('mousemove', (e) => {
          if (!isDragging && !isResizing) return;
          const stageW = stage.offsetWidth;
          const stageH = stage.offsetHeight;

          if (isDragging) {
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            const newLeftPx = Math.min(Math.max(0, startLeftPx + dx), stageW - el.offsetWidth);
            const newTopPx = Math.min(Math.max(0, startTopPx + dy), stageH - el.offsetHeight);
            ov.x = newLeftPx / stageW;
            ov.y = newTopPx / stageH;
            el.style.left = (ov.x * 100) + '%';
            el.style.top = (ov.y * 100) + '%';
          } else if (isResizing) {
            const dw = e.clientX - startX;
            const dh = e.clientY - startY;
            const newWPx = Math.min(Math.max(20, startWPx + dw), stageW - el.offsetLeft);
            const newHPx = Math.min(Math.max(16, startHPx + dh), stageH - el.offsetTop);
            ov.w = newWPx / stageW;
            ov.h = newHPx / stageH;
            el.style.width = (ov.w * 100) + '%';
            el.style.height = (ov.h * 100) + '%';
            if (ov.type === 'text') {
              const txtSpan = el.querySelector('.ov-txt-span');
              if (txtSpan) {
                txtSpan.style.fontSize = Math.max(10, Math.round((ov.fontSize || 36) * (stage.offsetHeight / 1000))) + 'px';
              }
            }
          }
        });

        window.addEventListener('mouseup', () => {
          if (isDragging || isResizing) {
            isDragging = false;
            isResizing = false;
            el.style.cursor = 'grab';
          }
        });

        stage.appendChild(el);
        overlayElementsMap.set(ov.id, el);
      }

      el.style.left = (ov.x * 100) + '%';
      el.style.top = (ov.y * 100) + '%';
      el.style.width = (ov.w * 100) + '%';
      el.style.height = (ov.h * 100) + '%';
      el.style.outline = (selectedOverlayId === ov.id ? '2px dashed #ffcc00' : '1px dashed rgba(255,255,255,0.4)');

      if (ov.type === 'text') {
        let txtSpan = el.querySelector('.ov-txt-span');
        if (!txtSpan) {
          txtSpan = document.createElement('span');
          txtSpan.className = 'ov-txt-span';
          txtSpan.style.cssText = 'pointer-events:none;word-break:break-word;line-height:1.2;';
          el.appendChild(txtSpan);
        }
        el.style.background = (ov.hasBg && ov.bgColor) ? ov.bgColor : 'transparent';
        el.style.color = ov.fontColor || '#ffffff';
        el.style.fontFamily = '\'Outfit\', \'Inter\', sans-serif';
        el.style.fontWeight = 'bold';
        txtSpan.style.fontSize = Math.max(10, Math.round((ov.fontSize || 36) * (stage.offsetHeight / 1000))) + 'px';
        el.style.textAlign = 'center';
        el.style.padding = '4px';
        el.style.borderRadius = '6px';
        txtSpan.textContent = ov.text || '';
      } else if (ov.type === 'image' && ov.imgUrl) {
        let img = el.querySelector('img');
        if (!img) {
          img = document.createElement('img');
          img.style.cssText = 'width:100%;height:100%;object-fit:contain;pointer-events:none;';
          el.appendChild(img);
        }
        img.src = ov.imgUrl;
      }
    });
  }

  function updateSelectionBorders() {
    for (const [id, el] of overlayElementsMap.entries()) {
      el.style.outline = (selectedOverlayId === id ? '2px dashed #ffcc00' : '1px dashed rgba(255,255,255,0.4)');
    }
  }

  function renderOverlayListUI() {
    const list = document.getElementById('cv-overlay-list');
    if (!list) return;
    list.innerHTML = '';

    if (!overlays.length) {
      list.innerHTML = '<div style="color:#8791bd;font-size:11px;text-align:center;padding:6px 0;">Nenhum overlay ativo no momento.</div>';
      return;
    }

    overlays.forEach((ov, idx) => {
      const item = document.createElement('div');
      item.style.cssText = 'display:flex;align-items:center;gap:6px;padding:6px 8px;background:#141829;border-radius:8px;margin-top:4px;font-size:11.5px;' +
        (selectedOverlayId === ov.id ? 'border:1px solid #ffcc00;color:#fff;' : 'border:1px solid #28304c;color:#ccc;');

      const label = document.createElement('span');
      label.style.cssText = 'flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer;';
      label.textContent = (ov.type === 'text' ? '📝 ' + (ov.text || 'Texto') : '🖼️ Imagem ' + (idx + 1));
      label.onclick = () => {
        selectedOverlayId = ov.id;
        if (ov.type === 'text') abrirEditorTextoInline(ov);
        renderOverlayDOM();
        renderOverlayListUI();
      };

      const btnDel = document.createElement('button');
      btnDel.textContent = '✕';
      btnDel.style.cssText = 'background:none;border:0;color:#fe5c5c;cursor:pointer;font-weight:bold;font-size:12px;padding:0 4px;';
      btnDel.onclick = (e) => {
        e.stopPropagation();
        overlays = overlays.filter(o => o.id !== ov.id);
        if (selectedOverlayId === ov.id) selectedOverlayId = null;
        fecharEditorTextoInline();
        notificarAlteracaoOverlays();
      };

      item.appendChild(label);
      item.appendChild(btnDel);
      list.appendChild(item);
    });
  }

  // ---------- Editor de Texto Integrado Estilo TikTok Live Studio ----------
  let editingTextOverlay = null;

  function abrirEditorTextoInline(ovTarget) {
    const box = document.getElementById('cv-txt-editor-box');
    if (!box) return;
    box.style.display = 'block';

    editingTextOverlay = ovTarget || null;

    const inpTxt = document.getElementById('cv-txt-val');
    const inpColor = document.getElementById('cv-txt-color');
    const inpBgColor = document.getElementById('cv-txt-bgcolor');
    const swBg = document.getElementById('cv-txt-bg-sw');
    const inpSize = document.getElementById('cv-txt-size');
    const btnSalvar = document.getElementById('cv-txt-salvar');

    if (ovTarget) {
      inpTxt.value = ovTarget.text || '';
      inpColor.value = ovTarget.fontColor || '#ffffff';
      inpBgColor.value = (ovTarget.bgColor && ovTarget.bgColor !== 'transparent') ? rgbToHex(ovTarget.bgColor) : '#e50914';
      if (swBg) {
        swBg.textContent = ovTarget.hasBg ? 'COM FUNDO' : 'SEM FUNDO';
        swBg.style.background = ovTarget.hasBg ? 'linear-gradient(135deg,#e50914 0%,#ff4b2b 100%)' : '#1c223a';
        swBg.style.color = ovTarget.hasBg ? '#fff' : '#8791bd';
      }
      inpSize.value = String(ovTarget.fontSize || 36);
      btnSalvar.textContent = '💾 Atualizar Texto na Live';
    } else {
      inpTxt.value = '🔴 OFERTA IMPERDÍVEL';
      inpColor.value = '#ffffff';
      inpBgColor.value = '#e50914';
      if (swBg) {
        swBg.textContent = 'COM FUNDO';
        swBg.style.background = 'linear-gradient(135deg,#e50914 0%,#ff4b2b 100%)';
        swBg.style.color = '#fff';
      }
      inpSize.value = '36';
      btnSalvar.textContent = '✨ Inserir Texto na Live';
    }
  }

  function fecharEditorTextoInline() {
    const box = document.getElementById('cv-txt-editor-box');
    if (box) box.style.display = 'none';
    editingTextOverlay = null;
  }

  function rgbToHex(color) {
    if (!color) return '#e50914';
    if (color.startsWith('#')) return color;
    return '#e50914';
  }

  // ---------- Interface ----------
  const $ = (id) => document.getElementById(id);
  const POS_PADRAO = { top: '72px', right: '16px' };

  const LOGO_ICON_BASE64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAABkCAYAAABNcPQyAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAET0SURBVHhe7b0HlBXF1v5d3SfNmZxzhIlkhpxzFARFEBCQoIiA5CAIigRByUl0CAbMiiDoVTFjQjEnzNeEOV2vOf2+tatPz+lz5gyCet/7vt/6z1rPOt09Vd3V9dTetWvXrmqllBqplKr6f/h7YUS49l+Cuk4phQ3DcXws1yPheNKG46/k/bP4bzzzP4Fa3kO3tvCL/+fxd73Tn7mPnefP5D0a/uh+tfxfi3H4xRqoJfPfjv+p50SCYdS8Vhuc5fwzZf4zef4kjo1ggRRK4zgqws4Xfu1/Esf6/ON9r+PBsZbhr8DmJ+z6sRN8rIj0oPDzY/3ffxK1ERqpPJGu/R/B30/w/yX8HybuWPGfM7L+U/c9VvyZ5//ZPMebz05/LPmOJc1R8NcI/it5/zfi/2/v87ep6L+zYv6MRPyn8b+pPMdZlr8mwf9N/F8td234D73P3yPBf4Q/W3hbml2GwqUUbiMU+noAprLwP60BarPG/5fgf4bg44VNqsel8LkV0R5FnFeR4LMQ77PO4+S6RxHrUfjdCp+p8JhBwo+X7ONJ+1fy/J34g+f/9wi2C+YsoByLZHpdimgh1G+QGmuQlWBQmKwoT1VUpCrKkxX1UhQVaYqSZEVevCItWpEUZRHudym8psLtkOrw5/83cLRyHO1/fwH/OYKPt8BmgNgYryI5xiAjXpETr6ifoehQV9GnXDGyUnFBT8WmwYoNgxTndVUMqa9ona0oiVdkehUxAVLD7/+/EcdbR38C/zmCjweiUkUVx/sNshJdNMlTDGmfwuJJPdi1ZSoP71rIU3vn88/7Z/Pjq4vg881wZCX/evpcDv9jJg/unMZtVVPYuXYyW1ZMYP3S8axaNJYVC4Zz0fzBLJ83kOXz+rNsbl+WzOrJ4pndWDKzC0tndmTCsIbUzYmuUab/JI6n67D7eDuPE+Fp7XSO87+P4EgqtzY404i0ieQm+BX5KQYdSw12Lh/Ol+/eBj9eAz9ugB83wo+b4Kf18Mt2+O16+Pky+GEVfHcxfHsJ/Hs5/GsxfCUNYCF8Mg8+nAVHpsP7U+DdyfDPifD22fD2BHhjPLw+Hl4bz1cHBnPFgpZkJbhrlO94EZ73eOrFTmfDNhylqxEj04bz3GlcVt/HMOzjYyf4WAt4PJB7uk1LLafHK5rnK/ZsmQS/3wHfr4bvl8AX58J7s+D9efDBbDgy0yLtvXPgn+fA21PhrWnw5hR4fTIcPpvfXzqL3144k19fGMcvz43lp2dO58dDI/nhyZH8+OQofjw0iu8fH8H3jw2FF8fCq+PhzbN46druFCS7apTz70A4aZFgkyfwSMNXCp9S+B2ICkCuCySdnaeadKOar2MnuDaEDxOOpyHY0psYrciMVkwe3h6+vQ0+nwWfzuH5qwdzwcC6jG6dxtmdMpjUJY1pXdOY1S2d6V3SmNA+lXGtUzm9RQojmqUwpEkKAxok06ciid4VSfQoT6JrWRKdy5LoVJqo0VH/ynkS3cuTmNa3iINbe/Lb8yPg8Ok8sL4Vvr8w9DEMI6QObFJt8oSQSHCSGa0UsUoRrxSJSpFsKFICkGO5Jv+LU5bNYRMv+eU+NukhBNstLLzA4QhPE35+rP8TSN8b5VYkRinqpPp55p6L4IsL4MhcqsaVk+9M6yjjH933eCGVdN25lfDSKHh1NJNPzK2R5nhgl09+bWJtAoUIWxqFSHm2kClkJQiZSpGqFBlKkWMq8t2Kuh5FiUdR7FUUexRFLkWOYaWRtEK45LUJl/vKs45bgo+1YkWq/yit/F+GRDEeqxImnt4HPrwAPpzGg2t66MJKOhnXihqXXxn6eExDw2VYsCVES4481/4NlEMdQ1kEBT6D93adAK+M461dPUiLre7H/hTsvjP8ejikbCJxQopIpRCcrpRu3OVK0dxU9IpSDI5V9PcrunkVzUxFHaXIUoqUALHSYCI8r3aCndKi+4iA80Dr+TDPkf2/P5KuajIC9xDCxDmRnpzIK/fPgTfH8e3jp9El17JqNZEuA7fLDMCF2y1wW78uFy4b4ecCU2Bi2jDMQAMIhV2+qV2z+PngYH57chDLzyiqUf4/gv3udt0o06RTWV0m1C9jYkUpEypKOEvOS+tydkWpxpQGZcyqbMC8Vo1Y2LYxiztUsrxLc9b2bskVJ7Zh7/AOPHFOZ95a3J2XZnbggREtueGEZmzo2IiLWtbngsp6zG9SzuxGZUyrX8rk8mLOLq3LlLISKUtNgm3CRGpsyfG5FFFhkGsCLVniWAgci1TanbzdMIRMuS7/tyVRIB4oeebsSf3g9bPg8EjWjSmzKknyCKmaTAsej8DjgBuP43/OtEKwbhAOwoVki3gH6aZFujxTVOWBS5rx7WODeG93VypyPDVIjARnw5ZfbfC4TJZ2acsvHTtCUQk/1S3j++Iyvq1Txr+LSvmubhk/1C3j59JyqFcfGjWEpo2gWSNo3QS6NYMBLWF4Kzi7PUzvCKNaQf9K6NoEWjaARhVQUc7v5WX8VlbKzyWlfF9cyjd1SqCOrsdQgrVkmYooj0WiFDTKUEQLGW5FrDgiXAq/SJ8QEJBoT0CCxV3o9wTdheJq9Lqt+8X4FLHiiJBjcTP6LNVUnJ/N2w+ewy+HBvDmjT3I85u6LEKEkOe1iXSQa13zhpBd3Qjk1yWwJT1Idoh0O0h3kty3LI4P93bny7t7cfm0OjUI/CNoyVWKTvExfN+wEUfiUjmSmsH7qZn8My1H4+20HN5Jy+aD9Gw+zMjmo8wcPs3K5vOsbL7IzuHr/Fy+rZPHj+UF/NKokN+aFfBbsyJ+Ls3n33k5fJ2bzRc5OXyWk83HmVkcSc/i/bRM3k3L4s3UTN5IyeDz1KxQgm21GeW1XH0VBemsuWgad+9Zwz17lnL3redz9y0LufuW+dx54xzuuH4Gt187hduvPoO9O4axdForKrI92mASkn0ew/JMuRR10rzUzfCRFe8myW8S5zNJjfVQUaeIXZefwc9PjeTHJ05hag9dKF3ZmkivN0CmA96w80ADqCY3RIr/mOCgNAdV9foz6vDZP7rx0d6u9GsZX10/NnlOhJMvDV5+R3q9fJmSxVupGbyTksFbcpyey9sxibztjuK95DTeT8/mvfRs3s3I5d3MXD7IyOJIdAwfpSTxVUE+P+Sk8XOdJH6tzOWX5sX8UFrI1wX5fJqdw5GoGN6PiuHD9AzejU/iNbefV91+Dpt+XjGj+MSMCiW42pvkUzQqTOW5x7YCtwC3AbuA7cBlwAZgJfy6FH44H76YAkcmwgdTuH1lJbnxlqtR7lMnK5HLVk3khQdW8cS+83ng+hncuW08+y4bzd3bx/PmvdP55uFBfPPIQJ6+rBOpLquShRhNrteSUq9Ia+C4JmzJDiXXkmI5DpfYmiTb/bNdF6VJHg7v7MDHd/bhuSta0bFxQg1ia4PdCEa6PXyamMqriakcTsrg1aQM3ohL5kjvvnw5bTof1WvAPxNSNfFvpmXzVnIG7xbV5YupU/l8/Di+yM3mp4F9+WXhLH48uRvfVeTxTXE+n+fk8kl+Pl+ecSafTTibIxmZfNy9Kx9Nm86RiZP4eMpUPjxnCt9Mn2ERrCVXzHhRwz6DRLdi2ZwRwG5++mAh1y3szprxrVl1ZjNWjmvCJeOasGJMQy4cXsF5Q8qYfEIh1y5uw2/Pj+aT23vQrsjQ6jclxsOubVPhq7nwwZnw2ih47lR+OXQSPz5+It893Jev7uvJNwdO5MPdPTi5NFZXjGGYlmoOEOwkuiYC5EaQXtsgCyfTKbkhBDvUtGBO31y+2t+dd25uz2vXtuLKRc2YOaqCfu3S8HqsxlC72jYYpBRvu6N5LjaF5+LTeDEhjZeUl69vuBH5e3fAIF5xRXM4KZ3Dyem8Hh3Hu5XN9f9++ufbHImP45vp0/X5D7tv5ePEOD7Oy+X92AQ+6dNPX//+lcO87PHyxYb1+jz8T7mUqpL+U/pbkbiMOIMsv+Kq9WcDN/Hi7eOqnfeR1JONsrwYvnrwJF7Z2YmSFOvFmzUs4OunJvHdY315Zltb7r+kGY+sacnBDW14dF1rHlzVmr0XNmHz+BKGl/mr7yUVrqXW68Hn8+HzhZNskxnsd22J1YQFSLWtbSeJYvgEESTWDBw7CZNhx/JhebxxXRve3dWB927tyNs3tOXZy5swd1C6NgLD68GZ/7SCTF4oL+KRhBQORSXwdFwqLygPX+/cqSv/9T79eVL5eDYumefjknjO4+dw/Ub8/vvvfP/scxyOiuP1jBx++fgTfv3qa96qU8ybCUm84fbx1RbRpPDB9Jk8ohRHli3X50fWruf57j14qf9A3up/EirKpapkXjU5SpHut6bhmiQqrlo5BKji0K2n13iJSMhMdvPIpibcvKh+tWV8Wr8Svn9sIAfWtSbLY+iBeJGhaOBSNHEr6rmssZ5ctxuPVLLuSwMEh0iwo+8NIdZBYiTYJFrnodZzKALDprB361Qcy8YJJdy3sgmPrG3EvRfX4/aF+bQq8VanCc9zRvNyvll0Ekzvxkcty3jIH8ehqDieVCafXnmVJuO57n04oAye8MdyMCqGRwwPh0oq+P3XX/n22ed40hfPc0rxzbZtOv17o8fwgmHwYkoaP7z9T3778SdeqlPMvUrx1qIlOs3LgwZzp1LcpRQPSlmSo1RVmnhJkhTDejShavEo7r1qBu8dWgpfLuCz5+ezdc0ELr34DLasGM1ll4xly4rT2XzRCDYuGc76Cwez6rz+XLqoL3eu7cQlp2cTHyB444wKvrijHed0Sq1+cd0VOPypclxNriEkWITZkhpCcsDochIsxDgrNjKEPJtsh9SGwzCCJDtUtY1Et0FJmo8e5bHM6RPP7BOi8AXe1Ulwgc/LF03r8GvTHL4ty+TH9GRe8kdzj+nWlf/eVrFl4MmuPTQ5D7q93Ovxc6cyOFBcxm+//cZ3zz/PY24/jynF6z166fSf7t7N/UrxQs8+/A58sm+fPt8vaRYt0de+fvZZPt6zh4/37ePL3XtQdWJU1aRBnTm4fxO/f3k1fC8zN5vgqyVwZA58sgD+vRS+mAefzoSPZGZmErw1Hl4dC8+P4LdDp/LtI0M5cntfVo1MJ8GtaFwczRObG3LrvBIyvTYJNStNQzxS1U6MAMEBaIK1irYkN5RQA2VEERWTQGZWJqVlBdRvUIcGDepQVpZDfl4q8QmxmG4Zy4Y+W/p5m1ghU4gNJ/zo3jiDogSDhCjHPQO/LUyTt00XL5oeXnS5edPl4gnTZKdhcKVSvFplSeQj3buzWyl2mS5udHm4QSnuLC3ht99/54tnnmWf4eJ2pbjd4+Ob117nh+++4/rYBF7bsEnnf/jUoVyvlL7Hy0uW8ov03T//zK+//sz3P/3Erz/8gLp/95oqft8HP6+DbxbBv8+Hjxbw65tz+OnwFH58aRI/vTiRn54/m++fHsc3j43g6wND+eL+wXx610CO7O3HO7v6cvi6HvxjSUO65HvITzSY1DOe8wemUxQbmH7THqma6lMQlFgLTimVX0ljV2J0XBotWjbnrLEnsn7JUPZWDeeJm0fwxl2nc+ShUXz40EiO3DeUd+8exBv7TuKpG/rxj82d2HxeJdNHldOrYz6Z6XEhhFsER5DogDSHkyvER7stbSS2i31d98nyP6W4ShlanT5qmhwwTbaYBpsMxQaleHH7Dk3QfT26sUMpqgIQ8m8pLeb7n3/m/SefZKdSmsArJM/FKy1SJ07ii5df4ad/fc31qalsVYotSvHU0mVagg9Mn8aO1BS2ZaZzVVoa6vdfLquCZZrc356bxE1zWzGqdTq9S+LpVhRHx4IYjU75sbTOiaFphl+jMsNP49QoGqZYKEvykuk29EsnuKwZD2cFWuo21Cq21a9P4PMSFeXFHyW/Pn3dzu/1J9Gta1vWLx3NU7dN5etDk/ntuTH88sTJ/PDICXx3oA/fHujDNw/24V/39+Sre3vw5f4efLG/B5/d2ZWP93bmo9s68ekdXfjg9h48saM9l53bgGG988hKDRp3Qam2iNVSXYu6bphlcEJDg4GNDZKiQ/8nyDUNVhuKqw2D5YbBQkPODVaJig30wbf16MYKpVipDDYpg8uUYnvdOnz93Xe898QTbDcMTfxmIb51a378+We++vBDfgRe3LGDTdINKoOlSvHosmXWPU8fxQKluETG8lKW3z+5sArW8dZtXRlU19SuuvDC/hVIhYkUijUsxEX5fPijovD7/fj9UUT7fURH+fRvTHQUsTFReAJj4aycQs6dPoqDt07ix2cmwLMj+P7hvnz7UE9+eKw/3z3cjy/39+b9PT148apOPLK+JfuXV3LXskruW9mcRze25JltrXjtmra8f2snjtzWkTevb8mLOyo5fGUL/nlTax6/rCUrziqmslSk2iqzJlqIdfTH2pkRmMgQ6a+f7WLtyFg2jE2kf/NgIxGIe1WZBo2VYr5hMM9QLDGUJmKJUjx/3bWajA9ffpk3DhzgnYNP8NUrh7muc2eWp6by7S+/8MHzz7HWULpBrBRr3uXin4ee0lL6A3Blz54sU4pVptKEPrBihb7nR2++yasPPcQ7jz/Ovw4fFgleWvXFy2Nom2cVLtpjEOU28QT6RI8eagQd+X9ktbqd7kSvR5NqkxklxEYJqX5iYqKJjYkmLtZPXEwUCXF+4mMsqc3MymfJvNG889B0ePFMfni4D9892oefnjiJT27vzUOrW7FubBnjOmbSrTiO+sk+MjymHs7Z86oyxIk1FJl+Fw2z/PRtnMTZvbPYNKGIh1c34PVrmvPazkqeubwpz2+t5NBljVk7MY+GhbbmqDkhoY2wgDSLj/7i0dnctayca+cWER9tdSO2/1zsii5Ksc4QAgyNC4Rwpbj7omW8/+ab/POVVzjy9lt8/N67fP7Jx1zeozvnxcfz3ssv89zuXZq4hUrpfHOV4rbpM/jsn29z+P57uTA+jvOVYpmp9O+t06dz5K23OPL6a7z3xmv88/Ar/OvTT1BvXd+kamgLkwRTfMMmUV43UT4vPlGX/ihioqOJivJrcqKj/RoWYQ5EBciTY/l/lEWonEv+aA2/JlZ+Y2L8mtjE+GiSE6JJS4rWDpaE2DgmjD6Rtx6aA4fP5MfH+/Pjwf78+4G+HNzYhgUDC2mRFa37uHBNcTzIj3FzctN4Vo3J58FVDXl+W1MOXdqI5y9vyGPrijl3cBIpcUHDMJxgW2UP75zK6ztb8ea1rRneLU1fs9JYz+kqkqfJsaR4nqmYaxpM9XqYFBXFTH8U58dHszA+mln+KGaaJnNNk8Wx0SyK9nGuaTAnQO4C0+ACU3FBdBQXeN0skmuGwSLDYImpmO/1MNfvZ1Gsnwtio5jj97HAH4Vqk6Kq4sXJEWUSrfs/i9jY2BgthcrlJi49naiUZJQQKZIXG0tMTEyAsAB51UQGzyWNhj6WfDHEx0WTEBdNUryf9OQYctJidCxWh5ZNuP/m+fDWTH47NIBfnj2VHx4bzL6FjRnUMEmPlcOJigR7/jf8em0oSfYyu186960o5enL6vPo+gqev6ycvRfk0aWhL5CuJslyPTXWxWMbm2hP161L6mlXr/PerZXBImUwU1nkzjYVUw2DyTL3rRRTlGJaAFOVqk53rnjR5NywMNsQVa+4QGsDS6qF1MWmwYWm4kKX4jxDMUtZkLzye56Uw22oqhivgd8nBo5InUitH19UFHlFhayedjpPLx7HE2cNZFGrxsTHxuCNtkhzkmqRGV1NukWq1RBsghPiY0lJjCUzOYbctFjyUr1kJ3qYPWkEX7+8Ag6P5tfnR8ELw3l4dVtOqZ8UaQJbQypb7p2ZmUndOnWoV6+Chg0a0KB+fcrLyyktKaFOnTrk5uaQmppCbIw0WMuij4TsWBfTT0jjwUtKOLihjAOrSnl0TREzBsZp/7ykiWRZzx2UzYe7O/LeLe0Z0C443hckKcWFhsEKQzE3QNR0Q8g09O9M04IczxBiDMW5jrRC+Cy5ppSW2IuVYq2yLHExyLaYipWGYrFhSfe8ALGSRxqKPFcT7PO4Q/pKkdyU7EwOnT8elg2GaZ2hTyWUFHBNdAzeqCh8fiexFqol2SZZkytq2k9srJ+khBhy0+OoVxBPZVEUnRukcOW6SfDuAn5/YQS8MobP7jyZhf3yI0qsVGxKSjINGjSgffv2dO7UmbZt21LZtKkmVQjNy8sjJyeH3Nxc8vJyKSoqpKS4WEMaQk5ONokJCZZ2ivCMehle1o/N5vH1pTywsoRnLy3l6tnZZCUHhnva4AoSXDfFy+Er2/DR3i48sLEZfp/VF9uNoMQ0mG4aTDEUEwyDCYZiopBsk20qztHHhiZViJkvEPVrKi5yGaxyG2zxGVwTZ3BrsuL2TIO7cwzuyjC4Llax3mtwsdtgiUtUuWKezmtQ5TZQbpdRpYcqgT5UiBG1PLp+HejYAPo04vd+TfmpfhFfxsZwRBm0dbtQDkm1CQ32y9JfWw3AOvZrtZyWGE1pbhx9K+O4YHgprzx0iThT+fXp/prcR1d3ol1acHhkQ8ioKK+gb98+9O/fj27du9G4cWPy8/JISUkhLi5Wl0EsdT2Gdsvkg+0JkyGYWOl+EhISyEhP1/ny8/N1YxFDMPx5ojXO7JjII6tLeGJTPZ7ZUo89i+tQnKOn36rVtT2Wvmh4Lp/s68SR3e1YO6U49H4BtW0Hw9lePDtILjw2S0JvdKCdoUg1FTkeRZ5PUTda0TBB0SxV0SZL0TFX0TlX0SpVURajyPEq0lyKJMPKr0N/tAS7XVXWEMYylDTB0dFcFBfDz34/X6cn86/0ZD6LjuZ1w+RlpRgiVmJAWkMNLkvFB4dA1q8YVUnx0WSlRNMgz8vS0fX49r2r4Iv58IqErQ5j6/gyHYvkrBypxEaNGnLqqacycuRIunTtQkW9CkpKS7VkirRmZWaSlppKUlISCQnxWmuElCXwXqKhZKxtDdm8ulGkp6WRnZ1FcnKyHhmEE92jxM+9S+vy+KYGHNxYwb1r69OgJFH/zzK2rHS5MSaHNjXnvT0d+WRfB9bNbERcYETwZ6GDJyTaVCaAYhX5SYrydEWTHEWLfIO2hQbtixSVuYo6yYrUaCuQwg68qL6X2xUkWKRYfoW801wuPpIxmzK0w1tw0DB5TJm0ktZbPZYNVKa2nIPWs65YPea1xrcpidFkJ3vo1TSDtx9fBl+eB++Mg5eHs3lYrm7ZzhcUVTp2zGhmzJxBnz69adOmDa1atqRVq1Y0b96M+vXqUbduHfLz88jOytJkJSclERcXV93vBw0+G8FrUj5577jYODIzMsjJziY+Lq6Ge7Jhqoe9C+vyTFVDnr2sHo9ua0NZ3XSLBAkQCJDcsSiGl7Y2493dHXl/VzvuWtuMkf3rkp0pwQLH4i+vCZ8ySPEa5MQa1E83aFdgMKBcMaGFYmp7xdSOBoMbKVrlKOomKdKjlZ4H8EtYlB2AZ0uwL+CEELh9PuJdLq4wFE+bBgcMxcPiDlOKNcrAI75jr+Vxqh4iBYZBQamxJEas8thoH2lJURRmxLJvxxR46wyZ9oDXRrB9ZFYNQ6pXr16sXnUJEyeezUknn8SQIYO1FPfv359uXbvSpnUrLdnlZaW6X7VJTktN09IofawQbVn7tsEXtBnkf6KuExMTtdTHx8dpdV1UWEhuTo52vDjLUzfBzZ6FxTy/rREvbWvAfVu7kJ2Vov/njAlvVRDNgbXNeOO6VrywvZKXr2rBnasqufL8pmw5rwVbL2zL9qUdNXZc1JkrV3Tl6ku6s3N1L65d04fr1/Xnxg0ncfOlg7nlsuHsrRrBXTtGc+9VY3n0hvEc2jWRp26ZyPPXjuTQutbcN8vHmgGKUxsbtM1XlCYrMmMsqZcoGh3b7XK5qsSZb827BklWHi/xhsEIZVlxYp0NEzekDBM84sCwVZ8TAW9VQHrlfuJ6jIv24XMbLJ03Gl6dzA+P9eW3g/3YcEqa7itsiRFHyYgRp7Fj+zamT5vG5EkTWbZ0CXNmz2bc2LGcOmQIJ5zQl44dO9CqVUuaN2tGo4YNKS6uq4nJyEgnNSVFS7KQl5iYQGJCvCZTIBIq5Mr/hFBJm5aWSmZmhpbitLQ0rfql0UgjdZJcnODmoRVlvL6zkk92t+CuqoEkJ8RbYTwOqzo71s0Fw3J5fF0FT2yq4P5LSnh8fTnPXN6QF7c35dWrm/PaNS21F+3Ing58cnsnvrirC1/f05V/39ed7x/qyc+P9ubXg33hUD949kR4YQAcHgJvngbvngmfzIEvl8P7y/ns1nbcfKbinA6KbsXWasucOEVKYJWlctlGVoCQINFRIt6hY0qZyal2OwaJDc1r+Zm19GrjxpKGbp1a8+MLc/j+0RP56eBAlvTPDKlAr8/HnDmz2bZ1K3PnzmHn1Vdy0w3XsXnzRpYsXsz0aVM5Y9w4hg8bxoABJ9KufTtKS0u1kSXP1bNMYeNQ6cOl0Ui/K32uEJqVmUFWVqZuDEKsWNyiAQoLCygqLNBdgzSYhg3qaw3gvF+fuj4+vK4JX+xrBY9144pl/fAYJm7tsw6V5vJ0L2d0S2Ht2GxuOreIey4q48GV9XloVQMeX9eIpy+t5IWtLXllR2veuLoNb1/Xng9u7MDHt3Tk092d+XJvZ765qxvf39uLHx7oy08PD+DXxwZYmu+90+D9U+Hbi2ROil8eHsTNYxUT2yl6lSoaZVrLaVP9tgRHIjhAnvzPJa5JmdkJS+eUVJtcPXEQmEyQc3HbJSal8vStY/nhoV78cmgwOyeWVQemCXxeHxMnTmT9hvVccP5C7rnnTh595AB33rGPG66/lk0bN7B8+XLmzz+PE044gYKCglqHOX8EKXN6epoeUpWWllC3bl09hJLjivJyrfrLysqoX78+TRo3ribZ1jJTOyXw9Z5K3r2mHh/s60HvLg2s/0cIFBCIwZMWZZIf56JOglur+/JED/WTPDRI9tAkxUOzNA8t0720y/TSOcdL11wPPQs89Kvj5cRiHycUe+lX4mNwPR9LTojnuXX14JWB8MHp8N5E+GQ1d84vZVxzsQWsNdSiqhO8ToLDZnosKbYk2UmirYqrSXXmc4TW6EhIPQQx9PLNXx49ka/v68GTa5qTF5gktyrOYNiwYZrAKVPPYf/+Ozn4+KM89ugBHn74Qe7Zfxe3376XRYsW0bBhwxoV+Gch7yHquEWL5jRu1EirejHeRPW3a9eWJk0aa7LbtW1LSnJySN5lg9J4eVt9ntpYyr61bYmLs4L0ayP574AYTTLPnudXtEtVrOoXxb/vagvPD4DXRvPGXVMZ3sSjpTc7TpHoVUTLVKZNcDi5NsLPQ8gNECpE2nmdEw1SsGbNG/PV4+P5/K7uHNnVgZ75lsq2/bVt27Rh9uxZnHHGGVx77U7u2X8nBx68j4OPP8KLLz7Hiy88y8SzJ2hCwl/670Bqaqo22rp160bXrl3o0aM7vXv1pF+/E+jUqZN2qLRv10775+08SS6DW+fk8djaYp7YUMKkodbY13aChC/GO1boGasARPJ1XLnEy8k8gccgxW9o8goTDYpiFAu6evn5oZ789uRJ8PI4Fo4opSxB7ACr/5UVI5pgUb3hJNcg3OvTEiq/WhU7CbYn6wNRF16PNdtkuP3csnkoX9/diX890Jt1w/NCXqi8vIxzzjlHV+acObO48ood7Nm9i/vuuZtnnjnEyy+9wEkDB9SoiHA4paa2yj2aZMm7dO3ShdGnn84pg05m2LChjBo5Qht87dq1o2mTJtor5szTtcjHgYsLuXtJAfetraAwJybwfItgm2gnabaDpDpN2GyVlS7o75YFCNK/+1yGnuVL8BmkRAvJBoVJBvUSFLtnFPDbo/347WBv9q6upDg+SLA0DuUyjCpL4mqqaa+QGonscNUcFtJqS2+Pbs35/L5TeH9Pe17Y3IzS6KC1KUMWqcCTTjqZQacMYsF581mzeqWW4gfvv5fHH3uEDu3b1yCjNhyNwGOBGGk9uvdg9swZTJo4gfFnnqmHZ127dqVY99GlejjlzHNe/2TuuaiIh1cWMWuINTa2ybJnnWpD+Bop7eeukUZIlnVZsoBASDZJiDJJizHJiTdI9Sn61/fyxW3t+e7+3jx/TRsq0hXJPivipAbBFoLHtooOIVgk2CY+sHTECoazl5N4dPiq6Y7i1i1D+HRfFz7c25EpHZJCKqdFixaceGJ/7UseP/5MbSUvXnQ+VZdfxl13/YPOnTvVIEFX4B+c/1UMPuUULlx0AaNGjtSuUemD69evpw07McgkTsxOW5zoYu/8XP6xuICds7L0hjFicwRjukLJ1hMV+np47FfoVGQQFumaZJFktyXJ8T6TJL9BjFtRlGxw+KqWfL2/N69f15YGmdYYWNS69i/oPjhCiGooqRaZGmGSbvl8g7FUAnn5Zk2KeOe2XrxzSzseW92YVEfskviDBwwYoCcIunTpzPDhwxk/fjxz58xm44a19OnTp0bF14bjIfhY0orLctjQoQwbeiqdOnXUY22ZoRLfdVFRke6znekvHBDPfcvyuP38HPo0tjRXuDTqYx3U5yAugsTWBptkWWkp6jpKiHZbi/my4lw8v6Mtn/6jOy9tb0FZirVmTNaGaZelEZDgIEFBdW0ZT7aEBqQ1kCaoksNX+8lLmiyf1Yb3bmrNu7e0Y0Gf0DGvDD9atmyphypi2PQ74QROO+005syZw/BhQ2tUuqAGOeJtigkNlfkrsPtJORZvV6+ePbUBKBa22AqFhYWkp6eTlZUVIsXNst3cdm42d1yQz6rTkwJ+4CAx4ZJcLbkB6dT/jyTtNfIEJVmvj3ZZ5c2Kd/HMdnGadOaZyyt1wKNtoOn3EYLdQkxAEkOlN0w6nav59IxN6Io/af1SqKTkOB6/siuv7WzJExsaUxofrBDxJLVu2ZKs7Czq1aunVaAYOCcNPIkxo8doj1N4xYeT0bxVBY/MP5t7Tu5Nj4YVlgMmQrpwx8fxQOaZxfddr6LCmlfOydEuUJFgKaNdLqnM5UOT+ceifG47L4u6qYElLQEjyla9QTUdKr3OOOxIqM4f0ACa6IABJs9Jj3PzZFULHXRwaHNjsuMtO0fKFSTYEWheLbURV/A5pNYRu+w8l5v36ZjLmze059VrWnLpWYUhFVdSUqJVXmxcrFbRTZtW0qZ1a07o21cTHl7RNQg2FLee2xWKcsFw8129CnZ2aU9ZUaiF/ndAnB/i9LCCBlJJiBe/dbx2aUqcmp1uWAsfd1+Yyx2LchnSKnRKMUiU3dceu2quDVplBxpvcoyLRzdV8ub1bXh8Q0MyArsSVNdbKMHHADutI0DdDsKTVQOinlbObMyLWyVysSljAksvBaIFRDVnZ2drSRa1JxXYrFmlHo7Y/bcTNQh2K/YOTOW3qGg+M318rgyIjePL1s04v30LYhODz/urEKu5qI7V74pfW3zZMhMlExpigNrpGmW5uO3cLPYszGPJ0MRAmWWmyUGKs88NqGWn+o6EozaEwLOTYkweWNOYV3e24OG19UiLCQvxrSY4IInOVQVCZPjaXDuqMhKk7/X7fdy6vClPbGjIoyvLaBiIhNCFSUzU3ihx/0mlydiyTlGRnrwXssMrOCI8il29EvjJH8vnZhRfuXx8bbj4VinISOO51s0ZXF4s86A189YCZ//rbFBSkTIZkZSUaM1OyVxzlBWvJsd2OlmLddmZqexZkMuVU1JJjw3m1/d29KU1iPrTsJ4hEnzvygZ6IuOBlaWk1kZwJFRLqy25ejVfMHQ2FJb0lhXG88jGJhzc0IArJueHbEckU3oSSiPj6wyZgxVHf16elmIxbMIrPiLcipv7JPGD38/nhocvXR6+MD18arr1/PU3yuDHgjz2tWhEZXaocfdnIHPb0vfGxEpIUnS1g0ekWQiz0517Yry2pHfPz6BFgR22E+yLBUeVyHCEqPmaKt9uiMkxJvsvrsczlzdg/7I62hES8g5CsLV8xLGMpJrYoDq24SS0+jgQEy03PKlLFi9ubcyTm+oxd4AVSiqQ/8s0nEReSCVJPyaGjBgvMsaUQodXbkS4FXtOSecHv5fPDJPPTBefmG4+tGG4OKIU30f5+KismOWN6pGWEOqgOB7I+0m/K0Tbky9yTSRa6sZOd2rraO5alMO+87MZ3NJp3YcSFE5y+LmTwNobSLB8oqLvuqicpy6tzx2LC2uusqhJsEyvhfazkWCtAgzdFkFuOHtYPs9sKufgulKGtAhOtwmp4hESSZWKSk5O0qE2IsVCdnjF1gqPwf7xRfzg9/CRMvjIdHHEdPGB4eJ9w837pov3ZPGXYfCmUnyZlMBzFWWMzM05LrVtQ6RUuhTb6aO7MZdLX3P6x1sXe7ljQRZ7zsthWp9QOyCSBIZ7so4X9r2F4H2LSzi4vpy95xeQXJsE29KrJdgmt/qa49deWB22el4WUEtrXXFGPg9fUocHL65Dl+Kg0STqraCwUFeUSIMMNcRYkZgokYbwiq0VPpOHzm3Kv2O8vCNLMQ0X7xou3jFMDU2sYfKaYfKKYfK8rLyTdCnJ3JidTZtjeFa4YSflFb9A9YJzl8uKIo0JbmBanOHmljkZ7Do3m2VD7fFwoH93DndsgsOGS7WjtoZg3T8p2mTP+UUcWFXM7vPyj43gaoRcCxDrINV5bIgFbRhsOLuA+5cVcveF+TTOChpY0uJzsnN0Py4VpiMrJMoxI4Mo/3E4LHxuHlrWk09i/bymTN4wTE2o/L5hGrxmGrxsmrxgmDyrDJ4yDQ6ahl4M/ZRp8nJSChclJ5MRwWK3UTvBtvZyaemVMCA7TVaCyY2zheAsLj0jlbhALHVI0LxjMVsI0TXIC0cELRB4rhB864JC7l9Rh1vm5dVOcDi5NoHh1yJuNqal18TndbF9ej73XZTP7QtzKHZs6ikSK2Ex4qe2K0cMFbGmIw2PIkFeyhvl5ZHVg3k/NooXlcHLEulpyK/BiyKxpsEzpsEhw+CgYfCIkGsa3GMY7FeGXvn+qMfD3QmJjE1MxOtYmlobNMESqxZo9LK3h5RZLGkhR9Ik+g12Tk/n5jmZbJuQSkZMoMwOUpxSXO3J0m7LsIVujvTh12zYZUuMNrlpXiH7lxZy4+xsvflNSPmrCdbkhUlrOPGBvadCyA1sjSAEx0aZXDMrl3uX5WtVJTMe1QVJSNB9ra6cgJqW4YYYXVb+mhXrhD2U8fu9HFzTm/fivDyjFM+ahg4MtAg1eVzW5AqxhsFDhsF9hsFdpsE/DIM7DJM9ymCXodijFE/HxLAlIYHoPzDwbIKd7yzDx7jY2GqCozwG26dlcPOcLK6cnKan83S5wyQvRE3Lrx4T1yTwWEkWgq+bW8Adi/K5dkZm7QRXS3GA7CCxYef2Rif6ReXX6ktEFcX5DK6elsXdi/O4fmYWmXHBh4kEi7RKWmn9Vrx0jL4u9wiv1NrginLxwPxSXopx86gyeMwUKVU8ECDzHkOxX8Midp+p2GMa7DZNbjEMbjIMbjYNrjMMtksocKybep6jE2wPj6p35QksiY2NCRLs8xrsnJPNnnlZ3DAjneLkAMG1WNFOosNR2/Xq+8g9A2UTgq+emcee83K5eloGKUcj2Alrf6kgwc5rzpZsGwtCcLzPYOfUDO68MJdbZmdSGHhJQUK8RbBdOVJhUnHSFx+LBFfDa3Lb+FQO+k2938XdhuJO0+B202CvkCmuTMPQ2GUa3GQaXG8aXGsYXGsaXGMaevX9PlHdWR4Wlbr07nw1nuNAdEyMbpTyntUq2mMFz+vYaJmgiHJxw4ICbpufzbVTM8h1NO6aRAWIFMl1GGLHAss7FvSzy6LBbedkcfPcLK44J7U2goP7RQWl2ZLaIOE1r9kE6wcra36y6qxU9i7MYdfcDOplBSVTe69SUqxKCuyBpb1CMTHHR7DP4LYz4jgYbXCbEkJF5RpaOm8xFTebihtMxfVCqKG41lQWqYYQq7hBGeyPM7km36RPjin7SNV8RhikEUp5rXqR9zd1A7UC5a0KjY/xcP15dbn13Gx2TMwgTc8N11TRNRBhHXIooXYDsO6jd3J3jINlDnrrpAxunJ3JFZPTahKsDKNKKj2cYKs/DhDrhHPfKXtLogDBMsG8ZmQyt87LZu/8TNoWB61o6cckxNWuJKkwy9iK0efOQoVbsSHwGlw/ws/9flNvWiJEirq9xkHmTpFYUcNybCiuUYbGHdI4Mk2GZ5q4JeIw7N61PVfiqLWbNlB2eWcpu3N4l5kaxa2LStgzP4dtE9JICgssDCcuEmpVzfY9wiRd7p3gN6malMH1s9LZMTlVf6EmrPwqhGCbyOB5BMPKJjhMguWGCwfEsXteFv9YmMkpLYMOeZmdEoKloiRvtZr2+4/ZitbwKKoGedgbZepNS64ylF6BscNUbDMNtpoG2wylib3ZZehGsN9jciDTxdwMkwzHrjjHAtFSonnshmkTLKMAJ8FlRfHcfXE5/7ggl01j0mosxakhyQ6yIhFr5Qmmtes39JpY7yZVE9O5bkYaOyYl/zHBxwJn+lCSFWPaRLF7Xia3L8hkRv+gJ0vUmqw4EFIlvZ7IcMR4hRWqdrgVm/qZ7PIZeoeZraa1TnaTqdgoO9mYBptNgy3KYK9h8FyKyeUFbpolHbsh50S0P9oiWJc5YIOYpl7yIqMAO137pqk8tLqcOxflc+Ep1rIWDadhFIHIcOI12Q4jKthHBxCmaWRj16qz07l2WjrbhWBH3x9AgOCjkFybBOs8jhkSuWHPYje7Zqdz8+wMVo1Org6PlULJ9Js4NaoJDkBCcWWoEF65EeFWrOthcL3XWgi9wTBYq3ewUaySX9Ngo1Lc5DW5Nd3FiAzZECXCfY4RonVkqtDelE2rao9bN1anq/K0vjk8tKqMuxYXMqVHhI1LA0RWT/CHqdtq6PSONGEEy71CCI42uOysVK6eksq2iUmkVW89YT830AfbJNeQ5vBzMcgCu6g7jSyb4PJEgysmJHPt9DSunZlOVlLQgNJjX3EO2NsVui2CbSdCjUqJBLdiVSeDq7zWindZxS6Qle7LDcU60+DmGJP5iSbpEfrZ40VuXp5evGbPIumNZXw+LdXOMi+b0oAHLy7m/ouKOKVpqGcuRALDCQ2HTXwIucH6dZIrSIw22DI+mSsmJ7F1QmJNgm0JDkcoweGkh24HaBXIKoDsbLN6aCw3zk7hzgsy6NI46M6T1i8zM7ZGcM4716amw19ICF7ZXrHFLbvPGCxRBhcGNju53m2wPMqgifcYtcEfQMboBQX5unz2Mh0hWCQ6OSW5utL9MVHcuLI1+xfnc+cF+TTJCh0V1CqtGrUbYXbe6sAB29By3FsI3jQuie1nJ1I1IZH0+BoSHCTYSaot0U5inemqCXYUxi7QrC5R3Dw7id1zkplzanCmSNLZMzM2wdpwEd/usUqxW7G4hcFa2XgksD1RlfS5XpMTPYaONKyR509CoihtVWxDyi4eOeeEf4P6GTx4aXP2nZ/PNedk6mUjzvsEHRRHIzqCsRXSOAL3CiujhM9uHBPPtrPiuXx8fASCtQRbTu8QggNDoHC17ZTcaukNtC77pgPquLl2chw7JsSyY1YecbFB6bQdHHJfe1xtR5OEL9mMCNn4q5HBFrfBOjGyDIMpboPMY+3DjxHiQpWYLLu89oJ2aaA6stIxF3zOmKY8ubER+5cWsWxwhP7XJtlJsIO40N/whmAd1xZAKJMLm0bHcfmZMVx2ZhwZ4QRrFR2I03VKrr1/csj2u7bKdpLsKIh90+IoRdUoL9vP8nHT3Ew6VAai/kVNBybL7eGG0w0q7svaVLUTst3xhV7ZJ0rR9C8YUDbCpULep2nTJnp3HnvhuOWu9OqdBAS60iUgwOfjptWduW9JIQdWFDKiTYQhn0OC7ftbqtch3SFwNAZbcBxWtLPMQvCG0XFsOSPaIjjhKBLsRAiRDpLDyY1EsKyEO7ejyXWTXewY72PxmaWWZRhYLG1vpqalOGClW0EGQn5siHTUhnBS/k7obZhKS7W0SiSlTCqIoSXnebm5uux22tatSjiwpQ17F+Rx75IcKjJDNUkNUh3Saf8/vA+uzhupIQTS2mnEil43KoZLx0ZpkmsSrPvgmgRrMh39cTgsa1qOaxZMv3iKYvvpLqpOV+xbUkz9iuDiLSFUPFiW0yP42Rx7yGTNMNVQNf8jkI1dJFZbxrnWFg/W7gDSKCV8VqY8g+9qsO78nty3vETHQ22ZmqnXAzkbn0VgqMrV1wPkOYkNSm4wj62aq8kOa9wiwetH+dk42sPmsVFk1iBYvtmgx2cWcXY4Zw040tgEV18Pk2CBbA20oKvBjjMNbpkRzdJpspAs+HBxcogXy5LewHApsKJC1GFiUmKNRvN3IpIGyMrKplu3rjrSRMa/er+PxEQtwWnpaTo4UMpsp2/StJSnr+7FbfNyeHhDOf07WOuIa9w7hMRwMm3hsAkPEKvzBqTcbgwO2PcWgteNjGLDKDebxkaRkRDm15dxsJPg44aj0CE3Vop++QZXjDPZMlKxb1k9mjapW/0/SW9vw2SPha3VFNbqCfmfVLBokfD7WvkjXIuQ7lhRWFDIwIEDdSivkJuWmqL38bClWNR2dlam4xkml100hEMb6nPfRXW4aXlDYv2Ru5Zqgmy1HEl67bTVCFPVdoMIe3chePVpXtaNcLFhTBSZiTUIDhpZkXE08mu2SOfNk03FJX2kHzbZNs7D6tntMd1BI0oMLh2xGIhW1ORqVW2Fx4halCGJGDchhf6b0ayyksGDB1OQn6+D8gWyDkkIFoOwrLRU7+gj657tPL16teGFa/qwd342B7c0YWg/q/GG14FTKoMEhRJbg2DHkCjcsLLz2apbCF5zmo81w002RiJYf1YnogQHYogikWxPWAeOw1uhE72yDLaPNllzquKG2fkMGdAs5OVl6CHTbtaKRXvJjDV0EukV0mUsGr4hip0//NrxQO7ZuVMnvdCssKBAS6/0wRK7LftmSaC+bM5S2bQJSYnBiYWY+BTuvmIMD19cwH0XFXLzqjbERtc+xLMIdkpnBJLt9GE+Bes3VIic6cXRsXK4j7XDDTaP85EV/u1juw/WJFcT7Tx2kKp/rfPq9LUQbB/Ldn3TmxtcNtpg/amKW5e3orQ0+NFHyScSLJKiVzTqiM7A1FwA8jxpBKKya9vK4XjIlmfI/hsDTjxRb2AqlrIYUBKfLTvuSDC+7MAjG5q2a9eGzPTQJaNLF4zl+a2t2XdeBk9vr6R3+9rXRYWQGn69FqFw5ot0Dy3Bgf+JFX3JqV7WDlNceoaX7JRaJDiEZPs4TKpDGoEjTSSCnSjwKlacICQrbjrHx5VL+xAV49xh3eqPZTJCO/MdHi5rnGw5WaQBSBohWrs8j8Xz5XiG9KcNGtTXe2/IykGRUqu/TdU770iMtlbTWVnaoOrRoxvlJUUh30c6aWAvXr35JO5cmMmTmxqwdk6zkP4yEqx6CZXWaoKd/bL9f0c6O791vWZD0QQP9bB6qGLzmVG1EOx8gJPsMHL1Iubq/1vSHJInwsvZ6JlhcOVYg8tHK26dnca8iT1QRtAokfx2jJaOngh4uix3qfUlNC3NhqH/L8MYWTck+13Jr/iGhXxrtz3ZdDxGq3bxOsm6J9mhVvbakC2TJFRX+lcZ8sixhBLJ5IEsTJffhg0bcOKJ/WhUv1RvnWDP7TZs3IDnbhnFgxdJ5Ghd7tvcjJy0oK9dv0fYe9c4t/vjQD8aQp6jLmvkCSPc/p8QvGqYh5VDFBvG+iITbN0kAsHhKjjCeQgivJANcX6c3dDgijMVq05R7F1YwuQxXauHAgLpGoQY6fukb5Z7iuTakmyNmYNRFVqqpQ+Pjw9sbJapCRUjSX51X5qTTWqKtVmppJMGpHe3y0i38gjJ6emWtRwfrz1YvXt3p1G9uiR4Tf3lVSlbYVFd7rv6DA5cXMRdi4t5dnsjerWwNia1cbT3d16PlKaaaJuLGtecaYN1JiE6a4d5WD5Isfb0CCra2QfXhtpIjdQAaiu8/CYog/PaGVSNNdk0XL5dUMGE07uHjI/lRWQD05TkJD3+tH3gtYUPVatwhzGojwMaSI+3A14oaTiy55VIqahkpwSLgSX7Y3Xt3JGcrDRd5uiA5OQVFLH/qok8u7kB/1hczMtby5k+sJYxb9g728fBOgolLjxPTURQ/w6y5Svla4Z5WHaSYs1oHzmpESQ4nLhwVPe3DhJDzsNRy4sKiqIMtp7sYvuZJttOV9y/oh7njBGSQwsm1rRIm0iW7dYUwqz+OUC6w49tRYgEl7va0SI67isQvamn+ZKTtI9Zhl/yK8Ohysqmeh/q5s0r9c64znKUVjTg/mun8tSGety1uA4vXFrOimHWHpVhFRmC8Dqw6+yo/3dAX7f75wj3tyESfPEQL8tPVqwb460mOOjDNsIIDvOL/qkV6REK4rzWOc3gpuEurjrLZO1gxbXTCrlganfik0J3lJPnSp9qbS6aoCcjhEyrXw4aYMEZqeA6ZjsUSFyfsoZICNYNJuB6FIIrKsrp3KmjtpTzcrPxuUPdfO07tuPeK8dwcE2Znil6an0plwyOqxFvFQmWpIY7K2rWj028RWxY/evjoxMs04Orhvm4ZLBi0zgPWck1XLwBguWk+qZBVBtZ4YWshuN6oEDhhXC+jL1HZbskg6U9DDaNMFg+UHHFxAx2LOlH06blNfJJ4J9IoSzE1n1pXJyWTHusbJdRzzE79hkRq1vSyTBM8ov0ym45sgi9WWVTvRlMfl5utSOlmjh3NFPOHsqzNwzXWzPcdkEdDl5SxOIToqu3Pj5apYcjRCrD8oYQa1/7A1KdaFAUzZZxsdqu2XSGh+TAapLq/H6/O/gFcJvUsN9aEU56SOHCLMHAr/MztbLl/OQWBptHGKwYqNg62sMdqzszcUw3/BEcG0KivfhaiJbhkvSrYjzJBLwYaNLX2tIq/a2MZ8XYKioq0BIrFrKMb0UrRHKDNm3Wgms2Tubglnbcdm4a+5cVce/5OYxrEfTAHWvl22SGk+s8ry1tOCKllePTTyxi2zi/JnjFWD/RXmuXner0K2c3rUpOskx9e3wb0XgKIVLICzs/iikfqZA2RGqGlSqqTlNsHKlYIyp7RiGb53eme+eGKHdkN6VY1PaERVy8Rbgez6alVe8eIMTK8lQxqET6ZW5X1HmkcmTlFjBr0iAObD+VRy8p4dZz07lzcSE3TUyje2ENtfeXcLQ6OhbYWjIrJ5WqmfVY2k+xbXwUU05N1eRKVEv1vXfNTqtaN7eV/lSOlTnceRFKrk2kndZ+2NHGan8EQ5l0y1Cs6Gew/jSTJScqVg4yuXFeBevntqVruyId9xSeL+QegXJbY2bri23SVx9d3ZkUFZcwbcIA9l82lAcurs/OyfHsmpfN/RfmsHJAnN7dNfQ54ff4a4hsJUe4FgZ/XAIXz+xK1eholvRT3HRBIZ0aJmqBCfl+07pTVNUdc1NYM6cDjRqJw/zYvUN/N2Sb4TmtDLYPVaweoljWX7H2FJONZ+SwakoDRp9cTr2ydHz+yFIt0JuAHbWBmaRnZtKja0vWnH8ad6zvh3yT4bpJMdw0M4ndczPYNiqBk8vdeuxeM/9/GyYNG9Vn88KB7JyYzCUDFbfNTePSGU1Jki0MXWHvf+kIVXXZMOn/vNx4fiNWzOjGsIEt6NmlKb27VdK7ezP69mhOn+6V9O7WlF5dBU3o0aURPTvXp0enCnp2qkePDqV0a1NItzZ5dG2VTefKNDo0TqZN/XiaF3tolG9QL9ugKEWRKVvO+60Nq2XLW+dXQuTzM4PyDVZ0UaweqFjSXzGzk2JuV8Xa0xJZP76AZWeVM+GUEnq1z6dZo2wK8mT+NpaYOD9Rfh9e+axAtJ/4pDiyctIoryigU7v6jB7SnmXTe7N1Xjuum13GDeckcNWZYuD5uX5KIjvGxHNGMy/pjmUnTkil2SrQa1pfRZEvncg3hNNiZNc5RV6SoiBZUSdVUZyuKMtU1M9RNMg1aJBn0DjfpLKOi+Z1XbQocdOqzEu7ej46NvLTqXEMnZvG07V5Et1bpdC9dRrdW6fTvU0m3dvlMKRvfRZN7sSV81uxfWw0m4cq7jk3mVevGEDv8jhiXY4tDG1Maa2qrh5lsGWUYuXJSntFLj8rnSunFnDNjAJ2Ti9gx5RCtk4uoGpSvsblk/K47OxcLj0rm41nZLFmTCYrR6VzyfBklg9N4sJBiczvF8vs3tFM6x7FWR1cjG6pGNZU0a9c0b5A0TRDvoOg9FKSONMi1rkLfIKh6JyqGN/AYF5nxaI+inO7K85pr5jSQbGgn58Vw1JZNy6X9RPqsm5KPVbPaMzyKZUsn9qc1bNasX5Wa7bMbMaWaQ3ZfHZdqsZnsGG4l4tPsjTEpaMMto/1snqgj1PK3WQeJY5ayBULWnYNkopM9lhlz49VlCUrmmQqmuco2uQrOtWRT/Io+lUoTmqgGNJEMazSYHgzxaiWBmPbmEzoYDKlq4uZPd3MO8HDooFelp7i46IhflYMjWH1iDjWjIpn1ch41o9OYMuZyWw7K4Uto7xas4lReu/5mXy+awjn98/R5ZDGFtL/CgxlVHXINljY3WDzKQaXDlesO1Xp8enqQUqrgOUDrBtKxVxyknW+tL9icT/FBX0VC3op5vdQzOmqmNZJMbm94uy2ijNbKU5vrhjZTDG0iWJgPcUJZQY9ihWtcwzqpxqa5JxoRZJb4ZcvdzqsbIGcF3gNumUbnNZQcVYrxXSR6G6KGZ0UMzoq5nRWTO9oHcv1eT0U5/VQzJPjroqFPRQLe1naYM0gxcqBivndDYY1NGiSYhz1k7pSWdLwRF1L+eLkW0YeRZpPkROjqJOgqEhRNEhTNMqwSJYvoHQOkNyrRNGn1GrYA+srBjVUDG6sGF6pGNNKcVZbxdntFefIu3RVzOqumN1dMVfK30uxsI/iwn6KhX2tut4w1GD3DJOHViewZ0kDhlXGUiTfZ4i21HOIBW3B8kWLBLXPNJjUzOC8jgYLOhrM72BqnNfRZEEnk/M6mczrIDA4t73B7PYms9qZzGhjcE4rg7ObG4yvNBjX1GB0Y4PhDRSDKxSDyg1OLjfoV6zoUWTQMd+gRaaicZqiPEmRFyvfNVAkuhUxpmVZR+pH5Vz6GdkIu3uBYnA9xemVBhNaG0ztoJgpBHdVzOtukTu/m6XeJ7ZRjG1mcHKFolOuojxORSQ13Ei0+3MhV3zSIrnyXSLZjznNr8iOURTEy2d3FCVJFtGNheQsacCKdnmKjvmKLoWK7kUW+hQrBpQpTq4wOKWeNDLFqMYGo5sYjK00OKuFwcRWBlPamMxsbzKvi8miXibL+7nYOMTN1nFuVo1zM66Lh8p0a/PvJL+1P7RIb60EWwhab/Jibr0k1IYlTbVB0rsCaeXYHu/aDww/19fC/LJOhFd+bZDGIFIlEpUbbVAYa1AUpyiIVWT7FSkey6cc0i/9STjJD/+ffT28kRwLnHVj1bs0KpnFMvRHruLdivw4RSPp01MMMqMUWdGylbAiOUCu3fdGKJu6Lryg/w8RK+q/AimHRGrKBzbEKJXvIQlke3/pc0Uta8kN73sD+P8AzY246OBLYdUAAAAASUVORK5CYII=";

  function criarUI() {
    console.log('[LIVECAM_BOOT] building-hud');
    if ($('cv-painel')) return;
    const targetParent = document.body || document.documentElement;
    if (!targetParent) {
      setTimeout(criarUI, 300);
      return;
    }

    const logoHtmlHeader = `<div style="display:flex;align-items:center;gap:8px;min-width:0;"><img src="${LOGO_ICON_BASE64}" style="height:24px;width:auto;object-fit:contain;display:block;flex:none;" alt="Logo" /><span style="font-size:13px;font-weight:900;letter-spacing:0.4px;color:#D4AF37;white-space:nowrap;">LIVECAM INFINITY</span></div>`;

    const painel = document.createElement('div');
    painel.id = 'cv-painel';
    painel.style.cssText = [
      'position:fixed !important', 'top:' + POS_PADRAO.top, 'right:' + POS_PADRAO.right, 'z-index:2147483000 !important',
      'background:#0F0F12 !important', 'color:#fff !important', 'border:1px solid #D4AF37 !important', 'border-radius:12px !important',
      'font:13px/1.4 \'Inter\',system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif !important',
      'box-shadow:0 16px 48px rgba(0,0,0,0.85), 0 0 20px rgba(212,175,55,0.2) !important', 'width:460px !important', 'max-height:min(780px,90vh) !important', 'overflow-y:auto !important', 'overflow-x:hidden !important', 'scrollbar-width:none !important', 'user-select:none !important'
    ].join(';');

    painel.innerHTML = `
      <div id="cv-header" style="position:sticky;top:0;z-index:6;display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:#14141A;border-bottom:1px solid rgba(212,175,55,0.2);cursor:grab;gap:6px;">
        <div>${logoHtmlHeader}</div>
        <div style="display:flex;align-items:center;gap:6px;flex:0 0 auto;"><span id="cv-estado" title="Status da câmera virtual" style="display:flex;align-items:center;gap:4px;font-size:10px;font-weight:700;padding:2px 8px;border-radius:999px;border:1px solid rgba(212,175,55,0.3);background:#181820;color:#D4AF37;"><span id="cv-dot" style="width:7px;height:7px;border-radius:50%;background:#777;display:inline-block;"></span><span id="cv-estado-txt">Inativa</span></span><button id="cv-cfg" title="Configurações / Assinatura" style="width:28px;height:28px;border:1px solid rgba(212,175,55,0.3);border-radius:6px;background:#181820;color:#D4AF37;cursor:pointer;padding:0;display:flex;align-items:center;justify-content:center;">${IC.gear}</button><button id="cv-power" title="Ligar/Desligar Câmera Virtual" style="width:28px;height:28px;border:1px solid rgba(212,175,55,0.3);border-radius:6px;background:#181820;color:#D4AF37;cursor:pointer;padding:0;display:flex;align-items:center;justify-content:center;">${IC.power}</button><button id="cv-min" title="Minimizar Painel" style="width:28px;height:28px;border:1px solid rgba(212,175,55,0.3);border-radius:6px;background:#181820;color:#D4AF37;cursor:pointer;padding:0;display:flex;align-items:center;justify-content:center;">${IC.min}</button></div>
      </div>

      <!-- CONTAINER FLEX DA NAVEGAÇÃO E CONTEÚDO (ETAPA 2) -->
      <div id="cv-body-wrap" style="display:flex;width:100%;height:calc(100% - 48px);min-height:500px;overflow:hidden;">
        
        <!-- MENU LATERAL INTERNO (4 ABAS: ESTÚDIO, ÁUDIO, QUALIDADE, CONFIGURAÇÕES) -->
        <div id="cv-tabs" style="width:88px;flex-shrink:0;background:#121217;border-right:1px solid rgba(212,175,55,0.15);padding:8px 4px;display:flex;flex-direction:column;gap:6px;">
          <button id="cv-tab-btn-live" class="cv-nav-btn" data-tab="cv-area-estudio" style="width:100%;padding:10px 4px;border:0;border-radius:6px;background:#D4AF37;color:#0F0F12;font-size:11px;font-weight:800;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:4px;text-align:center;">
            <span style="font-size:16px;">📹</span>Estúdio
          </button>
          <button id="cv-tab-btn-audio" class="cv-nav-btn" data-tab="cv-area-audio" style="width:100%;padding:10px 4px;border:0;border-radius:6px;background:transparent;color:#A0A0B0;font-size:11px;font-weight:700;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:4px;text-align:center;">
            <span style="font-size:16px;">🎵</span>Áudio
          </button>
          <button id="cv-tab-btn-qual" class="cv-nav-btn" data-tab="cv-area-qualidade" style="width:100%;padding:10px 4px;border:0;border-radius:6px;background:transparent;color:#A0A0B0;font-size:11px;font-weight:700;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:4px;text-align:center;">
            <span style="font-size:16px;">📺</span>Qualidade
          </button>
          <button id="cv-tab-btn-cfg" class="cv-nav-btn" data-tab="cv-area-config" style="width:100%;padding:10px 4px;border:0;border-radius:6px;background:transparent;color:#A0A0B0;font-size:11px;font-weight:700;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:4px;text-align:center;">
            <span style="font-size:16px;">⚙️</span>Config
          </button>
        </div>

        <!-- ÁREA PRINCIPAL COM AS SEÇÕES INTERNAS -->
        <div id="cv-corpo" style="flex:1;min-width:0;padding:12px;overflow-y:auto;">
          
          <!-- SEÇÃO 1: ESTÚDIO -->
          <div id="cv-area-estudio" style="display:block;">
            <h3 style="font-size:13px;font-weight:800;color:#FFFFFF;margin:0 0 10px 0;display:flex;align-items:center;gap:6px;">Câmera Live</h3>
            <div id="cv-palco" style="position:relative;width:212px;aspect-ratio:9/16;margin:0 auto;border-radius:12px;background:#05070F;border:1px solid #D4AF37;box-shadow:0 8px 24px rgba(0,0,0,0.85);overflow:hidden;">
              <video id="cv-preview" playsinline muted autoplay preload="auto" crossorigin="anonymous" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#05070F;display:block;"></video>
              <div id="cv-overlay-stage" style="position:absolute;inset:0;pointer-events:auto;z-index:3;"></div>
              <div id="cv-vazio" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;color:#A0A0B0;font-size:12px;text-align:center;padding:0 18px;line-height:1.4;cursor:pointer;z-index:5;pointer-events:auto;">
                <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#E50914" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" style="opacity:.9;"><rect x="3" y="4" width="18" height="16" rx="3"/><path d="M10 9l5 3-5 3z"/></svg>
                <span>Nenhum vídeo selecionado</span>
                <span id="cv-btn-sel-arquivo" style="font-size:10.5px;color:#0F0F12;font-weight:800;border:1px solid #D4AF37;border-radius:999px;padding:6px 14px;background:#D4AF37;display:inline-flex;align-items:center;gap:6px;cursor:pointer;box-shadow:0 4px 12px rgba(212,175,55,0.3);">${IC.plus} Selecionar Arquivo</span>
              </div>
              <div id="cv-tiktok-badge" style="position:absolute;top:8px;left:8px;display:flex;align-items:center;gap:5px;background:rgba(15,15,18,0.85);backdrop-filter:blur(4px);padding:3px 8px;border-radius:999px;font-size:9px;font-weight:800;color:#D4AF37;border:1px solid rgba(212,175,55,0.3);pointer-events:none;z-index:6;">LIVECAM INFINITY · 9:16</div>
            </div>

            <div id="cv-eco-status" style="display:${modoLeve ? 'flex' : 'none'};align-items:center;justify-content:center;gap:5px;margin-top:6px;padding:4px 8px;background:rgba(0,230,118,.12);border:1px solid rgba(0,230,118,.3);border-radius:8px;font-size:10px;color:#00e676;font-weight:700;text-align:center;">
              ⚡ Modo Leve ECO (Otimizado para 4GB RAM & Dual-Core)
            </div>

            <div id="cv-extra">
              <div id="cv-barra" style="height:6px;background:#181820;border-radius:3px;margin:12px 0 4px;cursor:pointer;position:relative;">
                <div id="cv-buf" style="height:100%;width:0%;background:#282835;border-radius:3px;position:absolute;top:0;left:0;pointer-events:none;"></div>
                <div id="cv-prog" style="height:100%;width:0%;background:linear-gradient(90deg,#E50914,#D4AF37);border-radius:3px;position:absolute;top:0;left:0;pointer-events:none;"></div>
                <div id="cv-tip" style="display:none;position:absolute;bottom:14px;transform:translateX(-50%);background:#0F0F12;color:#FFF;font-size:10px;padding:2px 6px;border-radius:4px;white-space:nowrap;pointer-events:none;box-shadow:0 2px 6px rgba(0,0,0,.5);">0:00</div>
              </div>
              <div style="display:flex;justify-content:space-between;color:#A0A0B0;font-size:10.5px;">
                <span id="cv-tempo">00:00</span><span id="cv-dur">00:00</span>
              </div>

              <!-- SELETOR DE VELOCIDADES DE REPRODUÇÃO (0.5x, 0.75x, 1.0x, 1.25x, 1.5x, 2.0x) -->
              <div style="display:flex;align-items:center;justify-content:space-between;gap:4px;margin-top:8px;padding:6px 8px;background:#14141A;border:1px solid rgba(212,175,55,0.2);border-radius:8px;box-sizing:border-box;">
                <span style="font-size:10.5px;color:#D4AF37;font-weight:700;display:flex;align-items:center;gap:3px;flex:0 0 auto;">${IC.speed}Velocidade:</span>
                <div id="cv-speed-btns" style="display:flex;gap:3px;flex:1;min-width:0;justify-content:flex-end;">
                  <button class="cv-spd-btn" data-spd="0.5" style="padding:3px 2px;border:1px solid rgba(212,175,55,0.2);border-radius:4px;background:#181820;color:#CCC;font-size:9.5px;font-weight:700;cursor:pointer;flex:1;min-width:0;text-align:center;">0.5x</button>
                  <button class="cv-spd-btn" data-spd="0.75" style="padding:3px 2px;border:1px solid rgba(212,175,55,0.2);border-radius:4px;background:#181820;color:#CCC;font-size:9.5px;font-weight:700;cursor:pointer;flex:1;min-width:0;text-align:center;">0.75x</button>
                  <button class="cv-spd-btn" data-spd="1" style="padding:3px 2px;border:1px solid #E50914;border-radius:4px;background:#D4AF37;color:#0F0F12;font-size:9.5px;font-weight:800;cursor:pointer;flex:1;min-width:0;text-align:center;">1.0x</button>
                  <button class="cv-spd-btn" data-spd="1.25" style="padding:3px 2px;border:1px solid rgba(212,175,55,0.2);border-radius:4px;background:#181820;color:#CCC;font-size:9.5px;font-weight:700;cursor:pointer;flex:1;min-width:0;text-align:center;">1.25x</button>
                  <button class="cv-spd-btn" data-spd="1.5" style="padding:3px 2px;border:1px solid rgba(212,175,55,0.2);border-radius:4px;background:#181820;color:#CCC;font-size:9.5px;font-weight:700;cursor:pointer;flex:1;min-width:0;text-align:center;">1.5x</button>
                  <button class="cv-spd-btn" data-spd="2" style="padding:3px 2px;border:1px solid rgba(212,175,55,0.2);border-radius:4px;background:#181820;color:#CCC;font-size:9.5px;font-weight:700;cursor:pointer;flex:1;min-width:0;text-align:center;">2.0x</button>
                </div>
              </div>

              <!-- REPETIÇÃO CONTÍNUA DA PLAYLIST -->
              <button id="cv-loop" class="cv-sec" style="width:100%;margin-top:8px;padding:8px 10px;border:1px solid rgba(212,175,55,0.2);border-radius:8px;background:#14141A;color:#FFF;cursor:pointer;display:flex;align-items:center;justify-content:space-between;"><span style="display:flex;align-items:center;gap:8px;font-size:11px;">${IC.infinito} Repetição Contínua</span><span id="cv-loop-sw" style="font-size:10px;font-weight:800;padding:2px 8px;border-radius:999px;background:#D4AF37;color:#0F0F12;">ON</span></button>

              <!-- BOTÃO ADICIONAR VÍDEO(S) -->
              <button id="cv-add" style="width:100%;margin-top:8px;padding:10px;border:0;border-radius:8px;background:#D4AF37;color:#0F0F12;font-weight:800;font-size:12.5px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;box-shadow:0 4px 12px rgba(212,175,55,0.25);">${IC.plus} Adicionar Vídeos</button>
              <input id="cv-arquivo" type="file" accept="video/*" multiple style="display:none;">
              <div id="cv-lista" style="max-height:110px;overflow-y:auto;margin-top:8px;"></div>
              <div id="cv-status" style="margin-top:6px;color:#A0A0B0;white-space:pre-wrap;font-size:11px;">Nenhum vídeo carregado.</div>

              <!-- BOTÕES PRINCIPAIS DE AÇÃO -->
              <button id="cv-toggle" style="width:100%;margin-top:10px;padding:12px;border:0;border-radius:8px;background:#E50914;color:#FFF;font-weight:800;font-size:13.5px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;box-shadow:0 4px 14px rgba(229,9,20,0.4);transition:all .2s ease;">${IC.play} INICIAR TRANSMISSÃO</button>
              <button id="cv-restart" class="cv-sec" style="width:100%;margin-top:8px;padding:10px;border:1px solid #D4AF37;border-radius:8px;background:#181820;color:#D4AF37;font-weight:700;font-size:12px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;">Reiniciar Vídeo</button>

              <!-- 10. CARD RECOLHÍVEL: ELEMENTOS DA LIVE -->
              <div id="cv-card-elementos" style="margin-top:12px;border:1px solid rgba(212,175,55,0.25);border-radius:10px;background:#14141A;padding:10px;box-sizing:border-box;">
                <div id="cv-card-elementos-header" style="display:flex;align-items:center;justify-content:space-between;cursor:pointer;user-select:none;padding:2px 0;">
                  <span style="font-size:12px;font-weight:800;color:#FFF;display:flex;align-items:center;gap:6px;">
                    <span style="font-size:13px;color:#D4AF37;">🎨</span> Elementos da Live (Texto & Imagem)
                  </span>
                  <span id="cv-card-elementos-toggle-icon" style="font-size:11px;color:#D4AF37;font-weight:800;">▲</span>
                </div>
                <div id="cv-card-elementos-body" style="margin-top:10px;display:block;">
                  <div style="display:flex;gap:6px;">
                    <button id="cv-add-txt" class="cv-sec" style="flex:1;">${IC.type} Adicionar Texto</button>
                    <label id="cv-add-img" for="cv-img-file" class="cv-sec" style="flex:1;cursor:pointer;user-select:none;" tabindex="0">${IC.image} Adicionar Imagem</label>
                  </div>
                  <input id="cv-img-file" type="file" accept="image/*" style="display:none;">

                  <div id="cv-txt-editor-box" style="display:none;margin-top:10px;padding:10px;background:#060813;border:1px solid rgba(212,175,55,.3);border-radius:10px;box-shadow:inset 0 2px 6px rgba(0,0,0,.5);">
                    <div style="font-size:11px;font-weight:700;color:#D4AF37;margin-bottom:6px;display:flex;justify-content:space-between;align-items:center;">
                      <span>✏️ Editor de Texto (TikTok Live Studio)</span>
                      <span id="cv-txt-fechar" style="cursor:pointer;color:#A0A0B0;">✕</span>
                    </div>
                    <input id="cv-txt-val" type="text" placeholder="Digite o texto da Live..." style="width:100%;box-sizing:border-box;padding:8px;background:#14141A;border:1px solid #28304c;border-radius:8px;color:#fff;font-size:12px;outline:none;margin-bottom:8px;" />
                    <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
                      <span style="font-size:10.5px;color:#A0A0B0;flex:1;">Cor da Letra:</span>
                      <input id="cv-txt-color" type="color" value="#ffffff" style="width:30px;height:26px;border:0;border-radius:4px;cursor:pointer;background:none;" />
                    </div>
                    <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:8px;">
                      <button id="cv-txt-bg-btn" style="flex:1;padding:6px;border:1px solid #28304c;border-radius:8px;background:#181820;color:#fff;font-size:10.5px;cursor:pointer;display:flex;align-items:center;justify-content:space-between;">
                        <span>Estilo Fundo:</span>
                        <span id="cv-txt-bg-sw" style="font-size:9.5px;font-weight:800;padding:2px 6px;border-radius:999px;background:linear-gradient(135deg,#e50914 0%,#ff4b2b 100%);color:#fff;">COM FUNDO</span>
                      </button>
                      <input id="cv-txt-bgcolor" type="color" value="#e50914" style="width:30px;height:26px;border:0;border-radius:4px;cursor:pointer;background:none;" />
                    </div>
                    <div style="display:flex;align-items:center;gap:6px;margin-bottom:10px;">
                      <span style="font-size:10.5px;color:#A0A0B0;flex:1;">Tamanho da Fonte:</span>
                      <input id="cv-txt-size" type="range" min="16" max="72" value="36" style="flex:1;accent-color:#e50914;cursor:pointer;" />
                    </div>
                    <button id="cv-txt-salvar" style="width:100%;padding:9px;border:0;border-radius:8px;background:linear-gradient(135deg,#e50914 0%,#ff4b2b 60%,#f5af19 100%);color:#fff;font-weight:800;font-size:12px;cursor:pointer;">✨ Inserir Texto na Live</button>
                  </div>

                  <div id="cv-overlay-list" style="margin-top:8px;max-height:160px;overflow-y:auto;"></div>
                </div>
              </div>

            </div>
          </div>

          <!-- SEÇÃO 3: ÁUDIO -->
          <div id="cv-area-audio" style="display:none;" class="lci-audio-page">
            <h3 style="font-size:13px;font-weight:800;color:#FFFFFF;margin:0 0 10px 0;display:flex;align-items:center;gap:6px;">Ferramentas de Áudio</h3>

            <!-- CARD 1: ÁUDIO DO VÍDEO ORIGINAL -->
            <div style="border:1px solid rgba(212,175,55,0.25);border-radius:10px;background:#14141A;padding:12px;margin-bottom:10px;" class="lci-audio-card">
              <div style="font-size:11.5px;font-weight:800;color:#D4AF37;margin-bottom:8px;display:flex;align-items:center;gap:6px;" class="lci-audio-title">
                <span>🎵 Áudio do Vídeo Original</span>
              </div>
              <button id="cv-ouvir" class="cv-audio" style="width:100%;padding:10px;border:1px solid rgba(212,175,55,0.2);border-radius:8px;background:#181820;color:#CCC;cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:8px;">
                <span style="display:flex;align-items:center;gap:8px;"><span id="cv-ouvir-ic" style="display:inline-flex;align-items:center;color:#A0A0B0;">${IC.volOff}</span><span style="text-align:left;line-height:1.2;font-size:11.5px;">Ouvir áudio no PC<br><span style="font-size:10px;color:#A0A0B0;">som em transmissão</span></span></span>
                <span id="cv-ouvir-sw" style="font-size:10px;font-weight:800;padding:2px 8px;border-radius:999px;background:#181820;color:#A0A0B0;border:1px solid rgba(212,175,55,0.2);">OFF</span>
              </button>
            </div>

            <!-- CARD 2: TRILHA MP3 EXTERNA -->
            <div id="cv-audsep-card" style="border:1px solid rgba(212,175,55,0.25);border-radius:10px;background:#14141A;padding:12px;margin-bottom:10px;" class="lci-audio-card">
              <div style="font-size:11.5px;font-weight:800;color:#D4AF37;margin-bottom:8px;display:flex;align-items:center;gap:6px;" class="lci-audio-title">
                <span>🎼 Trilha MP3 Externa</span>
              </div>
              <div id="cv-audsep" style="display:flex;align-items:center;justify-content:space-between;gap:8px;cursor:pointer;padding:4px 0;">
                <span style="display:flex;align-items:center;gap:8px;text-align:left;font-size:11.5px;">${IC.volOn}<span style="line-height:1.2;">Usar áudio separado<br><span id="cv-audsep-nome" style="font-size:10px;color:#A0A0B0;font-weight:400;">nenhum áudio carregado</span></span></span>
                <span id="cv-audsep-sw" style="font-size:10px;font-weight:800;padding:2px 8px;border-radius:999px;background:#181820;color:#A0A0B0;border:1px solid rgba(212,175,55,0.2);">OFF</span>
              </div>
              <div style="display:flex;gap:6px;margin-top:10px;">
                <button id="cv-audsep-add" style="flex:1;padding:9px;border:0;border-radius:8px;background:#D4AF37;color:#0F0F12;font-weight:800;font-size:11.5px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;box-shadow:0 4px 12px rgba(212,175,55,0.25);">${IC.plus} Selecionar Trilha MP3</button>
                <button id="cv-audsep-del" style="flex:0 0 auto;width:38px;border:1px solid rgba(229,9,20,0.4);border-radius:8px;background:#181820;color:#E50914;font-weight:800;font-size:13px;cursor:pointer;" title="Remover trilha">✕</button>
              </div>
              <div id="cv-audsep-loop" style="display:flex;align-items:center;justify-content:space-between;margin-top:10px;padding:6px 8px;border:1px solid rgba(212,175,55,0.15);border-radius:6px;background:#181820;cursor:pointer;font-size:11px;color:#FFF;font-weight:600;">
                <span style="display:flex;align-items:center;gap:6px;">${IC.infinito} Loop de áudio</span>
                <span id="cv-audsep-loop-sw" style="font-size:10px;font-weight:800;padding:2px 8px;border-radius:999px;background:#181820;color:#A0A0B0;border:1px solid rgba(212,175,55,0.2);">OFF</span>
              </div>

              <div id="cv-audsep-shuf" style="display:flex;align-items:center;justify-content:space-between;margin-top:6px;padding:6px 8px;border:1px solid rgba(212,175,55,0.15);border-radius:6px;background:#181820;cursor:pointer;font-size:11px;color:#FFF;font-weight:600;" title="Fatia o áudio em trechos inteligentes e embaralha a ordem das frases/trechos a cada reprodução">
                <span style="display:flex;align-items:center;gap:6px;color:#D4AF37;">${IC.shuffle} Embaralhar Áudio (Anti-Detecção)</span>
                <span id="cv-audsep-shuf-sw" style="font-size:10px;font-weight:800;padding:2px 8px;border-radius:999px;background:#181820;color:#A0A0B0;border:1px solid rgba(212,175,55,0.2);">OFF</span>
              </div>

              <input id="cv-audsep-file" type="file" accept="audio/*" style="display:none;">
            </div>

            <!-- CARD 3: SINCRONIZAÇÃO -->
            <div id="cv-synccard" style="border:1px solid rgba(212,175,55,0.25);border-radius:10px;background:#14141A;padding:12px;margin-bottom:10px;" class="lci-audio-card">
              <div style="font-size:11.5px;font-weight:800;color:#D4AF37;margin-bottom:8px;display:flex;align-items:center;gap:6px;" class="lci-audio-title">
                <span>🔄 Sincronização</span>
              </div>
              <div id="cv-autosync" style="display:flex;align-items:center;justify-content:space-between;gap:8px;cursor:pointer;padding:4px 0;">
                <span style="display:flex;align-items:center;gap:8px;text-align:left;font-size:11.5px;">${IC.sync}<span style="line-height:1.2;">Sincronizar áudio<br><span style="font-size:10px;color:#A0A0B0;font-weight:400;">Correção de delay automática</span></span></span>
                <span id="cv-autosync-sw" style="font-size:10px;font-weight:800;padding:2px 8px;border-radius:999px;background:#181820;color:#A0A0B0;border:1px solid rgba(212,175,55,0.2);">OFF</span>
              </div>
              <div id="cv-syncrow" style="display:flex;align-items:center;gap:8px;margin-top:10px;">
                <span style="font-size:11px;color:#A0A0B0;white-space:nowrap;">Intervalo</span>
                <input id="cv-syncint" type="number" min="5" step="5" style="width:48px;background:#181820;color:#FFF;border:1px solid rgba(212,175,55,0.25);border-radius:6px;padding:4px;font-size:11.5px;text-align:center;outline:none;">
                <span style="color:#A0A0B0;font-size:11px;">segundos</span>
                <button id="cv-sync" style="margin-left:auto;display:flex;align-items:center;gap:5px;padding:6px 12px;border:1px solid #D4AF37;border-radius:6px;background:#181820;color:#D4AF37;font-size:11px;font-weight:700;cursor:pointer;white-space:nowrap;">${IC.sync} Forçar Sincronização</button>
              </div>
            </div>

            <!-- CARD 4: MICROFONE E EFEITOS -->
            <div style="border:1px solid rgba(212,175,55,0.25);border-radius:10px;background:#14141A;padding:12px;margin-bottom:10px;" class="lci-audio-card">
              <div style="font-size:11.5px;font-weight:800;color:#D4AF37;margin-bottom:8px;display:flex;align-items:center;gap:6px;" class="lci-audio-title">
                <span>🎙️ Microfone e Efeitos</span>
              </div>
              <button id="cv-mic" class="cv-sec" style="width:100%;padding:10px;border:1px solid rgba(212,175,55,0.2);border-radius:8px;background:#181820;color:#FFF;cursor:pointer;font-size:11.5px;font-weight:700;display:flex;align-items:center;justify-content:center;gap:6px;">${IC.micOff} Abrir microfone (falar)</button>
              <div style="display:flex;align-items:center;gap:8px;margin-top:10px;">
                <span style="font-size:11px;color:#A0A0B0;white-space:nowrap;">Volume FX</span>
                <input id="cv-fxvol" type="range" min="0" max="100" value="20" style="flex:1;accent-color:#D4AF37;cursor:pointer;">
                <span id="cv-fxval" style="font-size:11px;color:#D4AF37;font-weight:700;width:36px;text-align:right;">20%</span>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:10px;">
                <button id="cv-sala" class="cv-sec" style="padding:8px;border:1px solid rgba(212,175,55,0.2);border-radius:6px;background:#181820;color:#CCC;font-size:11px;font-weight:600;cursor:pointer;">Ruído de sala</button>
                <button id="cv-resp" class="cv-sec" style="padding:8px;border:1px solid rgba(212,175,55,0.2);border-radius:6px;background:#181820;color:#CCC;font-size:11px;font-weight:600;cursor:pointer;">Respiração</button>
                <button id="cv-micvar" class="cv-sec" style="padding:8px;border:1px solid rgba(212,175,55,0.2);border-radius:6px;background:#181820;color:#CCC;font-size:11px;font-weight:600;cursor:pointer;">Telefone</button>
                <button id="cv-clique" class="cv-sec" style="padding:8px;border:1px solid rgba(212,175,55,0.2);border-radius:6px;background:#181820;color:#CCC;font-size:11px;font-weight:600;cursor:pointer;">Cliques</button>
              </div>
              <div style="display:flex;align-items:center;gap:6px;margin-top:10px;">
                <button id="cv-auto" class="cv-sec" style="flex:1;padding:8px 10px;border:1px solid rgba(212,175,55,0.2);border-radius:6px;background:#181820;color:#FFF;font-size:11px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:space-between;"><span style="display:flex;align-items:center;gap:6px;">${IC.sync} Automático</span><span id="cv-auto-sw" style="font-size:10px;font-weight:800;padding:2px 8px;border-radius:999px;background:#181820;color:#A0A0B0;border:1px solid rgba(212,175,55,0.2);">OFF</span></button>
                <select id="cv-fxint" title="Intervalo para disparo dos efeitos sonoros" style="flex:0 0 auto;background:#181820;color:#FFF;border:1px solid rgba(212,175,55,0.25);border-radius:6px;padding:7px;font-size:11px;font-weight:700;cursor:pointer;outline:none;">
                  <option value="30">30s</option>
                  <option value="60" selected>1 min</option>
                  <option value="120">2 min</option>
                  <option value="180">3 min</option>
                  <option value="300">5 min</option>
                </select>
              </div>
            </div>
          </div>

          <!-- SEÇÃO 4: QUALIDADE E DESEMPENHO -->
          <div id="cv-area-qualidade" style="display:none;" class="lci-quality-page">
            <h3 style="font-size:13px;font-weight:800;color:#FFFFFF;margin:0 0 2px 0;" class="lci-quality-header">Qualidade e Desempenho</h3>
            <p style="font-size:11px;color:#A0A0B0;margin:0 0 12px 0;">Selecione o perfil ideal para a sua transmissão.</p>

            <!-- SELECT ORIGINAL PRESERVADO COMO SELEÇÃO REAL DE VERDADE -->
            <select id="cv-qualidade-sel" style="display:none;">
              <option value="leve">LEVE — 540p / 20 FPS</option>
              <option value="equilibrado">EQUILIBRADO — 720p / 24 FPS</option>
              <option value="alta">ALTA — 1080p / 30 FPS</option>
            </select>

            <!-- 3 CARDS DE PERFIL VERTICIS -->
            <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:12px;">

              <!-- PERFIL 1: LEVE -->
              <div id="cv-prof-card-leve" class="lci-quality-card" style="border:1px solid rgba(212,175,55,0.15);border-radius:10px;background:#14141A;padding:12px;cursor:pointer;transition:all .2s ease;">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
                  <div style="display:flex;align-items:center;gap:8px;">
                    <div id="cv-prof-radio-leve" class="lci-quality-radio" style="width:16px;height:16px;border-radius:50%;border:2px solid #A0A0B0;display:flex;align-items:center;justify-content:center;box-sizing:border-box;">
                      <div id="cv-prof-dot-leve" style="width:8px;height:8px;border-radius:50%;background:transparent;"></div>
                    </div>
                    <span style="font-size:12px;font-weight:800;color:#FFF;">Leve</span>
                  </div>
                  <div style="display:flex;align-items:center;gap:6px;">
                    <span style="font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px;background:#181820;color:#D4AF37;border:1px solid rgba(212,175,55,0.2);">540 × 960 / 20 FPS</span>
                    <span id="cv-prof-badge-leve" style="display:none;font-size:9.5px;font-weight:800;padding:2px 6px;border-radius:999px;background:#D4AF37;color:#0F0F12;">ATIVO</span>
                  </div>
                </div>
                <div style="font-size:10.5px;color:#A0A0B0;line-height:1.35;margin-left:24px;" class="lci-quality-description">
                  Menor consumo de recursos para computadores básicos.
                </div>
              </div>

              <!-- PERFIL 2: EQUILIBRADO -->
              <div id="cv-prof-card-equilibrado" class="lci-quality-card" style="border:1px solid rgba(212,175,55,0.15);border-radius:10px;background:#14141A;padding:12px;cursor:pointer;transition:all .2s ease;">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
                  <div style="display:flex;align-items:center;gap:8px;">
                    <div id="cv-prof-radio-equilibrado" class="lci-quality-radio" style="width:16px;height:16px;border-radius:50%;border:2px solid #A0A0B0;display:flex;align-items:center;justify-content:center;box-sizing:border-box;">
                      <div id="cv-prof-dot-equilibrado" style="width:8px;height:8px;border-radius:50%;background:transparent;"></div>
                    </div>
                    <span style="font-size:12px;font-weight:800;color:#FFF;">Equilibrado</span>
                  </div>
                  <div style="display:flex;align-items:center;gap:6px;">
                    <span style="font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px;background:#181820;color:#D4AF37;border:1px solid rgba(212,175,55,0.2);">720 × 1280 / 24 FPS</span>
                    <span id="cv-prof-badge-equilibrado" style="display:none;font-size:9.5px;font-weight:800;padding:2px 6px;border-radius:999px;background:#D4AF37;color:#0F0F12;">ATIVO</span>
                  </div>
                </div>
                <div style="font-size:10.5px;color:#A0A0B0;line-height:1.35;margin-left:24px;" class="lci-quality-description">
                  Equilíbrio entre qualidade, estabilidade e desempenho.
                </div>
              </div>

              <!-- PERFIL 3: ALTA DEFINIÇÃO -->
              <div id="cv-prof-card-alta" class="lci-quality-card" style="border:1px solid rgba(212,175,55,0.15);border-radius:10px;background:#14141A;padding:12px;cursor:pointer;transition:all .2s ease;">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
                  <div style="display:flex;align-items:center;gap:8px;">
                    <div id="cv-prof-radio-alta" class="lci-quality-radio" style="width:16px;height:16px;border-radius:50%;border:2px solid #A0A0B0;display:flex;align-items:center;justify-content:center;box-sizing:border-box;">
                      <div id="cv-prof-dot-alta" style="width:8px;height:8px;border-radius:50%;background:transparent;"></div>
                    </div>
                    <span style="font-size:12px;font-weight:800;color:#FFF;">Alta Definição</span>
                  </div>
                  <div style="display:flex;align-items:center;gap:6px;">
                    <span style="font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px;background:#181820;color:#D4AF37;border:1px solid rgba(212,175,55,0.2);">1080 × 1920 / 30 FPS</span>
                    <span id="cv-prof-badge-alta" style="display:none;font-size:9.5px;font-weight:800;padding:2px 6px;border-radius:999px;background:#D4AF37;color:#0F0F12;">ATIVO</span>
                  </div>
                </div>
                <div style="font-size:10.5px;color:#A0A0B0;line-height:1.35;margin-left:24px;" class="lci-quality-description">
                  Maior qualidade de imagem para computadores compatíveis.
                </div>
              </div>

            </div>

            <!-- CARD MODO LEVE / MODO ECO -->
            <div id="cv-leve-card" style="border:1px solid rgba(212,175,55,0.25);border-radius:10px;background:#14141A;padding:12px;margin-bottom:10px;" class="lci-quality-eco">
              <div id="cv-leve" style="display:flex;align-items:center;justify-content:space-between;gap:8px;cursor:pointer;">
                <span style="display:flex;align-items:center;gap:8px;text-align:left;font-size:11.5px;color:#FFF;font-weight:700;">
                  <span style="line-height:1.2;">Modo Leve / Modo Eco<br><span style="font-size:10px;color:#A0A0B0;font-weight:400;">Otimização adicional para computadores com recursos limitados.</span></span>
                </span>
                <span id="cv-leve-sw" style="font-size:10px;font-weight:800;padding:3px 9px;border-radius:999px;background:#181820;color:#A0A0B0;border:1px solid rgba(212,175,55,0.2);">DESATIVADO</span>
              </div>
            </div>

          </div>

          <!-- SEÇÃO 5: CONFIGURAÇÕES -->
          <div id="cv-area-config" style="display:none;">
            <div id="cv-config" style="display:block;">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
                <button id="cv-voltar-cfg" title="Voltar" style="display:none;width:30px;height:30px;border:1px solid #28304c;border-radius:999px;background:#141829;color:#c3cbe8;cursor:pointer;padding:0;align-items:center;justify-content:center;">${IC.back}</button>
                <strong style="font-size:15px;display:flex;align-items:center;gap:8px;color:#eef1ff;"><span class="cv-ic">${IC.gear}</span>Minha Licença Infinity</strong>
              </div>
              <div style="background:#111425;border:1px solid rgba(255,204,0,.25);border-radius:14px;padding:14px;font-size:12px;line-height:1.7;margin-bottom:10px;">
                <div><span style="color:#8791bd;">Status:</span> <b style="color:#00e676;">● Licença Ativa</b></div>
                <div style="margin-top:8px;"><span style="color:#8791bd;">Titular:</span><br><b style="word-break:break-all;color:#e2e8ff;">${ASSINATURA.email || 'Cliente Valora Negócios'}</b></div>
                <div style="margin-top:8px;"><span style="color:#8791bd;">Chave:</span><br><b style="font-family:monospace;color:#ffcc00;word-break:break-all;">${mascararChaveLicenca(ASSINATURA.key)}</b></div>
                <div style="margin-top:8px;"><span style="color:#8791bd;">Validade:</span> <b style="color:#ff4b2b;">${fmtData(ASSINATURA.exp)}</b></div>
                <div style="margin-top:12px;padding-top:10px;border-top:1px solid #1f2744;display:flex;align-items:center;justify-content:space-between;">
                  <span style="color:#eef1ff;font-weight:700;display:flex;align-items:center;gap:4px;">🚀 Modo Leve (PC 4GB RAM):</span>
                  <button id="cv-toggle-modoleve" style="padding:4px 10px;border-radius:20px;font-size:11px;font-weight:800;cursor:pointer;border:1px solid rgba(255,204,0,.3);${modoLeve ? 'background:#00e676;color:#000;' : 'background:#242c46;color:#ccc;'}">${modoLeve ? 'ATIVADO ●' : 'DESATIVADO'}</button>
                </div>
              </div>
              <div style="text-align:center;color:#5a6390;font-size:11px;margin-top:14px;">LiveCam Infinity · versão ${VERSAO}</div>
            </div>
          </div>

        </div>
      </div>


      </div>`;

    const st = document.createElement('style');
    st.textContent = '.cv-sec{display:flex;align-items:center;justify-content:center;gap:8px;padding:10px;border:1.5px solid #28304c;border-radius:10px;background:#141829;color:#e2e8ff;cursor:pointer;font-size:12px;font-weight:600;transition:all .2s ease}.cv-sec:hover{border-color:#ffcc00;color:#fff}.cv-ic{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;border-radius:8px;background:#191e33;color:#ffcc00;flex:none}#cv-min:hover,#cv-cfg:hover,#cv-voltar-cfg:hover{background:#1a2038}.cv-audio:hover{border-color:#ffcc00}#cv-lista::-webkit-scrollbar{width:6px}#cv-lista::-webkit-scrollbar-thumb{background:#28304c;border-radius:3px}#cv-painel::-webkit-scrollbar{width:0;height:0;display:none}';
    painel.appendChild(st);
    targetParent.appendChild(painel);

    // Navegação de Abas Laterais (Etapa 2)
    const navBtns = painel.querySelectorAll('.cv-nav-btn');
    function ativarAba(targetId) {
      navBtns.forEach(btn => {
        const tid = btn.getAttribute('data-tab');
        const sec = $(tid);
        if (tid === targetId) {
          btn.style.background = '#D4AF37';
          btn.style.color = '#0F0F12';
          btn.style.fontWeight = '800';
          if (sec) sec.style.display = 'block';
        } else {
          btn.style.background = 'transparent';
          btn.style.color = '#A0A0B0';
          btn.style.fontWeight = '700';
          if (sec) sec.style.display = 'none';
        }
      });
    }

    navBtns.forEach(btn => {
      btn.onclick = () => {
        const targetId = btn.getAttribute('data-tab');
        ativarAba(targetId);
      };
    });

    const elemHeader = $('cv-card-elementos-header');
    if (elemHeader) {
      elemHeader.onclick = () => {
        const body = $('cv-card-elementos-body');
        const icon = $('cv-card-elementos-toggle-icon');
        if (body) {
          const isHidden = (body.style.display === 'none');
          body.style.display = isHidden ? 'block' : 'none';
          if (icon) icon.textContent = isHidden ? '▲' : '▼';
        }
      };
    }

    const selQual = $('cv-qualidade-sel');
    if (selQual) {
      selQual.value = qualidadeAtual;
      selQual.onchange = (e) => {
        const novaQual = e.target.value;
        console.log('[LIVECAM QUALIDADE] Alteração disparada no select:', novaQual);
        mudarQualidadeTransmissao(novaQual);
      };
    }

    // Programmatic click bindings for the 3 quality cards (bypassing CSP inline restrictions)
    ['leve', 'equilibrado', 'alta'].forEach(key => {
      const card = $('cv-prof-card-' + key);
      if (card) {
        card.onclick = () => {
          if (ativo) {
            status('⚠️ Para alterar a qualidade, encerre a transmissão e inicie novamente.');
            return;
          }
          const sel = $('cv-qualidade-sel');
          if (sel) {
            console.log('[LIVECAM CARD CLICK]', key, '| Valor anterior:', sel.value);
            sel.value = key;
            sel.dispatchEvent(new Event('change', { bubbles: true }));
          }
        };
      }
    });

    atualizarQualidadeUI();


    videoEl = $('cv-preview');
    videoEl.addEventListener('ended', proximo);
    videoEl.addEventListener('timeupdate', atualizarBarra);
    videoEl.addEventListener('progress', atualizarBuffer);
    videoEl.addEventListener('playing', () => { const v = $('cv-vazio'); if (v) v.style.display = 'none'; });
    videoEl.addEventListener('play', () => { atualizarToggle(); atualizarEstado(); });
    videoEl.addEventListener('pause', () => { atualizarToggle(); atualizarEstado(); });

    $('cv-syncint').value = String(syncIntervalS);

    try {
      const pos = JSON.parse(localStorage.getItem('lc-pos2') || 'null');
      if (pos) { painel.style.left = pos.left; painel.style.top = pos.top; painel.style.right = 'auto'; painel.style.bottom = 'auto'; }
    } catch (e) {}

    const header = $('cv-header');
    let drag = null;
    header.addEventListener('mousedown', (e) => {
      if (['cv-min', 'cv-power', 'cv-cfg'].includes(e.target.id)) return;
      const r = painel.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      header.style.cursor = 'grabbing'; e.preventDefault();
    });
    document.addEventListener('mousemove', (e) => {
      if (!drag) return;
      let x = Math.min(Math.max(0, e.clientX - drag.dx), window.innerWidth - painel.offsetWidth);
      let y = Math.min(Math.max(0, e.clientY - drag.dy), window.innerHeight - 40);
      painel.style.left = x + 'px'; painel.style.top = y + 'px'; painel.style.right = 'auto'; painel.style.bottom = 'auto';
    });
    document.addEventListener('mouseup', () => {
      if (!drag) return; drag = null; header.style.cursor = 'grab';
      try { localStorage.setItem('lc-pos2', JSON.stringify({ left: painel.style.left, top: painel.style.top })); } catch (e) {}
    });

    $('cv-min').onclick = () => {
      const ex = $('cv-body-wrap'), b = $('cv-min'), palco = $('cv-palco');
      const minimizando = ex.style.display !== 'none';
      ex.style.display = minimizando ? 'none' : 'flex';
      if (palco) palco.style.width = minimizando ? '116px' : '212px';
      b.textContent = minimizando ? '+' : '‒';
      b.title = minimizando ? 'Expandir' : 'Minimizar';
    };
    $('cv-power').onclick = () => { if (ativo) desligar(); else ligar(); };
    $('cv-cfg').onclick = () => { ativarAba('cv-area-config'); };
    
    // Ouvintes de clique para Selecionar Arquivo do computador
    $('cv-add').onclick = () => abrirSeletorArquivo();
    {
      const _vz = $('cv-vazio');
      if (_vz) _vz.onclick = (e) => { e.stopPropagation(); abrirSeletorArquivo(); };
      const _btnSel = $('cv-btn-sel-arquivo');
      if (_btnSel) _btnSel.onclick = (e) => { e.stopPropagation(); abrirSeletorArquivo(); };
    }
    $('cv-arquivo').onchange = (e) => { if (e.target.files.length) addArquivos(e.target.files); e.target.value = ''; };
    
    $('cv-toggle').onclick = () => {
      resumeMix();
      if (!videoEl.src) { ligar(); return; }
      if (videoEl.paused || userPaused) {
        userPaused = false;
        videoEl.play().catch(() => {});
        if (audioSepEl && audioSepOn) { try { audioSepEl.play().catch(()=>{}); } catch(x){} }
      } else {
        userPaused = true;
        origHTMLPause.call(videoEl);
        if (audioSepEl && audioSepOn) { try { audioSepEl.pause(); } catch(x){} }
      }
      atualizarToggle();
      atualizarEstado();
    };

    $('cv-restart').onclick = () => { if (videoEl.src) { videoEl.currentTime = 0; videoEl.play().catch(() => {}); } };
    
    // Eventos dos botões de Velocidade de Reprodução
    document.querySelectorAll('.cv-spd-btn').forEach(btn => {
      btn.onclick = () => {
        const rate = parseFloat(btn.getAttribute('data-spd')) || 1.0;
        aplicarVelocidade(rate);
      };
    });
    atualizarSpeedUI();

    $('cv-sync').onclick = () => {
      const b = $('cv-sync'); if (!b) return;
      const temVideo = videoEl && videoEl.src && videoEl.duration;
      ressincronizar(true);
      if (b.__cvT) clearTimeout(b.__cvT);
      if (!b.__cvHtml) b.__cvHtml = b.innerHTML;
      b.innerHTML = IC.sync + (temVideo ? ' Sincronizado!' : ' Sem vídeo');
      b.style.opacity = '0.85';
      b.__cvT = setTimeout(() => { b.innerHTML = b.__cvHtml; b.style.opacity = '1'; }, 1400);
    };

    // Eventos do Editor de Texto Estilo TikTok Live Studio
    $('cv-add-txt').onclick = () => {
      abrirEditorTextoInline(null);
    };
    const fecharTxtBtn = $('cv-txt-fechar');
    if (fecharTxtBtn) fecharTxtBtn.onclick = fecharEditorTextoInline;

    const bgBtn = $('cv-txt-bg-btn');
    if (bgBtn) {
      bgBtn.onclick = () => {
        const sw = $('cv-txt-bg-sw');
        const isBg = sw.textContent === 'COM FUNDO';
        sw.textContent = isBg ? 'SEM FUNDO' : 'COM FUNDO';
        sw.style.background = isBg ? '#1c223a' : 'linear-gradient(135deg,#e50914 0%,#ff4b2b 100%)';
        sw.style.color = isBg ? '#8791bd' : '#fff';
      };
    }

    $('cv-txt-salvar').onclick = () => {
      const txtVal = ($('cv-txt-val').value || '').trim();
      if (!txtVal) return;
      const fontColor = $('cv-txt-color').value || '#ffffff';
      const bgColor = $('cv-txt-bgcolor').value || '#e50914';
      const hasBg = $('cv-txt-bg-sw').textContent === 'COM FUNDO';
      const fontSize = parseInt($('cv-txt-size').value, 10) || 36;

      if (editingTextOverlay) {
        editingTextOverlay.text = txtVal;
        editingTextOverlay.fontColor = fontColor;
        editingTextOverlay.bgColor = bgColor;
        editingTextOverlay.hasBg = hasBg;
        editingTextOverlay.fontSize = fontSize;
      } else {
        const ov = {
          id: 'txt_' + Date.now(),
          type: 'text',
          text: txtVal,
          x: 0.15,
          y: 0.12,
          w: 0.70,
          h: 0.08,
          fontColor: fontColor,
          bgColor: bgColor,
          hasBg: hasBg,
          fontSize: fontSize,
          visible: true
        };
        overlays.push(ov);
        selectedOverlayId = ov.id;
      }

      fecharEditorTextoInline();
      notificarAlteracaoOverlays();
    };

    const imgFile = $('cv-img-file');
    const addImgBtn = $('cv-add-img');
    if (addImgBtn) {
      addImgBtn.onkeydown = (e) => {
        if ((e.key === 'Enter' || e.key === ' ') && imgFile) {
          e.preventDefault();
          imgFile.click();
        }
      };
    }
    if (imgFile) imgFile.onchange = (e) => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      const imgUrl = URL.createObjectURL(f);
      const imgEl = new Image();
      imgEl.src = imgUrl;
      imgEl.onload = () => {
        const ov = {
          id: 'img_' + Date.now(),
          type: 'image',
          imgUrl: imgUrl,
          imgEl: imgEl,
          x: 0.25,
          y: 0.70,
          w: 0.50,
          h: 0.15,
          visible: true
        };
        overlays.push(ov);
        selectedOverlayId = ov.id;
        notificarAlteracaoOverlays();
      };
      imgFile.value = '';
    };

    $('cv-ouvir').onclick = () => { monOn = !monOn; initMix(); resumeMix(); conectarVideoNoMix(); try { if (gMonitor) gMonitor.gain.value = monOn ? 1 : 0; } catch (x) {} try { localStorage.setItem('lc-mon', monOn ? '1' : '0'); } catch (x) {} atualizarAudioBtn(); };
    const _mic = $('cv-mic'); if (_mic) _mic.onclick = async () => {
      _mic.disabled = true;
      const on = await toggleMic();
      _mic.disabled = false;
      _mic.innerHTML = on ? IC.micOn + ' Falando… (clique p/ fechar)' : IC.micOff + ' Abrir microfone (falar)';
      _mic.style.borderColor = on ? '#E50914' : 'rgba(212,175,55,0.2)';
      _mic.style.color = on ? '#0F0F12' : '#FFF';
      _mic.style.background = on ? '#D4AF37' : '#181820';
    };
    const _mkFx = (id, fn) => { const b = $(id); if (b) b.onclick = () => { fn(); b.style.opacity = '0.55'; setTimeout(() => { b.style.opacity = '1'; }, 140); }; };
    _mkFx('cv-sala', fxSalaBurst);
    _mkFx('cv-resp', fxRespiracao);
    _mkFx('cv-micvar', fxTelefone);
    _mkFx('cv-clique', fxClique);
    const _fxv = $('cv-fxvol'); if (_fxv) _fxv.oninput = (e) => { const v = parseInt(e.target.value, 10) || 0; fxVol = v / 100; try { if (gFx) gFx.gain.value = fxVol; } catch (x) {} const l = $('cv-fxval'); if (l) l.textContent = v + '%'; };
    const _asAdd = $('cv-audsep-add'), _asFile = $('cv-audsep-file'), _asTog = $('cv-audsep');
    const pintaAS2 = () => {
      const sw = $('cv-audsep-sw');
      if (sw) {
        sw.textContent = audioSepOn ? 'ON' : 'OFF';
        sw.style.background = audioSepOn ? '#D4AF37' : '#181820';
        sw.style.color = audioSepOn ? '#0F0F12' : '#A0A0B0';
        sw.style.borderColor = audioSepOn ? '#E50914' : 'rgba(212,175,55,0.2)';
      }
      const c = $('cv-audsep-card');
      if (c) c.style.borderColor = audioSepOn ? '#D4AF37' : 'rgba(212,175,55,0.25)';
    };
    if (_asAdd) _asAdd.onclick = () => { if (_asFile) _asFile.click(); };
    if (_asFile) _asFile.onchange = (e) => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      audioSepFileObj = f;
      audioSepSlices = [];
      try { if (audioSepURL) URL.revokeObjectURL(audioSepURL); } catch (x) {}
      audioSepURL = URL.createObjectURL(f);
      if (!audioSepEl) audioSepEl = new Audio();
      audioSepEl.src = audioSepURL;
      audioSepEl.loop = audSepLoop;
      audioSepReady = true;
      audioSepOn = true;
      const nm = $('cv-audsep-nome');
      if (nm) {
        nm.style.color = '#D4AF37';
        nm.textContent = f.name.length > 26 ? f.name.slice(0, 24) + '…' : f.name;
      }
      aplicarAudioSep();
      pintaAS2();
    };
    if (_asTog) _asTog.onclick = () => {
      if (!audioSepReady) {
        const nm = $('cv-audsep-nome');
        if (nm) {
          nm.style.color = '#E50914';
          nm.textContent = 'adicione um áudio primeiro';
          setTimeout(() => { nm.style.color = '#A0A0B0'; nm.textContent = 'nenhum áudio carregado'; }, 1600);
        }
        return;
      }
      audioSepOn = !audioSepOn;
      aplicarAudioSep();
      pintaAS2();
    };
    pintaAS2();
    const _asDel = $('cv-audsep-del');
    if (_asDel) _asDel.onclick = () => { audioSepOn = false; audioSepReady = false; audioSepFileObj = null; audioSepSlices = []; if (gAudioSep) gAudioSep.gain.value = 0; if (audioSepEl) { try { audioSepEl.pause(); audioSepEl.removeAttribute('src'); audioSepEl.load(); } catch (e) {} } try { if (audioSepURL) URL.revokeObjectURL(audioSepURL); } catch (x) {} audioSepURL = null; try { if (gVideo && actx) gVideo.gain.value = micOn ? 0.15 : 1.0; } catch (e) {} const nm = $('cv-audsep-nome'); if (nm) { nm.style.color = '#A0A0B0'; nm.textContent = 'nenhum áudio carregado'; } if (_asFile) _asFile.value = ''; pintaAS2(); };
    const _asLoop = $('cv-audsep-loop');
    const pintaLoopAS = () => {
      const sw = $('cv-audsep-loop-sw');
      if (sw) {
        sw.textContent = audSepLoop ? 'ON' : 'OFF';
        sw.style.background = audSepLoop ? '#D4AF37' : '#181820';
        sw.style.color = audSepLoop ? '#0F0F12' : '#A0A0B0';
        sw.style.borderColor = audSepLoop ? '#E50914' : 'rgba(212,175,55,0.2)';
      }
    };
    if (_asLoop) _asLoop.onclick = () => { audSepLoop = !audSepLoop; if (audioSepEl) audioSepEl.loop = audSepLoop; try { localStorage.setItem('lc-audseploop', audSepLoop ? '1' : '0'); } catch (x) {} pintaLoopAS(); };
    pintaLoopAS();

    // Eventos do Embaralhador de Áudio Anti-Detecção
    const _asShuf = $('cv-audsep-shuf');
    const pintaShufAS = () => {
      const sw = $('cv-audsep-shuf-sw');
      if (sw) {
        sw.textContent = audioSepEmbaralhar ? 'ON' : 'OFF';
        sw.style.background = audioSepEmbaralhar ? '#D4AF37' : '#181820';
        sw.style.color = audioSepEmbaralhar ? '#0F0F12' : '#A0A0B0';
        sw.style.borderColor = audioSepEmbaralhar ? '#E50914' : 'rgba(212,175,55,0.2)';
      }
    };
    if (_asShuf) {
      _asShuf.onclick = () => {
        audioSepEmbaralhar = !audioSepEmbaralhar;
        try { localStorage.setItem('lc-audshuf', audioSepEmbaralhar ? '1' : '0'); } catch (e) {}
        pintaShufAS();
        if (audioSepOn && audioSepReady) {
          aplicarAudioSep();
        }
      };
    }
    pintaShufAS();

    const _leve = $('cv-leve');
    const _tLeve = $('cv-toggle-modoleve');
    const pintaLeve = () => {
      const sw = $('cv-leve-sw');
      if (sw) {
        sw.textContent = modoLeve ? 'ATIVADO' : 'DESATIVADO';
        sw.style.background = modoLeve ? '#D4AF37' : '#181820';
        sw.style.color = modoLeve ? '#0F0F12' : '#A0A0B0';
        sw.style.borderColor = modoLeve ? '#E50914' : 'rgba(212,175,55,0.2)';
      }
      const c = $('cv-leve-card');
      if (c) c.style.borderColor = modoLeve ? '#D4AF37' : 'rgba(212,175,55,0.25)';
      const ecoPill = $('cv-eco-status');
      if (ecoPill) ecoPill.style.display = modoLeve ? 'flex' : 'none';
      if (_tLeve) {
        _tLeve.textContent = modoLeve ? 'ATIVADO ●' : 'DESATIVADO';
        _tLeve.style.background = modoLeve ? '#D4AF37' : '#242c46';
        _tLeve.style.color = modoLeve ? '#0F0F12' : '#ccc';
      }
    };
    if (_leve) _leve.onclick = () => { modoLeve = !modoLeve; try { localStorage.setItem('lc-modoleve', modoLeve ? '1' : '0'); } catch (x) {} pintaLeve(); };
    if (_tLeve) _tLeve.onclick = () => { modoLeve = !modoLeve; try { localStorage.setItem('lc-modoleve', modoLeve ? '1' : '0'); } catch (x) {} pintaLeve(); };
    pintaLeve();
    const _auto = $('cv-auto'), _fxint = $('cv-fxint');
    const pintaAuto = () => {
      const sw = document.getElementById('cv-auto-sw');
      if (sw) {
        sw.textContent = fxAuto ? 'ON' : 'OFF';
        sw.style.background = fxAuto ? '#D4AF37' : '#181820';
        sw.style.color = fxAuto ? '#0F0F12' : '#A0A0B0';
        sw.style.borderColor = fxAuto ? '#E50914' : 'rgba(212,175,55,0.2)';
      }
      if (_auto) _auto.style.borderColor = fxAuto ? '#D4AF37' : 'rgba(212,175,55,0.2)';
    };
    function proxAuto() {
      if (fxAutoTimer) { clearTimeout(fxAutoTimer); fxAutoTimer = null; }
      if (!fxAuto) return;
      const base = fxAutoIntervalS * 1000, jit = base * 0.4;
      const wait = Math.max(3000, base - jit + Math.random() * 2 * jit);
      fxAutoTimer = setTimeout(() => { const pool = [fxSalaBurst, fxRespiracao, fxTelefone, fxClique]; if (fxSeqI >= fxSeq.length) { fxSeq = pool.slice(); for (let i = fxSeq.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const tmp = fxSeq[i]; fxSeq[i] = fxSeq[j]; fxSeq[j] = tmp; } fxSeqI = 0; } fxSeq[fxSeqI++](); proxAuto(); }, wait);
    }
    if (_fxint) { _fxint.value = String(fxAutoIntervalS); _fxint.onchange = (e) => { fxAutoIntervalS = parseInt(e.target.value, 10) || 60; try { localStorage.setItem('lc-fxint', String(fxAutoIntervalS)); } catch (x) {} if (fxAuto) proxAuto(); }; }
    if (_auto) _auto.onclick = () => { fxAuto = !fxAuto; if (fxAuto) { fxSeq = []; fxSeqI = 0; proxAuto(); } else { if (fxAutoTimer) { clearTimeout(fxAutoTimer); fxAutoTimer = null; } } pintaAuto(); };
    pintaAuto();
    const _loop = $('cv-loop'); if (_loop) {
      const pintaLoop = () => { const sw = $('cv-loop-sw'); if (sw) { sw.textContent = loopInfinito ? 'ON' : 'OFF'; sw.style.background = loopInfinito ? '#D4AF37' : '#181820'; sw.style.color = loopInfinito ? '#0F0F12' : '#A0A0B0'; } _loop.style.borderColor = loopInfinito ? '#D4AF37' : 'rgba(212,175,55,0.2)'; };
      pintaLoop();
      _loop.onclick = () => { loopInfinito = !loopInfinito; try { localStorage.setItem('lc-loop', loopInfinito ? '1' : '0'); } catch (x) {} pintaLoop(); };
    }
    const _as = $('cv-autosync');
    const pintaAS = () => {
      const sw = $('cv-autosync-sw');
      if (sw) {
        sw.textContent = autoSync ? 'ON' : 'OFF';
        sw.style.background = autoSync ? '#D4AF37' : '#181820';
        sw.style.color = autoSync ? '#0F0F12' : '#A0A0B0';
        sw.style.borderColor = autoSync ? '#E50914' : 'rgba(212,175,55,0.2)';
      }
      const card = $('cv-synccard');
      if (card) card.style.borderColor = autoSync ? '#D4AF37' : 'rgba(212,175,55,0.25)';
      const row = $('cv-syncrow');
      if (row) row.style.opacity = autoSync ? '1' : '0.55';
    };
    if (_as) _as.onclick = () => { autoSync = !autoSync; try { localStorage.setItem('lc-autosync2', autoSync ? '1' : '0'); } catch (x) {} reprogramarSync(); pintaAS(); };
    pintaAS();
    const aplicarInt = (e) => {
      let v = parseInt(e.target.value, 10);
      if (!v || v < 5) v = 5;
      syncIntervalS = v; e.target.value = v;
      try { localStorage.setItem('lc-syncint', String(syncIntervalS)); } catch (x) {}
      reprogramarSync();
    };
    $('cv-syncint').onchange = aplicarInt;
    $('cv-syncint').onblur = aplicarInt;
    reprogramarSync();

    const barra = $('cv-barra');
    barra.onclick = (e) => {
      const tot = totalDur(); if (!tot) return;
      const r = barra.getBoundingClientRect();
      seekGlobal(Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)) * tot);
    };
    barra.onmousemove = (e) => {
      const tip = $('cv-tip'); const tot = totalDur(); if (!tip || !tot) return;
      const r = barra.getBoundingClientRect();
      const ratio = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
      tip.textContent = fmt(ratio * tot);
      tip.style.left = (ratio * r.width) + 'px';
      tip.style.display = 'block';
    };
    barra.onmouseleave = () => { const tip = $('cv-tip'); if (tip) tip.style.display = 'none'; };

    atualizarToggle(); atualizarEstado(); atualizarAudioBtn();
    renderOverlayDOM();
    renderOverlayListUI();
  }

  function atualizarSpeedUI() {
    document.querySelectorAll('.cv-spd-btn').forEach(btn => {
      const rate = parseFloat(btn.getAttribute('data-spd')) || 1.0;
      if (Math.abs(rate - velocidadeRate) < 0.01) {
        btn.style.background = '#D4AF37';
        btn.style.color = '#0F0F12';
        btn.style.fontWeight = '800';
        btn.style.borderColor = '#E50914';
      } else {
        btn.style.background = '#181820';
        btn.style.color = '#CCC';
        btn.style.fontWeight = '700';
        btn.style.borderColor = 'rgba(212,175,55,0.2)';
      }
    });
  }

  function atualizarToggle() {
    const b = $('cv-toggle'); if (!b) return;
    const tocando = videoEl && !videoEl.paused && videoEl.src && !userPaused;
    if (tocando) {
      b.innerHTML = IC.pause + ' PAUSAR TRANSMISSÃO';
      b.style.background = '#D4AF37';
      b.style.color = '#0F0F12';
      b.style.boxShadow = '0 4px 14px rgba(212,175,55,.4)';
    } else if (userPaused) {
      b.innerHTML = IC.play + ' RETOMAR TRANSMISSÃO';
      b.style.background = '#E50914';
      b.style.color = '#FFF';
      b.style.boxShadow = '0 4px 14px rgba(229,9,20,.4)';
    } else {
      b.innerHTML = IC.play + ' INICIAR TRANSMISSÃO';
      b.style.background = '#E50914';
      b.style.color = '#FFF';
      b.style.boxShadow = '0 4px 14px rgba(229,9,20,.4)';
    }
  }

  function atualizarEstado() {
    const dot = $('cv-dot'), txt = $('cv-estado-txt'), pill = $('cv-estado'), pw = $('cv-power');
    if (!dot) return;
    const on = ativo && videoEl && videoEl.src && !videoEl.paused;
    const pausada = ativo && videoEl && videoEl.src && videoEl.paused;
    if (on) { dot.style.background = '#00e676'; txt.textContent = 'Ativa'; pill.style.color = '#00e676'; pill.style.borderColor = 'rgba(0,230,118,.4)'; }
    else if (pausada) { dot.style.background = '#ffcc00'; txt.textContent = 'Pausada'; pill.style.color = '#ffcc00'; pill.style.borderColor = 'rgba(255,204,0,.4)'; }
    else { dot.style.background = '#777'; txt.textContent = 'Inativa'; pill.style.color = '#9aa'; pill.style.borderColor = '#28304c'; }
    if (pw) {
      if (ativo) { pw.style.color = '#fff'; pw.style.background = '#8a0a12'; pw.style.borderColor = '#e50914'; pw.title = 'Desligar Câmera Virtual'; }
      else { pw.style.color = '#fff'; pw.style.background = '#141829'; pw.style.borderColor = '#28304c'; pw.title = 'Ligar Câmera Virtual'; }
    }
  }

  function atualizarAudioBtn() {
    const ic = $('cv-ouvir-ic'), sw = $('cv-ouvir-sw'), btn = $('cv-ouvir');
    if (!ic) return;
    const ligado = monOn;
    if (ligado) {
      ic.innerHTML = IC.volOn; ic.style.color = '#D4AF37';
      sw.textContent = 'ON'; sw.style.background = '#D4AF37'; sw.style.color = '#0F0F12'; sw.style.borderColor = '#E50914';
      btn.style.borderColor = '#D4AF37'; btn.style.color = '#FFF'; btn.style.background = '#14141A';
    } else {
      ic.innerHTML = IC.volOff; ic.style.color = '#A0A0B0';
      sw.textContent = 'OFF'; sw.style.background = '#181820'; sw.style.color = '#A0A0B0'; sw.style.borderColor = 'rgba(212,175,55,0.2)';
      btn.style.borderColor = 'rgba(212,175,55,0.2)'; btn.style.color = '#CCC'; btn.style.background = '#181820';
    }
  }

  function mascararChaveLicenca(chave) {
    const texto = String(chave || '').trim();
    if (!texto) return '—';
    const final = texto.slice(-4);
    return final ? `••••-••••-••••-${final}` : '••••-••••-••••';
  }

  function fmtData(ms) { if (!ms) return '—'; try { var d = new Date(ms); return ('0' + d.getDate()).slice(-2) + '/' + ('0' + (d.getMonth() + 1)).slice(-2) + '/' + d.getFullYear(); } catch (e) { return '—'; } }

  function fmt(s) {
    if (!isFinite(s)) return '0:00';
    const m = Math.floor(s / 60), ss = Math.floor(s % 60);
    return m + ':' + String(ss).padStart(2, '0');
  }

  function durItem(i) {
    const it = playlist[i]; if (!it) return 0;
    if (i === idxAtual && videoEl && isFinite(videoEl.duration)) return videoEl.duration;
    return it.dur || 0;
  }
  function totalDur() { let s = 0; for (let i = 0; i < playlist.length; i++) s += durItem(i); return s; }
  function baseAntes() { let s = 0; for (let i = 0; i < idxAtual; i++) s += durItem(i); return s; }
  function elapsedGlobal() { return baseAntes() + (videoEl && isFinite(videoEl.currentTime) ? videoEl.currentTime : 0); }

  function seekGlobal(g) {
    let acc = 0;
    for (let i = 0; i < playlist.length; i++) {
      const d = durItem(i);
      if (g <= acc + d || i === playlist.length - 1) {
        const off = Math.max(0, d ? Math.min(d - 0.1, g - acc) : 0);
        if (i === idxAtual) { if (videoEl && isFinite(videoEl.duration)) videoEl.currentTime = off; }
        else { const p = tocar(i); if (p && p.then) p.then(() => { try { videoEl.currentTime = off; } catch (e) {} }); }
        return;
      }
      acc += d;
    }
  }

  function atualizarBarra() {
    if (!videoEl || !videoEl.duration) return;
    const tot = totalDur() || videoEl.duration;
    const el = elapsedGlobal();
    $('cv-prog').style.width = (Math.min(1, el / tot) * 100) + '%';
    $('cv-tempo').textContent = fmt(el);
    $('cv-dur').textContent = fmt(tot);
  }

  function atualizarBuffer() {
    const buf = $('cv-buf');
    if (!buf || !videoEl || !videoEl.duration || !videoEl.buffered.length) return;
    const tot = totalDur() || videoEl.duration;
    const fim = baseAntes() + videoEl.buffered.end(videoEl.buffered.length - 1);
    buf.style.width = (Math.min(1, fim / tot) * 100) + '%';
  }

  function renderPlaylist() {
    const vz = $('cv-vazio'); if (vz) vz.style.display = playlist.length ? 'none' : 'flex';
    const lista = $('cv-lista');
    if (!lista) return;
    lista.innerHTML = '';
    playlist.forEach((item, i) => {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:center;gap:6px;padding:6px 8px;border-radius:6px;margin-top:4px;cursor:pointer;' +
        (i === idxAtual ? 'background:#181820;border:1px solid #D4AF37;color:#D4AF37;font-weight:700;' : 'background:#14141A;border:1px solid rgba(212,175,55,0.1);color:#A0A0B0;');
      const nome = document.createElement('span');
      nome.textContent = (i === idxAtual ? '▶ ' : '') + 'Vídeo ' + (i + 1) + (item.dur ? ' · ' + fmt(item.dur) : '');
      nome.style.cssText = 'flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11.5px;';
      nome.onclick = () => tocar(i);
      const x = document.createElement('span');
      x.textContent = '✕'; x.style.cssText = 'color:#A0A0B0;padding:0 4px;font-size:11px;cursor:pointer;';
      x.onmouseenter = () => { x.style.color = '#E50914'; };
      x.onmouseleave = () => { x.style.color = '#A0A0B0'; };
      x.onclick = (e) => { e.stopPropagation(); removerItem(i); };
      row.appendChild(nome); row.appendChild(x);
      lista.appendChild(row);
    });
  }

  function status(msg) { const el = $('cv-status'); if (el) el.textContent = msg; }

  let iniciado = false;
  function iniciarPainel() {
    if (iniciado) return;
    iniciado = true;
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', criarUI);
    else criarUI();
  }

  window.addEventListener('message', function (e) {
    if (e && e.data && e.data.source === 'livecam-infinity-gate' && e.data.licensed) {
      if (e.data.version) VERSAO = e.data.version;
      ASSINATURA = { email: e.data.email || '', key: e.data.key || '', exp: e.data.exp || 0 };
      iniciarPainel();
    }
  });

  function enviarPingGate() {
    if (!iniciado) {
      window.postMessage({ source: 'livecam-infinity-injector-ping' }, '*');
    }
  }
  enviarPingGate();
  var pingInterval = setInterval(function () {
    if (iniciado) {
      clearInterval(pingInterval);
    } else {
      enviarPingGate();
    }
  }, 500);

})();
