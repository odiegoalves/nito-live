'use strict';

/* ===== Live Infinity — Service Worker (Manifest V3 + ntfy.sh Plain Text Engine + Renewal & Recovery Handler) ===== */

// Escutar clique no ícone da extensão para abrir a Central de Comando
chrome.action.onClicked.addListener((tab) => {
  if (tab && tab.id) {
    chrome.tabs.sendMessage(tab.id, { type: 'live-infinity-show' }, () => {
      if (chrome.runtime.lastError) {
        // Ignorar se a aba não possuir o content script ativo
      }
    });
  }
});

// Abertura segura das páginas oficiais (Renovação & Recuperação) em nova aba
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && (message.type === 'LIVE_INFINITY_OPEN_RENEWAL_PAGE' || message.action === 'renew-subscription')) {
    chrome.tabs.create({
      url: 'https://liveinfinitysite.vercel.app/',
      active: true
    })
      .then(() => {
        sendResponse({ ok: true });
      })
      .catch((error) => {
        sendResponse({
          ok: false,
          error: error ? error.message : 'Não foi possível abrir o site de renovação.'
        });
      });
    return true;
  }

  if (message && (message.type === 'LIVE_INFINITY_OPEN_RECOVERY_PAGE' || message.action === 'recover-key')) {
    chrome.tabs.create({
      url: 'https://api.valoranegocios.com.br/ativar-liveinfinity',
      active: true
    })
      .then(() => {
        sendResponse({ ok: true });
      })
      .catch((error) => {
        sendResponse({
          ok: false,
          error: error ? error.message : 'Não foi possível abrir a página de recuperação.'
        });
      });
    return true;
  }
});

// Normalizador estrito de tópicos
function normalizeNtfyTopic(rawInput) {
  if (!rawInput || typeof rawInput !== 'string') return null;
  let str = rawInput.trim();
  if (!str) return null;

  str = str.replace(/^https?:\/\//i, '');
  str = str.replace(/^ntfy\.sh\//i, '');
  str = str.replace(/^\/+|\/+$/g, '');

  const qIdx = str.indexOf('?');
  if (qIdx > -1) str = str.slice(0, qIdx);
  const hIdx = str.indexOf('#');
  if (hIdx > -1) str = str.slice(0, hIdx);

  if (!/^[a-zA-Z0-9_-]+$/.test(str)) {
    return null;
  }

  return str;
}

/* Alerta de Vendas: Envia notificação com título na URL e corpo text/plain (SEM JSON VISÍVEL) */
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg && (msg.type === 'live-infinity-ntfy' || msg.type === 'ttlf-ntfy')) {
    var canal = normalizeNtfyTopic(msg.canal || msg.topic || '');
    if (!canal) {
      sendResponse({ ok: false, error: 'Canal inválido.' });
      return true;
    }

    try {
      var notificationUrl = new URL(`https://ntfy.sh/${encodeURIComponent(canal)}`);
      var titleText = msg.titulo || msg.title || '💵 Venda Realizada - Parabéns';
      notificationUrl.searchParams.set('title', titleText);

      var tagsStr = 'moneybag';
      if (typeof msg.tags === 'string' && msg.tags.trim()) {
        tagsStr = msg.tags;
      } else if (Array.isArray(msg.tags)) {
        tagsStr = msg.tags.join(',');
      }
      notificationUrl.searchParams.set('tags', tagsStr);
      notificationUrl.searchParams.set('priority', String(msg.priority || 5));

      var bodyText = msg.corpo || msg.message || '';

      fetch(notificationUrl.toString(), {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain; charset=utf-8'
        },
        body: bodyText
      })
        .then(function (r) {
          sendResponse({ ok: r.ok, status: r.status });
        })
        .catch(function (err) {
          sendResponse({ ok: false, status: 0, error: err ? err.message : 'Erro de rede' });
        });
    } catch (err) {
      sendResponse({ ok: false, error: err ? err.message : 'Erro na montagem da URL' });
    }

    return true; // OBRIGATÓRIO: Mantém o canal de resposta assíncrono aberto
  }
});
