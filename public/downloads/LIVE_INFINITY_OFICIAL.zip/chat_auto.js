'use strict';

/* ===== Live Infinity — Comentários, Respostas Automáticas & Fila Única com Prioridade e Idempotência (ChatSendQueue) ===== */

const messageNodeIds = new WeakMap();
let nextNodeId = 1;

function getOrCreateNodeId(node) {
  if (!node) return 'msg_node_static';
  if (!messageNodeIds.has(node)) {
    messageNodeIds.set(node, `msg_node_${Date.now()}_${nextNodeId++}`);
  }
  return messageNodeIds.get(node);
}

const LiveInfinityChat = {
  commentActive: false,
  replyActive: false,
  commentTimer: null,
  replyScanTimer: null,
  replyQueueTimer: null,
  
  commentIndex: 0,
  replyQueue: [],
  lastSentMessage: '',
  lastSentTime: 0,
  
  // Estruturas de deduplicação e idempotência com limite LRU
  claimedMessageKeys: new Map(), // key -> timestamp
  processedSourceKeys: new Set(), // sourceMessageKey -> boolean
  
  claimMessageKey(key) {
    if (!key) return false;
    const now = Date.now();
    if (this.claimedMessageKeys.has(key)) {
      return false; // Já reivindicada atomicamente! Ignorar imediatamente.
    }
    this.claimedMessageKeys.set(key, now);
    
    // Limpeza LRU/TTL (manter até 300 eventos recentes)
    if (this.claimedMessageKeys.size > 300) {
      const firstKey = this.claimedMessageKeys.keys().next().value;
      this.claimedMessageKeys.delete(firstKey);
    }
    return true;
  },

  trackSourceKey(sourceKey) {
    if (!sourceKey) return false;
    if (this.processedSourceKeys.has(sourceKey)) {
      return false;
    }
    this.processedSourceKeys.add(sourceKey);
    if (this.processedSourceKeys.size > 300) {
      const firstKey = this.processedSourceKeys.values().next().value;
      this.processedSourceKeys.delete(firstKey);
    }
    return true;
  },

  // Fila Única de Envio Centralizada com Chave de Idempotência
  enqueueMessage(msg, priority = 3, label = '', sourceKey = '', mentionName = null) {
    if (!msg) return false;
    let cleanMsg = String(msg).trim();
    if (cleanMsg.length > 100) cleanMsg = cleanMsg.slice(0, 97) + '...';

    // 1. Validar se a mensagem de origem já foi processada
    if (sourceKey && !this.trackSourceKey(sourceKey)) {
      return false;
    }

    // 2. Evitar mensagens exatamente iguais pendentes na fila
    if (this.replyQueue.some(item => item.msg === cleanMsg)) {
      return false;
    }

    const queueItem = {
      id: 'q_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      sourceKey: sourceKey || cleanMsg,
      msg: cleanMsg,
      mentionName: mentionName || null,
      priority, // 1: Agradecimento, 2: Intenção, 3: Respostas por Palavra-Chave, 4: Comentários Programados
      label: label || cleanMsg.slice(0, 25),
      addedAt: Date.now(),
      attempts: 0
    };

    this.replyQueue.push(queueItem);
    this.replyQueue.sort((a, b) => a.priority - b.priority);

    if (!this.replyQueueTimer) {
      this.replyQueueTimer = setInterval(() => this.processQueue(), 1000);
    }

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Respostas', `[Chat] Evento colocado na fila: "${cleanMsg.slice(0, 35)}" (Menção: ${mentionName ? '@' + mentionName : 'Nenhuma'})`);
    }
    return true;
  },

  processQueue() {
    if (!this.replyQueue.length) return;
    const now = Date.now();
    if (now - this.lastSentTime < 3500) return;

    const nextItem = this.replyQueue.shift();
    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Respostas', `[Chat] Solicitação de menção recebida: "${nextItem.msg.slice(0, 35)}" (Menção: ${nextItem.mentionName ? '@' + nextItem.mentionName : 'Nenhuma'})`);
    }

    const ok = this.sendChatMessage(nextItem.msg, nextItem.mentionName);
    if (!ok) {
      nextItem.attempts = (nextItem.attempts || 0) + 1;
      if (nextItem.attempts < 2) { // No máximo 1 retentativa controlada
        this.replyQueue.unshift(nextItem);
      }
    }
  },

  normalizeUserName(value) {
    if (!value) return '';
    return String(value)
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .trim()
      .toLowerCase();
  },

  sendChatMessageWithMention({ message, mentionName = null, sourceEventId = '' }) {
    if (!message) return false;

    let cleanMention = mentionName ? String(mentionName).replace(/^@/, '').trim() : '';
    let finalMessage = '';

    if (cleanMention) {
      const mentionTag = `@${cleanMention}`;
      if (message.indexOf('{usuario}') > -1) {
        finalMessage = message.replace(/\{usuario\}/g, mentionTag);
      } else if (!message.startsWith(mentionTag)) {
        finalMessage = `${mentionTag} ${message.trim()}`;
      } else {
        finalMessage = message.trim();
      }
    } else {
      finalMessage = message.replace(/@\{usuario\}/g, '').replace(/\{usuario\}/g, '').trim();
    }

    if (finalMessage.length > 100) {
      finalMessage = finalMessage.slice(0, 97) + '...';
    }

    const priority = cleanMention ? 1 : 2;
    const label = cleanMention ? `Menção: @${cleanMention}` : `Chat: ${finalMessage.slice(0, 20)}`;

    return this.enqueueMessage(finalMessage, priority, label, sourceEventId, cleanMention);
  },

  sendChatMessage(msg, mentionName = null) {
    if (this.lastSentMessage === msg && Date.now() - this.lastSentTime < 15000) return false;
    let ta = LiveInfinityDOM.findChatTextarea();
    if (!ta || !ta.isConnected) {
      ta = LiveInfinityDOM.findChatTextarea();
    }

    const fieldFound = !!ta;
    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Chat', `[Chat] Campo encontrado: ${fieldFound ? 'sim' : 'não'}`);
    }

    if (!ta) {
      return false;
    }

    this.lastSentMessage = msg;
    this.lastSentTime = Date.now();

    try { ta.focus(); } catch (e) {}
    LiveInfinityDOM.setInputValue(ta, msg);

    let suggestionFound = false;
    let mentionConfirmed = false;

    // Se houver nome de menção, verificar se o TikTok exibiu popover de sugestão nativa
    if (mentionName) {
      const targetNorm = this.normalizeUserName(mentionName);
      setTimeout(() => {
        const popovers = LiveInfinityDOM.toArray(document.querySelectorAll('div[class*="mention"], div[class*="popover"], div[class*="suggestion"], li[class*="mention"]')).filter(opt => {
          if (!LiveInfinityDOM.isVisible(opt)) return false;
          const txtNorm = this.normalizeUserName(opt.textContent || '');
          return txtNorm.indexOf(targetNorm) > -1;
        });

        suggestionFound = popovers.length > 0;
        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Chat', `[Chat] Sugestão encontrada: ${suggestionFound ? 'sim' : 'não'}`);
        }

        if (suggestionFound) {
          LiveInfinityDOM.clickElement(popovers[0]);
          mentionConfirmed = true;
        } else {
          mentionConfirmed = true; // Se o TikTok não usar popover (texto já contém @), considera a menção confirmada no texto
        }

        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Chat', `[Chat] Menção confirmada: ${mentionConfirmed ? 'sim' : 'não'}`);
        }
      }, 200);
    }

    setTimeout(() => {
      const tr = ta.getBoundingClientRect();
      const sendButtons = LiveInfinityDOM.toArray(document.querySelectorAll('svg, button, [role="button"]')).filter((b) => {
        if (!LiveInfinityDOM.isVisible(b)) return false;
        const r = b.getBoundingClientRect();
        const cy = r.top + r.height / 2;
        const ty = tr.top + tr.height / 2;
        if (((b.textContent || '').trim()) !== '') return false;
        return Math.abs(cy - ty) < 40 && r.left > tr.left && r.left < tr.right + 65 && getComputedStyle(b).cursor === 'pointer';
      });

      if (sendButtons.length > 0) {
        sendButtons.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
        LiveInfinityDOM.clickElement(sendButtons[sendButtons.length - 1]);
      } else {
        ['keydown', 'keypress', 'keyup'].forEach((tp) => {
          ta.dispatchEvent(new KeyboardEvent(tp, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
        });
      }

      setTimeout(() => {
        const sentOk = ta.value === '';
        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Chat', `[Chat] Mensagem enviada: ${sentOk ? 'sim' : 'não'}`);
        }
        if (!sentOk) {
          this.lastSentMessage = '';
        }
      }, 900);
    }, 400);

    return true;
  },

  commentState: {
    active: false,
    timer: null,
    productId: null,
    currentIndex: 0,
    cycle: 1,
    consecutiveFailures: 0,
    sending: false,
    seconds: 90
  },

  getNextProductComment(comments, currentIndex) {
    if (!Array.isArray(comments) || comments.length === 0) {
      return null;
    }

    const safeIndex = Number.isInteger(currentIndex) && currentIndex >= 0
      ? currentIndex % comments.length
      : 0;

    return {
      comment: comments[safeIndex],
      safeIndex: safeIndex,
      nextIndex: (safeIndex + 1) % comments.length
    };
  },

  /* ===== Automação 1: Comentários Automáticos ===== */
  async startComments(isRestoration = false) {
    this.commentState.active = true;
    this.commentActive = true;

    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('autoComments', true);
    }

    const shadow = window.__liveInfinityShadow;
    const intInput = shadow ? shadow.getElementById('li-rc-int') : null;
    let seconds = this.commentState.seconds || parseInt(intInput ? intInput.value : 90, 10) || 90;
    if (seconds < 1) seconds = 1;
    this.commentState.seconds = seconds;

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Coment.', `[ProductComments] Motor iniciado (${seconds}s) — ${isRestoration ? 'restaurado' : 'novo'}`);
    }

    if (!this.replyQueueTimer) {
      this.replyQueueTimer = setInterval(() => this.processQueue(), 1000);
    }

    if (this.commentTimer) {
      clearTimeout(this.commentTimer);
      this.commentTimer = null;
    }

    this.runProductCommentLoop(true);
  },

  async stopComments(reason = 'desativado pelo usuário') {
    this.commentState.active = false;
    this.commentActive = false;
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('autoComments', false);
    }

    if (this.commentTimer) {
      clearTimeout(this.commentTimer);
      this.commentTimer = null;
    }

    this.updateCommentsUI('Desligado.');
    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Coment.', `[ProductComments] Motor interrompido: ${reason}`);
    }
  },

  async restoreComments() {
    return this.startComments(true);
  },

  toggleComments() {
    if (this.commentActive) this.stopComments();
    else this.startComments();
  },

  updateCommentsUI(msg) {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;
    const el = shadow.getElementById('li-rc-status');
    const toggle = shadow.getElementById('li-box-toggle-comments');
    if (el) el.textContent = msg;
    if (toggle) toggle.checked = this.commentActive;
  },

  reloadActiveProductComments() {
    const activeProd = window.LiveInfinityProductLibrary ? LiveInfinityProductLibrary.getActiveProduct() : null;
    if (activeProd && activeProd.id !== this.commentState.productId) {
      this.commentState.productId = activeProd.id;
      this.commentState.currentIndex = 0;
      this.commentState.cycle = 1;
    } else if (activeProd && activeProd.comments && activeProd.comments.length) {
      const comments = activeProd.comments.map(c => String(c).trim()).filter(Boolean);
      if (comments.length) {
        this.commentState.currentIndex = this.commentState.currentIndex % comments.length;
      } else {
        this.commentState.currentIndex = 0;
      }
    } else {
      this.commentState.currentIndex = 0;
    }
  },

  async runProductCommentLoop(immediate = false) {
    if (!this.commentActive) return;

    const activeProd = window.LiveInfinityProductLibrary ? LiveInfinityProductLibrary.getActiveProduct() : null;
    if (!activeProd || !activeProd.comments) {
      this.updateCommentsUI('Ative um produto com comentários.');
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Coment.', '[ProductComments] Motor interrompido: nenhum produto ativo com comentários.');
      }
      this.scheduleNextCommentRun(this.commentState.seconds);
      return;
    }

    const comments = activeProd.comments
      .map(c => String(c).trim())
      .filter(Boolean);

    if (!comments.length) {
      this.updateCommentsUI('Nenhum comentário válido no produto.');
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Coment.', '[ProductComments] Motor interrompido: produto ativo sem comentários válidos.');
      }
      this.scheduleNextCommentRun(this.commentState.seconds);
      return;
    }

    if (this.commentState.productId !== activeProd.id) {
      this.commentState.productId = activeProd.id;
      this.commentState.currentIndex = 0;
      this.commentState.cycle = 1;
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Coment.', `[ProductComments] Produto ativo: "${activeProd.name}" (${comments.length} comentários)`);
      }
    }

    const item = this.getNextProductComment(comments, this.commentState.currentIndex);
    if (!item) return;

    const currentCycle = this.commentState.cycle;
    const currentIndex = item.safeIndex;
    const msg = item.comment;
    const executionId = `comm_${activeProd.id}_c${currentCycle}_i${currentIndex}_t${Date.now()}`;

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Coment.', `[ProductComments] Total de comentários: ${comments.length}`);
      LiveInfinityCore.log('Coment.', `[ProductComments] Ciclo: ${currentCycle} | Índice: ${currentIndex}`);
    }

    const enqueued = this.enqueueMessage(msg, 4, `Comentário [${activeProd.name}]`, executionId);

    if (enqueued) {
      this.commentState.consecutiveFailures = 0;
      const nextIdx = item.nextIndex;
      if (nextIdx === 0) {
        this.commentState.cycle += 1;
        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Coment.', `[ProductComments] Ciclo ${currentCycle} concluído`);
          LiveInfinityCore.log('Coment.', `[ProductComments] Reiniciando no índice 0`);
          LiveInfinityCore.log('Coment.', `[ProductComments] Ciclo: ${this.commentState.cycle} | Índice: 0`);
        }
      }
      this.commentState.currentIndex = nextIdx;
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Coment.', `[ProductComments] Mensagem enviada: "${msg.slice(0, 35)}"`);
        LiveInfinityCore.log('Coment.', `[ProductComments] Próximo índice: ${nextIdx}`);
      }
      this.updateCommentsUI(`[${activeProd.name}] (C${currentCycle} • ${currentIndex + 1}/${comments.length}) ✅ ` + new Date().toLocaleTimeString().slice(0, 5));
    } else {
      this.commentState.consecutiveFailures++;
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Coment.', `[ProductComments] Envio falhou — índice mantido para nova tentativa`);
      }
      if (this.commentState.consecutiveFailures >= 3) {
        this.updateCommentsUI('Aguardando campo do chat...');
      }
    }

    this.scheduleNextCommentRun(this.commentState.seconds);
  },

  scheduleNextCommentRun(seconds) {
    if (this.commentTimer) {
      clearTimeout(this.commentTimer);
      this.commentTimer = null;
    }
    if (!this.commentActive) return;

    const delayMs = (seconds || 90) * 1000;
    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Coment.', `[ProductComments] Próxima execução: em ${seconds}s`);
    }
    this.commentTimer = setTimeout(() => this.runProductCommentLoop(false), delayMs);
  },

  /* ===== Automação 2: Respostas Automáticas por Palavra-Chave (Com Deduplicação Absoluta) ===== */
  async startReplies(isRestoration = false) {
    if (this.replyScanTimer) {
      clearInterval(this.replyScanTimer);
      this.replyScanTimer = null;
    }

    this.replyActive = true;
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('autoReplies', true);
    }

    this.markExistingCommentsAsRead();

    if (!this.replyQueueTimer) {
      this.replyQueueTimer = setInterval(() => this.processQueue(), 1000);
    }

    this.replyScanTimer = setInterval(() => this.scanChatForKeywords(), 2000);

    this.updateRepliesUI('Monitorando comentários do chat... 👀');
    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Respostas', `Respostas automáticas ${isRestoration ? 'restauradas' : 'iniciadas'}`);
    }
  },

  async stopReplies() {
    this.replyActive = false;
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('autoReplies', false);
    }
    if (this.replyScanTimer) clearInterval(this.replyScanTimer);
    this.replyScanTimer = null;
    this.updateRepliesUI('Desligado.');
    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Respostas', 'Respostas automáticas paradas');
    }
  },

  async restoreReplies() {
    return this.startReplies(true);
  },

  toggleReplies() {
    if (this.replyActive) this.stopReplies();
    else this.startReplies();
  },

  updateRepliesUI(msg) {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;
    const el = shadow.getElementById('li-ra-status');
    const toggle = shadow.getElementById('li-box-toggle-replies');
    if (el) el.textContent = msg;
    if (toggle) toggle.checked = this.replyActive;
  },

  getRules() {
    const shadow = window.__liveInfinityShadow;
    const area = shadow ? shadow.getElementById('li-ra-regras') : null;
    if (!area) return [];

    const lines = area.value.split('\n');
    const rules = [];
    lines.forEach((l) => {
      const line = l.replace('=>', '=');
      const idx = line.indexOf('=');
      if (idx < 0) return;
      const keys = line.slice(0, idx).split(',').map(k => LiveInfinityDOM.normalizeText(k)).filter(k => k.length > 0);
      const resp = line.slice(idx + 1).trim();
      if (keys.length && resp) rules.push({ keys, resp });
    });
    return rules;
  },

  getChatRows() {
    // Buscar apenas nós de linhas raiz sem elementos filhos que também sejam linhas
    const rawRows = LiveInfinityDOM.toArray(document.querySelectorAll('[class*="cursor-pointer"], [class*="rounded"]')).filter((el) => {
      if (!LiveInfinityDOM.isVisible(el)) return false;
      const imgs = LiveInfinityDOM.toArray(el.querySelectorAll('img')).filter(im => {
        const r = im.getBoundingClientRect();
        return r.width >= 14 && r.width <= 56;
      });
      if (imgs.length !== 1) return false;
      const full = (el.textContent || '').trim();
      if (/está vendo o produto|acabou de|entrou na|pedidos feitos|Alternar modo/i.test(full)) return false;
      return full.length > 0 && full.length < 400;
    });

    // Descartar contêineres pai onde um filho já é uma linha capturada
    const uniqueRows = rawRows.filter(el => !rawRows.some(other => other !== el && el.contains(other)));

    return uniqueRows.map((row) => {
      const textNodes = LiveInfinityDOM.toArray(row.querySelectorAll('div, span')).filter(x => x.children.length === 0 && (x.textContent || '').trim());
      let isHost = false;
      const texts = [];
      textNodes.forEach((n) => {
        const t = n.textContent.trim();
        if (t === 'Host' || t === 'Anfitrião') isHost = true;
        else texts.push(t);
      });

      const author = texts.length ? texts[0] : '';
      const text = texts.length ? texts[texts.length - 1] : '';
      const nodeId = getOrCreateNodeId(row);

      return {
        el: row,
        nodeId,
        author,
        text,
        isHost
      };
    });
  },

  markExistingCommentsAsRead() {
    const rows = this.getChatRows();
    rows.forEach((c) => {
      const normAuthor = LiveInfinityDOM.normalizeText(c.author || 'anon');
      const normText = LiveInfinityDOM.normalizeText(c.text || '');
      const key = `reply:${c.nodeId}:${normAuthor}:${normText}`;
      this.claimMessageKey(key);
    });
  },

  scanChatForKeywords() {
    if (!this.replyActive) return;
    const rules = this.getRules();
    if (!rules.length) return;

    const shadow = window.__liveInfinityShadow;
    const mentionCheckbox = shadow ? shadow.getElementById('li-ra-mencao') : null;
    const shouldMention = mentionCheckbox ? mentionCheckbox.checked : true;

    const chatRows = this.getChatRows();

    chatRows.forEach((c) => {
      if (c.isHost || !c.text) return;

      const normAuthor = LiveInfinityDOM.normalizeText(c.author || 'anon');
      const normText = LiveInfinityDOM.normalizeText(c.text);
      
      // Chave única absoluta por nó DOM + autor + texto
      const eventKey = `reply:${c.nodeId}:${normAuthor}:${normText}`;

      // 1️⃣ Instrumentação Etapa 1: messageDetected
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Respostas', `[1/6] messageDetected: key="${eventKey.slice(0, 30)}..."`);
      }

      // 2️⃣ Instrumentação Etapa 2: Reivindicação Atômica Síncrona
      if (!this.claimMessageKey(eventKey)) {
        return; // Evento já reivindicado por outro observer ou ciclo! Abortar sem duplicar.
      }

      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Respostas', `[2/6] messageClaimed: key="${eventKey.slice(0, 30)}..."`);
      }

      // 3️⃣ Instrumentação Etapa 3: Busca pela REGRA MAIS ESPECÍFICA (não responder 3x para múltiplos matches)
      const ruleMatches = [];
      for (let i = 0; i < rules.length; i++) {
        const rule = rules[i];
        for (const k of rule.keys) {
          if (normText.indexOf(k) > -1) {
            ruleMatches.push({ rule, matchedKey: k, keyLength: k.length });
            break;
          }
        }
      }

      if (!ruleMatches.length) return;

      // Ordenar por tamanho da palavra-chave (maior especificidade)
      ruleMatches.sort((a, b) => b.keyLength - a.keyLength);
      const selectedRule = ruleMatches[0].rule;

      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Respostas', `[3/6] ruleMatched: "${ruleMatches[0].matchedKey}"`);
      }

      // 4️⃣ Enfileirar UMA ÚNICA resposta
      let responseMsg = (shouldMention && c.author ? `@${c.author} ` : '') + selectedRule.resp;
      const enqueued = this.enqueueMessage(responseMsg, 3, `Resposta @${c.author}`, eventKey);

      if (enqueued) {
        this.updateRepliesUI(`Respondido a @${c.author} ✅ ` + new Date().toLocaleTimeString().slice(0, 5));
      }
    });
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityChat = LiveInfinityChat;
}
