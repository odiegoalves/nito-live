'use strict';

/* ===== Live Infinity — Dashboard de Vendas & Mini Painel Informativo (Com Cálculo Consistente e Deltas de Vendas) ===== */
const LiveInfinityDashboard = {
  timer: null,
  detectedSalesCount: 0,
  lastGmv: 0,
  lastItens: 0,
  lastOrders: 0,
  initializedDeltas: false,
  isLiveDetected: true,
  dataLocated: false,
  processedSaleEvents: new Set(),

  start() {
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => this.update(), 2000);
    this.update();
  },

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  },

  resetSessionMetrics() {
    this.detectedSalesCount = 0;
    this.lastGmv = 0;
    this.lastItens = 0;
    this.lastOrders = 0;
    this.initializedDeltas = false;
    if (this.processedSaleEvents && typeof this.processedSaleEvents.clear === 'function') {
      this.processedSaleEvents.clear();
    }
    this.update();
  },

  getMetricText(labelPrefixes) {
    const prefixes = Array.isArray(labelPrefixes) ? labelPrefixes : [labelPrefixes];
    const nodes = LiveInfinityDOM.toArray(document.querySelectorAll('[class*="text-neutral-text3"]')).filter(e => {
      if (e.children.length !== 0) return false;
      const txt = (e.textContent || '').trim();
      return prefixes.some(p => txt.indexOf(p) === 0);
    });
    if (!nodes.length) return null;

    const targetEl = nodes[0];
    let parent = targetEl.parentElement;
    for (let i = 0; i < 3 && parent; i++) {
      const candidates = LiveInfinityDOM.toArray(parent.querySelectorAll('div, span, p')).filter(x => {
        return x.children.length === 0 && x !== targetEl && (x.textContent || '').trim();
      });
      for (let j = 0; j < candidates.length; j++) {
        const txt = candidates[j].textContent.trim();
        if (txt !== targetEl.textContent.trim() && txt.length < 25 && /^(--|R\$|\d)/.test(txt)) {
          return txt;
        }
      }
      parent = parent.parentElement;
    }
    return null;
  },

  parseValue(valStr) {
    if (!valStr) return 0;
    let s = String(valStr);
    let multiplier = 1;
    if (/mil/i.test(s)) multiplier = 1000;
    else if (/mi/i.test(s)) multiplier = 1000000;

    s = s.replace(/[^\d.,]/g, '');
    if (s.indexOf(',') > -1) {
      s = s.replace(/\./g, '').replace(',', '.');
    }
    return (parseFloat(s) || 0) * multiplier;
  },

  formatBRL(num) {
    if (num === null || num === undefined) return '—';
    return 'R$ ' + (num || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  registerSaleEvent(saleData = {}) {
    const saleId = saleData.eventId || saleData.id || `sale_evt_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;
    if (this.processedSaleEvents.has(saleId)) {
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Vendas', `[Sales] Evento duplicado ignorado: ${saleId}`);
      }
      return;
    }
    this.processedSaleEvents.add(saleId);

    this.detectedSalesCount += 1; // 1 novo pedido/venda confirmada
    this.lastEventTime = Date.now();

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Vendas', `[Sales] Evento de compra registrado: +1 venda (Total acumulado: ${this.detectedSalesCount})`);
    }

    this.update();
  },

  update() {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;

    try {
      const gmvTxt = this.getMetricText(['GMV atribu', 'GMV']);
      const itensTxt = this.getMetricText(['Itens atribu', 'Itens vend', 'Unidades vend']);
      const pedidosTxt = this.getMetricText(['Pedidos atribu', 'Vendas atribu', 'Pedidos', 'Vendas']);

      if (gmvTxt || itensTxt || pedidosTxt) {
        this.dataLocated = true;
      }

      // Verificar se existe um indicador de live ativa na página do TikTok Shop
      const liveIndicators = LiveInfinityDOM.toArray(document.querySelectorAll('*')).filter(el => {
        const txt = (el.textContent || '').trim();
        return txt === 'Ao vivo' || txt === 'LIVE' || txt === 'Transmitindo';
      });
      this.isLiveDetected = liveIndicators.length > 0 || this.dataLocated;

      const currentGmv = this.parseValue(gmvTxt);
      const currentItens = this.parseValue(itensTxt);
      const currentOrders = pedidosTxt ? this.parseValue(pedidosTxt) : 0;

      // LÓGICA DE DELTAS E REGISTRO ATÔMICO DE COMPRAS CONFIRMADAS
      if (this.initializedDeltas) {
        const deltaGmv = currentGmv - this.lastGmv;
        const deltaItens = currentItens - this.lastItens;
        const deltaOrders = currentOrders - this.lastOrders;

        if (deltaOrders > 0) {
          this.detectedSalesCount += deltaOrders;
          if (window.LiveInfinityCore) {
            LiveInfinityCore.log('Vendas', `[Sales] Snapshot anterior: GMV=${this.lastGmv} Itens=${this.lastItens} Pedidos=${this.lastOrders}`);
            LiveInfinityCore.log('Vendas', `[Sales] Snapshot atual: GMV=${currentGmv} Itens=${currentItens} Pedidos=${currentOrders}`);
            LiveInfinityCore.log('Vendas', `[Sales] Delta confirmado (Pedidos): +${deltaOrders} venda(s)`);
          }
        } else if (deltaGmv > 0 && deltaItens > 0) {
          // Se um evento de compra não tiver sido registrado recentemente, incrementa 1 venda via delta do DOM
          const recentlyEventRegistered = Date.now() - (this.lastEventTime || 0) < 2500;
          if (!recentlyEventRegistered) {
            const inferredSales = 1;
            this.detectedSalesCount += inferredSales;
            if (window.LiveInfinityCore) {
              LiveInfinityCore.log('Vendas', `[Sales] Snapshot anterior: GMV=${this.lastGmv} Itens=${this.lastItens}`);
              LiveInfinityCore.log('Vendas', `[Sales] Snapshot atual: GMV=${currentGmv} Itens=${currentItens}`);
              LiveInfinityCore.log('Vendas', `[Sales] Delta confirmado (GMV + Itens): deltaGmv=${deltaGmv.toFixed(2)} deltaItems=${deltaItens} -> +${inferredSales} venda(s)`);
            }
          }
        }
      } else {
        this.initializedDeltas = true;
        if (currentOrders > 0) {
          this.detectedSalesCount = currentOrders;
        } else if (currentGmv > 0 && currentItens > 0) {
          this.detectedSalesCount = 1;
        }
      }

      this.lastGmv = currentGmv;
      this.lastItens = currentItens;
      this.lastOrders = currentOrders;

      // MÉTRICAS CONSISTENTES E TOTALMENTE SINCRONIZADAS
      const vendas = Math.max(this.detectedSalesCount, currentOrders > 0 ? currentOrders : (currentGmv > 0 && currentItens > 0 ? 1 : 0));
      const itens = Math.max(currentItens, vendas);
      const ticketMedio = vendas > 0 ? (currentGmv / vendas) : 0;

      // 1. Atualizar Visão Geral no Hub Principal
      const elGmv = shadow.getElementById('li-dash-gmv');
      const elVendas = shadow.getElementById('li-dash-vendas');
      const elTicket = shadow.getElementById('li-dash-ticket');
      const elItens = shadow.getElementById('li-dash-itens');

      if (elGmv) elGmv.textContent = this.formatBRL(currentGmv);
      if (elVendas) elVendas.textContent = String(vendas);
      if (elItens) elItens.textContent = String(itens);
      if (elTicket) elTicket.textContent = this.formatBRL(ticketMedio);

      // 2. Atualizar Mini Painel Informativo (Modo Minimizado)
      const miniGmv = shadow.getElementById('li-mini-gmv');
      const miniVendas = shadow.getElementById('li-mini-vendas');

      const gmvDisplay = this.dataLocated ? this.formatBRL(currentGmv) : 'R$ 0,00';
      const vendasDisplay = String(vendas);

      if (miniGmv) miniGmv.textContent = gmvDisplay;
      if (miniVendas) miniVendas.textContent = vendasDisplay;

      if (window.LiveSessionStore && typeof LiveSessionStore.renderFooterLiveStatus === 'function') {
        LiveSessionStore.renderFooterLiveStatus(LiveSessionStore.session.status);
      }
    } catch (e) {}
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityDashboard = LiveInfinityDashboard;
}
