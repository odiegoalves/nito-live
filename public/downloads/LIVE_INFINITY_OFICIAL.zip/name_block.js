'use strict';

/* ===== Live Infinity — Bloqueio por Nome Suspeito ===== */
const LiveInfinityNameBlock = {
  active: false,
  timer: null,

  async start(isRestoration = false) {
    this.active = true;
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('nameBlock', true);
    }

    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => this.scan(), 3000);
    this.updateUI('Ativo — monitorando entrada de espectadores...');
    LiveInfinityCore.log('Bloqueio', `Automação ${isRestoration ? 'restaurada' : 'iniciada'}`);
  },

  async stop() {
    this.active = false;
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('nameBlock', false);
    }
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.updateUI('Desligado.');
    LiveInfinityCore.log('Bloqueio', 'Automação parada');
  },

  restore() {
    this.start(true);
  },

  toggle() {
    if (this.active) this.stop();
    else this.start();
  },

  updateUI(msg) {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;
    const el = shadow.getElementById('li-bn-status');
    const btn = shadow.getElementById('li-bn-botao');
    if (el) el.textContent = msg;
    if (btn) {
      if (this.active) {
        btn.textContent = '⏸ Parar Bloqueio';
        btn.classList.add('li-btn-stop');
      } else {
        btn.textContent = '▶ Iniciar Bloqueio';
        btn.classList.remove('li-btn-stop');
      }
    }
  },

  scan() {
    if (!this.active) return;
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityNameBlock = LiveInfinityNameBlock;
}
