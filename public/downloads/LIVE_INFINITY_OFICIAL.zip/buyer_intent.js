'use strict';

/* ===== Live Infinity — Automação de Intenção de Compra (Com Associação Estrita do Evento ↔ Usuário) ===== */
const LiveInfinityBuyerIntent = {
  active: false,
  timer: null,
  processedKeys: new Set(),
  isScanning: false,

  async start(isRestoration = false) {
    this.active = true;
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('buyerIntent', true);
    }

    this.markExistingEventsAsSeen();

    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => this.scan(), LIVE_INFINITY_CONFIG.DEFAULTS.SCAN_INTERVAL_MS);
    this.updateUI('Ativa — aguardando alguém adicionar ao carrinho');
    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Intenção', `Automação ${isRestoration ? 'restaurada' : 'iniciada'}`);
    }
  },

  async stop() {
    this.active = false;
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('buyerIntent', false);
    }
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.updateUI('Desligado.');
    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Intenção', 'Automação parada');
    }
  },

  restore() {
    this.start(true);
  },

  toggle() {
    if (this.active) this.stop();
    else this.start();
  },

  updateUI(msg) {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;
    const el = shadow.getElementById('li-ic-status');
    const toggle = shadow.getElementById('li-box-toggle-intent');
    if (el) el.textContent = msg;
    if (toggle) toggle.checked = this.active;
  },

  markExistingEventsAsSeen() {
    if (!window.LiveInfinityFeedMonitor) return;
    const events = LiveInfinityFeedMonitor.findCartEvents();
    events.forEach(ev => {
      try { ev.row.dataset.liCartSeen = '1'; } catch (e) {}
    });
  },

  getCustomPhrase() {
    const shadow = window.__liveInfinityShadow;
    const area = shadow ? shadow.getElementById('li-ic-cart') : null;
    let phrase = area ? (area.value || '').trim() : '';
    if (!phrase) phrase = 'Vi que você colocou o item no carrinho, finalize seu pedido antes que o estoque acabe! 🛒';
    return phrase;
  },

  async scan() {
    if (!this.active || this.isScanning || !window.LiveInfinityFeedMonitor) return;
    this.isScanning = true;

    try {
      const events = LiveInfinityFeedMonitor.findCartEvents();
      const newEvents = events.filter(ev => {
        const d = ev.row.dataset || {};
        return !d.liCartSeen && !d.liCartQueued;
      });

      for (const ev of newEvents) {
        if (!this.active) break;
        const eventId = 'cart_evt_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4);
        try { ev.row.dataset.liCartQueued = '1'; } catch (e) {}

        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Intenção', `[Cart] Evento detectado: carrinho em ${new Date().toLocaleTimeString()}`);
        }

        const verification = await LiveInfinityFeedMonitor.extractVerifiedUsername(ev.row, false);

        // REGRA ABSOLUTA: Apenas enviar se o status for VERIFIED (Comprovadamente pertencente ao evento)
        if (verification && verification.ok && verification.confidence === 'VERIFIED' && verification.username) {
          const username = verification.username;
          const mention = `@${username.replace(/^@/, '')}`;
          const key = `cart:${eventId}:${username}`;

          if (window.LiveInfinityCore) {
            LiveInfinityCore.log('Intenção', `[Cart] Usuário extraído: ${mention}`);
          }

          if (this.processedKeys.has(key)) {
            continue;
          }
          this.processedKeys.add(key);

          const phrase = this.getCustomPhrase();
          let finalMsg = '';
          if (phrase.indexOf('{usuario}') > -1) {
            finalMsg = phrase.replace(/\{usuario\}/g, mention);
          } else {
            finalMsg = `${mention} ${phrase}`;
          }

          if (finalMsg.length > 100) finalMsg = finalMsg.slice(0, 97) + '...';

          if (window.LiveInfinityChat) {
            if (typeof window.LiveInfinityChat.sendChatMessageWithMention === 'function') {
              window.LiveInfinityChat.sendChatMessageWithMention({
                message: phrase,
                mentionName: username,
                sourceEventId: key
              });
            } else {
              window.LiveInfinityChat.enqueueMessage(finalMsg, 2, `Intenção: ${mention}`, key, username);
            }
          }

          if (window.LiveInfinityCore) {
            LiveInfinityCore.log('Intenção', `[Cart] Evento colocado na fila: "${finalMsg.slice(0, 35)}" para ${mention}`);
          }

          this.updateUI(`Mensagem enviada para ${mention} ✅ ` + new Date().toLocaleTimeString().slice(0, 5));
        } else {
          this.updateUI('EVENTO DETECTADO — USUÁRIO NÃO IDENTIFICADO');
          if (window.LiveInfinityCore) {
            LiveInfinityCore.log('Intenção', '[Cart] Usuário extraído: não identificado. Nenhuma mensagem enviada.');
          }
        }
      }
    } catch (err) {
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Intenção', 'Erro no scanner de intenção: ' + (err.message || err));
      }
    } finally {
      this.isScanning = false;
    }
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityBuyerIntent = LiveInfinityBuyerIntent;
}
