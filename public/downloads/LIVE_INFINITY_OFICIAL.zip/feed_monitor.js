'use me';
'use strict';

/* ===== Live Infinity — Monitor Central do Feed de Atividades do TikTok Shop (v1.0.0) ===== */

const LiveInfinityFeedMonitor = {
  $s(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  },

  vis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  },

  fora(el) {
    let q = el;
    while (q) {
      if (q.id === 'live-infinity-root-host' || q.id === 'li-hub' || q.id === 'li-mini-panel' || q.dataset?.liveInfinity) {
        return false;
      }
      q = q.parentElement;
    }
    return true;
  },

  achaAvatar(row) {
    const im = this.$s('img', row).filter(x => this.vis(x));
    if (im.length) return im[0];

    const sv = this.$s('svg', row).filter(x => {
      const r = x.getBoundingClientRect();
      return this.vis(x) && r.width >= 12 && r.width <= 60 && r.height >= 12 && r.height <= 60;
    });
    if (sv.length) return sv[0];

    const cs = this.$s('div, span', row).filter(x => {
      if (!this.vis(x)) return false;
      const r = x.getBoundingClientRect();
      const stl = getComputedStyle(x);
      const isAvatarClass = (x.className || '').indexOf('avatar') > -1;
      return isAvatarClass || parseFloat(stl.borderRadius) >= 8 || (stl.backgroundImage && stl.backgroundImage !== 'none');
    });
    cs.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
    if (cs.length) return cs[0];

    return null;
  },

  realVis(e) {
    try {
      const cs = getComputedStyle(e);
      if (cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) < 0.3) return false;
      let an = e.parentElement, k = 0;
      while (an && k < 8) {
        const c2 = getComputedStyle(an);
        if (c2.visibility === 'hidden' || c2.display === 'none' || parseFloat(c2.opacity) < 0.3) return false;
        an = an.parentElement;
        k++;
      }
      return true;
    } catch (_) {
      return false;
    }
  },

  sobresReais() {
    const a = [];
    this.$s('div, span, p, h1, h2, h3, b, strong').forEach(e => {
      if (e.children.length > 3) return;
      const t = (e.textContent || '').trim();
      const m = t.match(/^Sobre\s+(.{2,40})$/i);
      if (!m) return;
      if (!this.realVis(e)) return;
      const n = m[1].replace(/\s*[ⓘℹ①(].*$/, '').trim();
      if (n) a.push(n);
    });
    return a;
  },

  nomePopover(antes) {
    const depois = this.sobresReais();
    const novos = depois.filter(n => antes.indexOf(n) < 0);
    if (novos.length) return novos[0];
    return depois.length ? depois[0] : null;
  },

  hover(el) {
    if (!el) return;
    try {
      const r = el.getBoundingClientRect();
      const cx = Math.round(r.left + r.width / 2);
      const cy = Math.round(r.top + r.height / 2);
      ['pointerover', 'pointerenter', 'mouseover', 'mouseenter', 'pointermove', 'mousemove'].forEach(tp => {
        try {
          el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy }));
        } catch (e) {}
      });
    } catch (e) {}
  },

  unhover(el) {
    if (!el) return;
    try {
      ['mouseout', 'mouseleave', 'pointerout', 'pointerleave'].forEach(tp => {
        try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {}
      });
    } catch (e) {}
  },

  clicar(el) {
    if (!el) return;
    const alvo = (el.closest && el.closest('button, [role="button"]')) || el;
    try {
      alvo.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
    } catch (e) {}
  },

  limpaHover(av) {
    if (!av) return;
    this.unhover(av);
    let pp = av;
    for (let i = 0; i < 4 && pp; i++) {
      this.unhover(pp);
      pp = pp.parentElement;
    }
    try {
      document.body.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, clientX: 4, clientY: 4, view: window }));
      document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, which: 27, bubbles: true }));
    } catch (e) {}
  },

  async extractVerifiedUsername(row, isPurchase = false) {
    if (!row) {
      return { ok: false, username: null, confidence: 'UNRESOLVED', source: 'NO_ROW' };
    }

    // 1. Procurar menção explícita com @ no próprio texto do nó do evento
    const rowText = (row.textContent || '').trim();
    const atMatch = rowText.match(/@(.+?)\s+(fez|realizou|acabou|comprou|compraram|efetuou|pagou|finalizou|adicionou)/i) || rowText.match(/@([a-zA-Z0-9_\.\-\u00C0-\u00FF\s]+)/);
    if (atMatch && atMatch[1]) {
      const cleanName = atMatch[1].trim();
      if (cleanName.length >= 2 && !/^(fez|realizou|acabou|comprou|efetuou|pagou|finalizou|adicionou)$/i.test(cleanName)) {
        return { ok: true, username: cleanName, confidence: 'VERIFIED', source: 'ROW_TEXT_AT' };
      }
    }

    // 2. Procurar elemento a[href*="/@"] diretamente no nó do evento
    const directUserLink = this.$s('a[href*="/@"]', row)[0];
    if (directUserLink) {
      const match = (directUserLink.getAttribute('href') || '').match(/@([a-zA-Z0-9_\.\-\u00C0-\u00FF]+)/);
      if (match && match[1]) {
        return { ok: true, username: match[1], confidence: 'VERIFIED', source: 'DIRECT_LINK' };
      }
    }

    // 3. Procurar o primeiro elemento filho b, strong, span contendo o nome do comprador no evento específico
    const userNodes = this.$s('b, strong, a, span.user-name, div[class*="user"], span[class*="name"]', row).filter(el => {
      const t = (el.textContent || '').trim();
      return t && t.length < 40 && !/(fez um pedido|realizou|acabou de comprar|comprou|efetuou o pagamento|pagou o pedido|finalizou a compra|adicionou ao carrinho)/i.test(t);
    });

    if (userNodes.length) {
      const firstUserNode = userNodes[0];
      const rawText = (firstUserNode.textContent || '').replace(/^@/, '').trim();
      if (rawText && rawText.length >= 2) {
        return { ok: true, username: rawText, confidence: 'VERIFIED', source: 'ROW_CHILD_ELEMENT' };
      }
    }

    // 4. Snapshot dos popovers visíveis antes do hover do avatar
    const av = this.achaAvatar(row);
    if (!av) {
      return { ok: false, username: null, confidence: 'UNRESOLVED', source: 'NO_AVATAR' };
    }

    const antes = this.sobresReais();
    let tent = 0;

    return new Promise((resolve) => {
      const tenta = () => {
        tent++;
        this.hover(av);
        if (isPurchase && tent >= 3) {
          try { this.clicar(av); } catch (e) {}
        }

        setTimeout(() => {
          const nome = this.nomePopover(antes);
          if (nome) {
            this.limpaHover(av);
            const cleanName = nome.replace(/^@/, '').trim();
            resolve({ ok: true, username: cleanName, confidence: 'VERIFIED', source: 'NEW_POPOVER' });
            return;
          }

          if (tent >= (isPurchase ? 6 : 4)) {
            this.limpaHover(av);
            // REGRA ABSOLUTA: Sem comprador verificado do nó específico -> Retorna UNRESOLVED (NENHUM FALLBACK PARA CARRINHO/GLOBAL!)
            resolve({ ok: false, username: null, confidence: 'UNRESOLVED', source: 'NONE' });
            return;
          }

          tenta();
        }, 250);
      };

      tenta();
    });
  },

  async extractUsernameFromRow(row, isPurchase = false) {
    const res = await this.extractVerifiedUsername(row, isPurchase);
    if (res && res.ok && res.confidence === 'VERIFIED') {
      return res.username;
    }
    return null;
  },

  parseBRL(value) {
    if (typeof value === 'number') return isNaN(value) ? null : value;
    if (!value) return null;
    const str = String(value).trim();
    const cleanStr = str.replace(/\s/g, '').replace(/R\$/gi, '');
    if (!cleanStr) return null;

    let numericVal = NaN;
    if (/^\d{1,3}(\.\d{3})*,\d{2}$/.test(cleanStr)) {
      numericVal = parseFloat(cleanStr.replace(/\./g, '').replace(',', '.'));
    } else if (/^\d+(,\d+)?$/.test(cleanStr)) {
      numericVal = parseFloat(cleanStr.replace(',', '.'));
    } else if (!isNaN(parseFloat(cleanStr))) {
      numericVal = parseFloat(cleanStr);
    }

    return Number.isFinite(numericVal) && numericVal > 0 ? numericVal : null;
  },

  parseSalesEventData(row, rawText = '') {
    const text = rawText || (row ? row.textContent : '') || '';

    let unitPrice = null;
    let totalAmount = null;
    let amountSource = 'none';

    const priceMatches = Array.from(text.matchAll(/R\$\s?([\d.]+(?:,\d{2})?)/gi));

    if (priceMatches.length > 0) {
      const parsedPrices = priceMatches.map(m => this.parseBRL(m[1])).filter(v => v !== null && v > 0);
      if (parsedPrices.length > 0) {
        unitPrice = parsedPrices[0];
        totalAmount = parsedPrices.length > 1 ? parsedPrices[parsedPrices.length - 1] : parsedPrices[0];
        amountSource = 'purchase_event';
      }
    }

    let quantity = 1;
    const qtyMatch = text.match(/(\d+)\s*(unidades?|itens|peças|unids?)/i) || text.match(/n[ºo°.]?\s*(\d+)/i);
    if (qtyMatch && qtyMatch[1]) {
      const parsedQty = parseInt(qtyMatch[1], 10);
      if (parsedQty > 0 && parsedQty < 100) {
        quantity = parsedQty;
      }
    }

    if (unitPrice && quantity > 1 && totalAmount === unitPrice) {
      totalAmount = unitPrice * quantity;
      amountSource = 'order_total';
    }

    let productName = null;
    const prodMatch = text.match(/(?:pedido de|produto|comprou|item)\s+([A-Za-z0-9\u00C0-\u00FF\s\-\.\/]{3,60})/i);
    if (prodMatch && prodMatch[1]) {
      let cleanProd = prodMatch[1].replace(/\(R\$.*$/i, '').replace(/R\$.*$/i, '').replace(/\b\d+\s*unidades?\b/i, '').trim();
      cleanProd = cleanProd.replace(/^(de|o|um|uma)\s+/i, '').trim();
      if (cleanProd && cleanProd.length >= 2) {
        productName = cleanProd;
      }
    }

    if (!productName && row) {
      const prodEl = this.$s('a[href*="product"], span[class*="product"], div[class*="product"]', row)[0];
      if (prodEl) {
        const txt = (prodEl.textContent || '').trim();
        if (txt && txt.length < 80) productName = txt;
      }
    }

    return {
      productName: productName || 'Produto TikTok Shop',
      quantity: quantity,
      unitPrice: unitPrice,
      totalAmount: totalAmount,
      amountSource: amountSource
    };
  },

  findCartEvents() {
    const res = [];
    const vistos = [];

    const hits = this.$s('div, span, p').filter((x) => {
      if (!this.vis(x) || !this.fora(x)) return false;
      const t = (x.textContent || '').trim();
      if (!t || t.length > 90) return false;
      return /(adicionou|colocou)\s+(este|o)?\s*produto\s+ao\s+carrinho/i.test(t);
    });

    const singles = hits.filter(x => !hits.some(y => y !== x && x.contains(y)));

    singles.forEach((mk) => {
      let row = mk;
      for (let i = 0; i < 6 && row.parentElement; i++) {
        if (row.parentElement.id === 'live-feed' || row.parentElement === document.body || row.parentElement.tagName === 'BODY') break;
        row = row.parentElement;
        if (row.querySelector('img') || this.achaAvatar(row)) break;
      }
      if (vistos.indexOf(row) > -1) return;
      vistos.push(row);
      res.push({ row, text: (mk.textContent || '').trim() });
    });

    return res;
  },

  findPurchaseEvents() {
    const res = [];
    const vistos = [];

    const hits = this.$s('div, span, p').filter((x) => {
      if (!this.vis(x) || !this.fora(x)) return false;
      const t = (x.textContent || '').trim();
      if (!t || t.length > 90) return false;
      if (/carrinho|adicionou.*produto/i.test(t)) return false;
      return /(fez (um |o )?pedido|realizou (um |o )?pedido|acabou de comprar|comprou|compraram|efetuou (o )?pagamento|pagou (o )?pedido|finalizou (a )?compra)/i.test(t);
    });

    const singles = hits.filter(x => !hits.some(y => y !== x && x.contains(y)));

    singles.forEach((mk) => {
      let row = mk;
      for (let i = 0; i < 7 && row.parentElement; i++) {
        if (row.parentElement.id === 'live-feed' || row.parentElement === document.body || row.parentElement.tagName === 'BODY') break;
        row = row.parentElement;
        if (this.achaAvatar(row)) break;
      }
      if (vistos.indexOf(row) > -1) return;
      vistos.push(row);
      res.push({ row, text: (mk.textContent || '').trim() });
    });

    return res;
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityFeedMonitor = LiveInfinityFeedMonitor;
}
