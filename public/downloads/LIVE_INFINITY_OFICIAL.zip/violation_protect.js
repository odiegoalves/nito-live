'use strict';

/* ===== Live Infinity — Proteção de Emergência Obrigatória & Automática (v1.0.0) ===== */
const LiveInfinityViolationProtect = {
  mandatory: true,
  state: 'ARMED', // DISABLED_BY_LICENSE | ARMED | MONITORING | SUSPECTED | CONFIRMED | COUNTDOWN | ENDING | ENDED | ERROR
  delaySeconds: 0,
  detectedAt: 0,
  suspectedAlert: null,
  suspectedAt: 0,
  lastHandledViolationId: null,
  timer: null,
  lastLogState: null,
  lastOpenNotification: 0,

  $s(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  },

  vis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  },

  fora(el) {
    let q = el;
    while (q) {
      if (q.id === 'live-infinity-root-host' || q.id === 'li-hub' || q.id === 'li-mini-panel') return false;
      q = q.parentElement;
    }
    return true;
  },

  ehConfig(e) {
    let q = e;
    for (let k = 0; k < 14 && q; k++) {
      const t = (q.textContent || '');
      if (t.length < 8000 && /(Configura[cç][oõ]es|Filtrar coment|Permitir coment|palavras-chave|Dura[cç][aã]o do silenciamento|Bloquear palavras|comunidade j[aá] sinalizou|potencialmente desagrad)/i.test(t)) {
        return true;
      }
      q = q.parentElement;
    }
    return false;
  },

  clicar(el) {
    if (!el) return;
    const alvo = (el.closest && el.closest('button, [role="button"], a')) || el;
    try { alvo.scrollIntoView({ block: 'center' }); } catch (e) {}
    const fire = (tp) => {
      try {
        const r = alvo.getBoundingClientRect();
        const cx = Math.round(r.left + r.width / 2);
        const cy = Math.round(r.top + r.height / 2);
        let E;
        if (tp.indexOf('pointer') === 0 && window.PointerEvent) {
          E = new PointerEvent(tp, { bubbles: true, cancelable: true, view: window, pointerId: 1, pointerType: 'mouse', isPrimary: true, button: 0, buttons: tp.indexOf('down') > -1 ? 1 : 0, clientX: cx, clientY: cy });
        } else {
          E = new MouseEvent(tp, { bubbles: true, cancelable: true, view: window, button: 0, buttons: tp.indexOf('down') > -1 ? 1 : 0, clientX: cx, clientY: cy });
        }
        alvo.dispatchEvent(E);
      } catch (e) {}
    };

    ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach(fire);
    try {
      if (typeof alvo.click === 'function') alvo.click();
      else fire('click');
    } catch (e) {}
  },

  async init() {
    await this.restoreSettings();
    const isLicenseValid = window.LiveInfinityLicense && typeof LiveInfinityLicense.isCurrentValid === 'function' ? LiveInfinityLicense.isCurrentValid() : true;
    if (!isLicenseValid) {
      this.state = 'DISABLED_BY_LICENSE';
    } else {
      this.state = 'ARMED';
    }

    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => this.tick(), 1500);
    this.updateUI();
  },

  async restoreSettings() {
    if (window.LiveInfinityStateStore) {
      const store = await LiveInfinityStateStore.loadState();
      const cfg = store.automations ? store.automations.violationProtection : null;
      if (cfg && typeof cfg.delaySeconds === 'number') {
        this.delaySeconds = Math.max(0, Math.min(120, parseInt(cfg.delaySeconds, 10) || 0));
      }
    }
  },

  async setDelaySeconds(sec) {
    this.delaySeconds = Math.max(0, Math.min(120, parseInt(sec, 10) || 0));
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('violationProtection', true, { delaySeconds: this.delaySeconds });
    }
  },

  acharTimer() {
    const els = this.$s('div, span, p, b, strong');
    for (let i = 0; i < els.length; i++) {
      const e = els[i];
      if (e.children.length === 0) {
        const t = (e.textContent || '').trim();
        if (/^\d{1,2}:\d{2}:\d{2}$/.test(t) && this.vis(e) && this.fora(e)) {
          return e;
        }
      }
    }
    return null;
  },

  acharPower(tm) {
    if (!tm) return null;
    let el = tm;
    const tr = tm.getBoundingClientRect();
    for (let up = 0; up < 9 && el; up++) {
      el = el.parentElement;
      if (!el) break;
      const cands = this.$s('button, [role="button"], svg', el).filter((b) => {
        if (!this.vis(b) || !this.fora(b)) return false;
        if (((b.textContent || '').trim()) !== '') return false;
        const r = b.getBoundingClientRect();
        if (!(r.left > tr.right - 2 && Math.abs((r.top + r.height / 2) - (tr.top + tr.height / 2)) < 30)) return false;
        return b.tagName === 'BUTTON' || getComputedStyle(b).cursor === 'pointer';
      });
      if (cands.length) {
        cands.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
        return cands[0];
      }
    }
    return null;
  },

  botaoConfirmar() {
    const bs = this.$s('button, [role="button"]').filter((b) => {
      const t = (b.textContent || '').trim();
      return this.vis(b) && this.fora(b) && /Encerrar|Confirmar|Sim|End/i.test(t) && !/Cancelar|Cancel/i.test(t) && t.length < 40;
    });
    return bs.length ? bs[bs.length - 1] : null;
  },

  achaAviso() {
    const dots = this.$s('span, sup, i, b, div');
    for (let i = 0; i < dots.length; i++) {
      const e = dots[i];
      const cls = (e.className || '').toString();
      if (cls.indexOf('m4b-badge-dot') < 0) continue;
      if (!this.vis(e) || !this.fora(e)) continue;
      const r = e.getBoundingClientRect();
      if (r.top > 170) continue;
      let p = e;
      for (let k = 0; k < 5 && p; k++) {
        const b = p.querySelector ? p.querySelector('button, [role="button"]') : null;
        if (b && this.vis(b) && this.fora(b)) return b;
        if (p.tagName === 'BUTTON') return p;
        p = p.parentElement;
      }
    }
    return null;
  },

  detecta() {
    const els = this.$s('div, span, p, h1, h2, h3, b, strong');
    let temPainel = false;
    for (let i = 0; i < els.length; i++) {
      const t0 = (els[i].textContent || '').trim();
      if (/^Lembrete de viola/i.test(t0) && els[i].children.length <= 3 && this.vis(els[i])) {
        temPainel = true; break;
      }
    }

    if (temPainel) {
      let conta = null;
      for (let j = 0; j < els.length; j++) {
        if (els[j].children.length > 0) continue;
        const tj = (els[j].textContent || '').trim();
        const mm = tj.match(/^Todos?\s*\((\d+)\)/i);
        if (mm) { conta = parseInt(mm[1], 10); break; }
      }
      if (conta !== null && conta > 0) {
        return `Violação no painel (Todos ${conta})`;
      }
    }

    const re = /(sua live pode ser suspensa|sua transmiss[aã]o pode ser suspensa|live foi encerrada por viola|live ser[aá] encerrada por viola|viola[cç][aã]o das diretrizes|conte[uú]do impr[oó]prio detect|penalidade aplicad|foi sinalizada por viola)/i;
    for (let k = 0; k < els.length; k++) {
      const e = els[k];
      if (e.children.length !== 0) continue;
      const cls = (e.className || '').toString();
      if (cls.indexOf('text-body') > -1) continue;
      if (!this.vis(e) || !this.fora(e)) continue;
      const x = (e.textContent || '').trim();
      if (x && x.length < 300 && re.test(x)) {
        if (this.ehConfig(e)) continue;
        return x.slice(0, 75);
      }
    }
    return null;
  },

  cancelTermination() {
    this.detectedAt = 0;
    this.suspectedAlert = null;
    this.state = 'MONITORING';
    this.updateUI();
    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Segurança', 'Encerramento de emergência cancelado pelo usuário. Proteção continua ARMED e MONITORANDO.');
    }
  },

  async tick() {
    const isLicenseValid = window.LiveInfinityLicense && typeof LiveInfinityLicense.isCurrentValid === 'function' ? LiveInfinityLicense.isCurrentValid() : true;
    if (!isLicenseValid) {
      this.state = 'DISABLED_BY_LICENSE';
      this.updateUI();
      return;
    }

    const tm = this.acharTimer();
    const agora = Date.now();

    if (this.state === 'ENDING' || this.state === 'ENDED') {
      const cf = this.botaoConfirmar();
      if (cf) this.clicar(cf);
      if (!tm) {
        this.state = 'ENDED';
      }
      this.updateUI();
      return;
    }

    if (!tm) {
      this.state = 'ARMED';
      this.detectedAt = 0;
      this.suspectedAlert = null;
      this.updateUI();
      return;
    }

    // Se a live está rodando e a proteção estava ARMED, passa para MONITORING
    if (this.state === 'ARMED') {
      this.state = 'MONITORING';
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Segurança', 'Live detectada — Proteção de emergência em MONITORAMENTO ATIVO. 🛡️');
      }
    }

    const av = this.detecta();

    if (!av) {
      const ic = this.achaAviso();
      if (ic && (agora - this.lastOpenNotification > 6000)) {
        this.lastOpenNotification = agora;
        this.clicar(ic);
        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Segurança', '🔎 Bolinha de notificação detectada no topo — verificando alerta de diretrizes...');
        }
      }
      if (this.state === 'SUSPECTED') {
        this.state = 'MONITORING';
      }
      this.updateUI();
      return;
    }

    // 1. Etapa de Suspeita (Dupla Leitura)
    if (this.state === 'MONITORING') {
      this.state = 'SUSPECTED';
      this.suspectedAlert = av;
      this.suspectedAt = agora;
      this.updateUI();
      return;
    }

    // 2. Etapa de Confirmação (Alerta mantido na leitura seguinte)
    if (this.state === 'SUSPECTED') {
      this.state = 'CONFIRMED';
      this.detectedAt = agora;
      this.lastHandledViolationId = `${av}_${agora}`;
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Segurança', `🚨 VIOLAÇÃO GRAVE CONFIRMADA: "${av}"`);
      }
    }

    // 3. Etapa de Countdown vs Encerramento Imediato
    const atrasoMs = this.delaySeconds * 1000;
    const decorrido = agora - this.detectedAt;
    const restaMs = atrasoMs - decorrido;

    if (restaMs > 0) {
      this.state = 'COUNTDOWN';
      this.updateUI(Math.ceil(restaMs / 1000));
      return;
    }

    // 4. Iniciar Encerramento
    this.state = 'ENDING';
    this.updateUI();

    const pw = this.acharPower(tm);
    if (pw) {
      this.clicar(pw);
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Segurança', '🚨 Clicando no botão de encerramento da LIVE por violação grave!');
      }
      setTimeout(() => {
        const cf = this.botaoConfirmar();
        if (cf) this.clicar(cf);
      }, 500);
    } else {
      this.state = 'ERROR';
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Segurança', '❌ Falha: Violação confirmada mas botão de desligar a LIVE não foi localizado!');
      }
    }
  },

  updateUI(restaSegundos = 0) {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;

    const badge = shadow.getElementById('li-rv-badge');
    const desc = shadow.getElementById('li-rv-state-desc');
    const statusText = shadow.getElementById('li-rv-status');
    const countdownBox = shadow.getElementById('li-rv-countdown-box');
    const countdownText = shadow.getElementById('li-rv-countdown-text');
    const btnCancel = shadow.getElementById('li-btn-cancel-rv');
    const inputDelay = shadow.getElementById('li-rv-delay');

    if (inputDelay && document.activeElement !== inputDelay && shadow.activeElement !== inputDelay) {
      inputDelay.value = String(this.delaySeconds);
    }

    if (!badge || !desc) return;

    switch (this.state) {
      case 'DISABLED_BY_LICENSE':
        badge.textContent = 'BLOQUEADA';
        badge.className = 'li-status-indicator li-status-blocked';
        desc.textContent = '🔒 BLOQUEADA — licença pendente ou inválida';
        if (statusText) statusText.textContent = 'Ative sua chave oficial para habilitar a proteção.';
        if (countdownBox) countdownBox.style.display = 'none';
        break;

      case 'ARMED':
        badge.textContent = 'ARMADA';
        badge.className = 'li-status-indicator li-status-active';
        desc.textContent = '🛡️ ARMADA — aguardando a live iniciar';
        if (statusText) statusText.textContent = 'Proteção obrigatória ativada. Aguardando transmissão no TikTok.';
        if (countdownBox) countdownBox.style.display = 'none';
        break;

      case 'MONITORING':
        badge.textContent = 'ATIVA';
        badge.className = 'li-status-indicator li-status-active';
        desc.textContent = '🛡️ ATIVA — monitorando violações em tempo real';
        if (statusText) statusText.textContent = 'Varrendo alertas de diretrizes e notificações do TikTok Shop.';
        if (countdownBox) countdownBox.style.display = 'none';
        break;

      case 'SUSPECTED':
        badge.textContent = 'AVISO DETECTADO';
        badge.className = 'li-status-indicator li-status-starting';
        desc.textContent = '⚠️ AVISO DETECTADO — confirmando alerta...';
        if (statusText) statusText.textContent = `Validando autenticidade do alerta: "${this.suspectedAlert || ''}"`;
        if (countdownBox) countdownBox.style.display = 'none';
        break;

      case 'CONFIRMED':
      case 'COUNTDOWN':
        badge.textContent = 'VIOLAÇÃO CONFIRMADA';
        badge.className = 'li-status-indicator li-status-inactive';
        desc.textContent = `🚨 VIOLAÇÃO CONFIRMADA — encerramento em ${restaSegundos}s`;
        if (statusText) statusText.textContent = `Alerta grave: "${this.suspectedAlert || ''}"`;
        if (countdownBox) {
          countdownBox.style.display = 'block';
          if (countdownText) countdownText.textContent = `🚨 Violação confirmada — Encerramento em ${restaSegundos}s`;
        }
        break;

      case 'ENDING':
        badge.textContent = 'ENCERRANDO LIVE';
        badge.className = 'li-status-indicator li-status-inactive';
        desc.textContent = '🚨 ENCERRANDO TRANSMISSÃO AGORA!';
        if (statusText) statusText.textContent = 'Acionando comandos de encerramento de emergência do TikTok.';
        if (countdownBox) countdownBox.style.display = 'none';
        break;

      case 'ENDED':
        badge.textContent = 'LIVE ENCERRADA';
        badge.className = 'li-status-indicator li-status-active';
        desc.textContent = '✅ LIVE ENCERRADA POR PROTEÇÃO DE EMERGÊNCIA';
        if (statusText) statusText.textContent = 'A transmissão foi encerrada com sucesso evitando penalidades maiores.';
        if (countdownBox) countdownBox.style.display = 'none';
        break;

      case 'ERROR':
        badge.textContent = 'ERRO NA PROTEÇÃO';
        badge.className = 'li-status-indicator li-status-inactive';
        desc.textContent = '❌ FALHA NA PROTEÇÃO — botão de desligar não encontrado';
        if (statusText) statusText.textContent = 'Violação confirmada mas a interface do TikTok não respondeu aos comandos.';
        if (countdownBox) countdownBox.style.display = 'none';
        break;
    }

    if (btnCancel && !btnCancel.hasAttribute('data-bound')) {
      btnCancel.setAttribute('data-bound', 'true');
      btnCancel.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        this.cancelTermination();
      });
    }

    if (inputDelay && !inputDelay.hasAttribute('data-bound')) {
      inputDelay.setAttribute('data-bound', 'true');
      inputDelay.addEventListener('input', async (e) => {
        const val = parseInt(e.target.value, 10);
        if (!isNaN(val)) {
          await this.setDelaySeconds(val);
        }
      });
    }
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityViolationProtect = LiveInfinityViolationProtect;
}
