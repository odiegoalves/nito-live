'use strict';

/* ===== Live Infinity — Gerenciador Central de Estado & Restauração Pós-F5 (v1.0.0) ===== */
function assertStorageKey(key, moduleName) {
  if (typeof key !== 'string' || key.trim() === '') {
    throw new TypeError(`[${moduleName}] Chave de armazenamento inválida: "${key}"`);
  }
  return key.trim();
}

const LiveInfinityStateStore = {
  STORAGE_KEY: 'live_infinity_automations_state',
  initialized: false,
  state: {
    schemaVersion: 4,
    automations: {
      productPin: { desiredEnabled: false, intervalSeconds: 40, runtimeStatus: 'STOPPED' },
      flashDeal: { desiredEnabled: false, runtimeStatus: 'STOPPED' },
      autoComments: { desiredEnabled: false, intervalSeconds: 90, runtimeStatus: 'STOPPED' },
      autoReplies: { desiredEnabled: false, mentionUser: true, runtimeStatus: 'STOPPED' },
      buyerIntent: { desiredEnabled: false, runtimeStatus: 'STOPPED' },
      purchaseThanks: { desiredEnabled: false, runtimeStatus: 'STOPPED' },
      nameBlock: { desiredEnabled: false, runtimeStatus: 'STOPPED' },
      violationProtection: { desiredEnabled: true, mandatory: true, delaySeconds: 0, runtimeStatus: 'ARMED' },
      mobileNotification: { desiredEnabled: false, runtimeStatus: 'STOPPED' },
      saleSound: { desiredEnabled: true, runtimeStatus: 'RUNNING' }
    },
    timer: {
      desiredEnabled: false,
      status: 'OFF',
      totalDurationMs: 7200000,
      endsAt: null,
      pausedRemainingMs: null,
      completionHandled: false
    }
  },

  async init() {
    if (this.initialized) return this.state;
    this.initialized = true;
    await this.loadState();
    return this.state;
  },

  async loadState() {
    const key = assertStorageKey(LIVE_INFINITY_CONFIG.STORAGE_KEYS.AUTOMATIONS_STATE || this.STORAGE_KEY, 'state_store');

    return new Promise((resolve) => {
      const applyData = (data) => {
        if (data && data.automations) {
          this.state = {
            schemaVersion: 4,
            automations: { ...this.state.automations, ...data.automations },
            timer: { ...this.state.timer, ...(data.timer || {}) }
          };
        }
        if (this.state.automations.violationProtection) {
          this.state.automations.violationProtection.desiredEnabled = true;
          this.state.automations.violationProtection.mandatory = true;
        }
        resolve(this.state);
      };

      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get([key], (res) => {
          applyData(res ? res[key] : null);
        });
      } else {
        try {
          const raw = localStorage.getItem(key);
          applyData(raw ? JSON.parse(raw) : null);
        } catch (e) {
          applyData(null);
        }
      }
    });
  },

  async setDesiredState(automationKey, desiredEnabled, extraData = {}) {
    if (this.state.automations[automationKey]) {
      if (automationKey === 'violationProtection') {
        desiredEnabled = true;
      }
      this.state.automations[automationKey].desiredEnabled = !!desiredEnabled;
      this.state.automations[automationKey].runtimeStatus = desiredEnabled ? 'RUNNING' : 'STOPPED';
      if (extraData && typeof extraData === 'object') {
        Object.assign(this.state.automations[automationKey], extraData);
      }
    }
    await this.saveState();
  },

  async setRuntimeStatus(automationKey, status) {
    if (this.state.automations[automationKey]) {
      this.state.automations[automationKey].runtimeStatus = status;
    }
    await this.saveState();
  },

  async setTimerState(timerData) {
    if (timerData && typeof timerData === 'object') {
      Object.assign(this.state.timer, timerData);
    }
    await this.saveState();
  },

  async saveState() {
    const key = assertStorageKey(LIVE_INFINITY_CONFIG.STORAGE_KEYS.AUTOMATIONS_STATE || this.STORAGE_KEY, 'state_store');

    try {
      localStorage.setItem(key, JSON.stringify(this.state));
    } catch (e) {}

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise((resolve) => {
        chrome.storage.local.set({ [key]: this.state }, () => {
          resolve(true);
        });
      });
    }
    return true;
  }
};

/* ===== Live Infinity — Gerenciador Central de Sessão & Estado do Rodapé ===== */
const FOOTER_STATUS_LABELS = {
  waiting_live: '● AGUARDANDO LIVE',
  live_detected: '● PREPARANDO LIVE',
  operating: '● AO VIVO',
  ending: '● ENCERRANDO LIVE',
  ended: '● AGUARDANDO LIVE',
  resetting: '● AGUARDANDO LIVE',
  offline: '● SEM CONEXÃO'
};

const LiveSessionStore = {
  session: {
    sessionId: null,
    status: 'waiting_live', // 'waiting_live' | 'live_detected' | 'operating' | 'ending' | 'ended' | 'resetting' | 'offline'
    liveDetected: false,
    startedAt: null,
    endedAt: null
  },
  confirmationsCount: 0,
  absenceCount: 0,
  isResetting: false,
  monitorTimer: null,

  init() {
    this.startSessionMonitor();
  },

  startSessionMonitor() {
    if (this.monitorTimer) clearInterval(this.monitorTimer);
    this.monitorTimer = setInterval(() => this.checkLiveStatus(), 2000);
    this.checkLiveStatus();
  },

  setSessionStatus(nextStatus) {
    const currentStatus = this.session.status;
    if (currentStatus === nextStatus) {
      this.renderFooterLiveStatus(currentStatus);
      return;
    }

    // REGRA DE IMPEDIMENTO DE REGRESSÃO DE ESTADO: operating -> live_detected É INVÁLIDA!
    if (currentStatus === 'operating' && nextStatus === 'live_detected') {
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Sessão', `[Session] Transição ignorada: ${currentStatus} → ${nextStatus}`);
      }
      return;
    }

    // Transições Válidas Permitidas
    const validTransitions = {
      waiting_live: ['live_detected', 'operating', 'offline'],
      live_detected: ['operating', 'waiting_live', 'ended', 'offline'],
      operating: ['ending', 'ended', 'resetting', 'waiting_live', 'offline'],
      ending: ['ended', 'resetting', 'waiting_live'],
      ended: ['resetting', 'waiting_live'],
      resetting: ['waiting_live'],
      offline: ['waiting_live', 'live_detected']
    };

    const allowedNext = validTransitions[currentStatus] || ['waiting_live'];
    if (!allowedNext.includes(nextStatus)) {
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Sessão', `[Session] Transição inválida bloqueada: ${currentStatus} → ${nextStatus}`);
      }
      return;
    }

    this.session.status = nextStatus;
    this.session.liveDetected = (nextStatus === 'operating' || nextStatus === 'live_detected');

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Sessão', `[Session] Transição de estado: ${currentStatus} → ${nextStatus}`);
    }

    this.renderFooterLiveStatus(nextStatus);
  },

  detectNativeTikTokLive() {
    const $s = (sel, root) => Array.prototype.slice.call((root || document).querySelectorAll(sel));
    const isOutside = (el) => {
      if (!el) return false;
      const root = el.getRootNode ? el.getRootNode() : null;
      if (root === window.__liveInfinityShadow) return false;
      return true;
    };

    const timerNodes = $s('div, span, p, b, strong').filter(e => {
      if (e.children.length !== 0 || !isOutside(e)) return false;
      const txt = (e.textContent || '').trim();
      const r = e.getBoundingClientRect();
      return /^\d{1,2}:\d{2}:\d{2}$/.test(txt) && r.width > 0 && r.height > 0 && txt.length < 12;
    });

    if (timerNodes.length > 0) return true;

    const liveBadges = $s('span, div, p, b, strong').filter(e => {
      if (e.children.length !== 0 || !isOutside(e)) return false;
      const txt = (e.textContent || '').trim();
      const r = e.getBoundingClientRect();
      const isBadgeText = (txt === 'AO VIVO' || txt === '● AO VIVO' || txt === 'LIVE' || txt === 'Transmitindo' || txt === 'TRANSMITINDO');
      return isBadgeText && txt.length < 15 && r.width > 0 && r.height > 0;
    });

    let powerBtn = null;
    if (window.LiveInfinityTimer && typeof window.LiveInfinityTimer.findTikTokEndLiveButton === 'function') {
      try {
        powerBtn = window.LiveInfinityTimer.findTikTokEndLiveButton();
      } catch (e) {
        powerBtn = null;
      }
    }
    return !!powerBtn;
  },

  checkLiveStatus() {
    if (this.isResetting || this.session.status === 'ending' || this.session.status === 'resetting') {
      this.renderFooterLiveStatus(this.session.status);
      return;
    }

    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      this.setSessionStatus('offline');
      return;
    }

    const isLiveOnAir = this.detectNativeTikTokLive();
    const REQUIRED_CONFIRMATIONS = 3;

    if (isLiveOnAir) {
      this.absenceCount = 0;
      if (this.session.status === 'waiting_live' || this.session.status === 'offline') {
        this.confirmationsCount = 1;
        this.onLiveDetectedInitial();
      } else if (this.session.status === 'live_detected') {
        this.confirmationsCount++;
        if (this.confirmationsCount >= REQUIRED_CONFIRMATIONS) {
          this.setSessionStatus('operating');
        }
      } else if (this.session.status === 'operating') {
        this.renderFooterLiveStatus('operating');
      }
    } else {
      this.confirmationsCount = 0;
      if (this.session.status === 'operating' || this.session.status === 'live_detected') {
        this.absenceCount++;
        if (this.absenceCount >= REQUIRED_CONFIRMATIONS) {
          this.onLiveEnded();
        }
      } else {
        this.renderFooterLiveStatus(this.session.status);
      }
    }
  },

  async onLiveDetectedInitial() {
    const newSessionId = `live_sess_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;
    this.session.sessionId = newSessionId;
    this.session.startedAt = Date.now();

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Sessão', `🔴 NOVA TRANSMISSÃO DETECTADA NO TIKTOK! ID da Sessão: ${newSessionId}`);
      if (typeof LiveInfinityCore.restoreActiveAutomations === 'function') {
        await LiveInfinityCore.restoreActiveAutomations();
      }
    }

    if (window.LiveInfinityDashboard && typeof LiveInfinityDashboard.resetSessionMetrics === 'function') {
      LiveInfinityDashboard.resetSessionMetrics();
    }

    this.setSessionStatus('live_detected');
  },

  onLiveEnded() {
    if (this.session.status === 'ended' || this.session.status === 'resetting') return;
    this.setSessionStatus('ending');
    this.session.endedAt = Date.now();
    this.session.liveDetected = false;

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Sessão', `🏁 TRANSMISSÃO ENCERRADA. Executando reset controlado da sessão...`);
    }

    this.resetLiveSession('live_ended');
  },

  async resetLiveSession(reason = 'live_ended') {
    if (this.isResetting) return;
    this.isResetting = true;
    this.setSessionStatus('resetting');

    try {
      if (window.LiveInfinityCore) {
        await LiveInfinityCore.stopOperationalAutomationsOnly(reason);
      }

      if (window.LiveInfinityChat) {
        LiveInfinityChat.replyQueue = [];
        LiveInfinityChat.commentIndex = 0;
        LiveInfinityChat.lastSentMessage = '';
      }

      if (window.LiveInfinityDashboard) {
        LiveInfinityDashboard.resetSessionMetrics();
      }

      if (window.LiveInfinityTimer) {
        LiveInfinityTimer.resetTimerToIdle();
      }

      this.session.sessionId = null;
      this.session.liveDetected = false;
      this.session.endedAt = Date.now();
      this.confirmationsCount = 0;
      this.absenceCount = 0;

      if (window.LiveInfinityStateStore) {
        await LiveInfinityStateStore.setTimerState({
          desiredEnabled: false,
          status: 'IDLE',
          endsAt: null,
          pausedRemainingMs: null,
          completionHandled: false
        });
      }

      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Sessão', `✨ Reset controlado concluído! Preservadas configurações e licença. Aguardando próxima live.`);
      }

      this.setSessionStatus('waiting_live');
    } finally {
      this.isResetting = false;
    }
  },

  // ÚNICA FUNÇÃO AUTORIZADA A ESCREVER NO RODAPÉ E CABEÇALHO DA INTERFACE
  renderFooterLiveStatus(sessionStatus) {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;

    const label = FOOTER_STATUS_LABELS[sessionStatus] || FOOTER_STATUS_LABELS.waiting_live;
    const statusBadge = shadow.getElementById('li-status-badge');
    const liveStatusText = shadow.getElementById('li-mini-live-status');
    const barStatusText = shadow.getElementById('li-bar-live-status');

    const isLiveActive = sessionStatus === 'operating';

    // 1. Sincronizar Cabeçalho
    if (statusBadge) {
      let headerText = 'AGUARDANDO LIVE';
      let headerClass = 'li-status-indicator li-status-inactive';

      if (sessionStatus === 'operating') {
        headerText = '● ATIVO';
        headerClass = 'li-status-indicator li-status-active';
      } else if (sessionStatus === 'live_detected') {
        headerText = 'PREPARANDO';
        headerClass = 'li-status-indicator li-status-active';
      } else if (sessionStatus === 'ending') {
        headerText = 'ENCERRANDO';
        headerClass = 'li-status-indicator li-status-active';
      } else if (sessionStatus === 'offline') {
        headerText = 'SEM CONEXÃO';
        headerClass = 'li-status-indicator li-status-inactive';
      }

      if (statusBadge.textContent !== headerText) {
        statusBadge.textContent = headerText;
        statusBadge.className = headerClass;
      }
    }

    // 2. Sincronizar Mini Painel (Modo Minimizado com Rótulos Compactos)
    if (liveStatusText) {
      let miniLabel = 'AGUARDANDO';
      let miniClass = 'li-status-indicator li-status-inactive minimized-status';

      if (sessionStatus === 'operating') {
        miniLabel = 'AO VIVO';
        miniClass = 'li-status-indicator li-status-active minimized-status';
      } else if (sessionStatus === 'live_detected') {
        miniLabel = 'PREPARANDO';
        miniClass = 'li-status-indicator li-status-active minimized-status';
      } else if (sessionStatus === 'ending') {
        miniLabel = 'ENCERRANDO';
        miniClass = 'li-status-indicator li-status-active minimized-status';
      } else if (sessionStatus === 'offline') {
        miniLabel = 'SEM CONEXÃO';
        miniClass = 'li-status-indicator li-status-inactive minimized-status';
      }

      if (liveStatusText.textContent !== miniLabel) {
        liveStatusText.textContent = miniLabel;
        liveStatusText.className = miniClass;
      }
    }

    // 3. Sincronizar Barra Inferior
    if (barStatusText && barStatusText.textContent !== label) {
      barStatusText.textContent = label;
    }
  },

  updateHeaderAndFooterUI() {
    this.renderFooterLiveStatus(this.session ? this.session.status : 'waiting_live');
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityStateStore = LiveInfinityStateStore;
  window.LiveSessionStore = LiveSessionStore;
}
