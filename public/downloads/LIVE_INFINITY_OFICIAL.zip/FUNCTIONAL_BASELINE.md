# Live Infinity — Baseline Funcional Aprovada (2026-07-31)

Este documento registra a baseline funcional imutável da **Live Infinity**, contendo o inventário técnico completo, os hashes SHA-256 e a responsabilidade de cada módulo.

---

## 1. Identificação Geral

- **Nome da Aplicação**: Live Infinity
- **Versão da Baseline**: 1.0.1 (Baseline Funcional Aprovada)
- **Data da Baseline**: 2026-07-31
- **Status da Versão**: CONGELADA PARA HOMOLOGAÇÃO COMERCIAL

---

## 2. Inventário Técnico dos Arquivos Funcionais e Hashes SHA-256

| Arquivo | Tamanho (Bytes) | Hash SHA-256 | Responsabilidade Técnica Principal |
| :--- | :--- | :--- | :--- |
| `manifest.json` | 1677 | 8372602a0cb9d362f791727a1cdf753d8c7fc5213b1d69034580139a16743aa0 | Configuração do Chrome Extension V3, permissões e scripts |
| `background.js` | 4679 | 490f373c480558e6ce5489104cd72116e48d2d456614a132d8472fa40f266b77 | Service Worker, persistência do chrome.storage e revalidação |
| `content.js` | 23118 | dcf01d047b04fd9f6a2e7b078689692a3a00de4195501f39e7140eaf9c3180cc | Injeção do Shadow DOM, escuta de eventos nativos do TikTok |
| `automation_store.js` | 14884 | 1bf5440a7aa992f38d22bddfc18c908602afe7fdc11d2b3e844c8d654de86a58 | Máquina de Estado Central, ciclo de sessão da live e reset |
| `license.js` | 12560 | a61e94f3c9489e5f7d6dc547e37dccd166c7fe59e423e24b58fe1ab1c767ae2f | Autenticação por chave, validação no backend oficial e revalidação |
| `timer.js` | 29039 | a7abedaf7d0c6345dad71fda738f640017d1b85944f0016b83057fcc879ec93f | Contagem regressiva, motor do LiveGoPro, botão de energia e modal |
| `ui_manager.js` | 34500 | 6043f2dcc4fb2130d9637f31eda868ae4899ac5e97c6d2be98b5b01f7632e5d6 | Interface Shadow DOM, mini painel minimizado (230x82) e abas |
| `styles.js` | 19319 | 273ab97af4437fe5fe0842e08e90d1d082911197a23f13e6615a4e59b7946ca1 | Estilos CSS isolados, tema dark/gold, responsividade e layout |

---

## 3. Descrição dos Motores Funcionais Congelados

1. **Licenciamento & Autenticação**: Validação direta contra `https://admin.valoranegocios.com.br/painel-seguro-liveinfinity/`.
2. **Estado Central da Sessão (`LiveSessionStore`)**: Estados unificados (`waiting_live`, `operating`, `ending`, `ended`, `resetting`, `offline`).
3. **Timer & Encerramento Nativo (`LiveInfinityTimer`)**: Algoritmo do LiveGoPro com verificação de posição à direita do timer nativo, rejeição de switches (`Vídeo`, `Roteiro`, `Áudio`) e confirmação de modal.
4. **Comentários Automáticos Loop**: Distribuição contínua e circular dos comentários de produto.
5. **Menções e Alertas**: Captura de eventos do TikTok e disparo de menções para carrinho e compra.
