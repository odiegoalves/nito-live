'use strict';

/* ===== Live Infinity — Automação de Refixação de Produtos ===== */
const LiveInfinityProductPin = {
  active: false,
  timerInterval: null,
  timerInterval60: null,
  attempts: 0,
  last60sTime: 0,

  async start(isRestoration = false) {
    this.active = true;
    this.attempts = 0;
    
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('productPin', true);
    }

    const shadow = window.__liveInfinityShadow;
    const intervalInput = shadow ? shadow.getElementById('li-rf-intervalo') : null;
    const seconds = Math.max(10, parseInt(intervalInput ? intervalInput.value : 40, 10) || 40);

    this.runCycle();
    if (this.timerInterval) clearInterval(this.timerInterval);
    if (this.timerInterval60) clearInterval(this.timerInterval60);

    this.timerInterval = setInterval(() => this.runCycle(), seconds * 1000);
    this.timerInterval60 = setInterval(() => this.run60sExtensionCycle(), 3000);

    this.updateStatus('Ativo — refixando produto nº 1...');
    LiveInfinityCore.log('Refixar', `Automação ${isRestoration ? 'restaurada' : 'iniciada'} (intervalo: ${seconds}s)`);
  },

  async stop() {
    this.active = false;
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('productPin', false);
    }
    if (this.timerInterval) clearInterval(this.timerInterval);
    if (this.timerInterval60) clearInterval(this.timerInterval60);
    this.timerInterval = null;
    this.timerInterval60 = null;
    this.updateStatus('Desligado.');
    LiveInfinityCore.log('Refixar', 'Automação parada');
  },

  restore() {
    this.start(true);
  },

  toggle() {
    if (this.active) this.stop();
    else this.start();
  },

  updateStatus(msg) {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;
    const el = shadow.getElementById('li-rf-status');
    const btn = shadow.getElementById('li-rf-botao');
    if (el) el.textContent = msg;
    if (btn) {
      if (this.active) {
        btn.textContent = '⏸ Parar Refixação';
        btn.classList.add('li-btn-stop');
      } else {
        btn.textContent = '▶ Iniciar Refixação';
        btn.classList.remove('li-btn-stop');
      }
    }
  },

  isCoupon(btnEl) {
    let parent = btnEl;
    for (let i = 0; i < 10 && parent; i++) {
      parent = parent.parentElement;
      if (!parent) break;
      const txt = parent.textContent || '';
      if (txt.indexOf('Em estoque') > -1 || txt.indexOf('Quantidade') > -1) return false;
      if (/cupom|desconto|gasto m/i.test(txt)) return true;
    }
    return false;
  },

  isProduct(btnEl) {
    let parent = btnEl;
    for (let i = 0; i < 10 && parent; i++) {
      parent = parent.parentElement;
      if (!parent) break;
      const txt = parent.textContent || '';
      if (txt.indexOf('Lista de produtos nesta LIVE') > -1) return false;
      if (txt.length > 700) return false;
      if (txt.indexOf('Em estoque') > -1 || txt.indexOf('Quantidade') > -1) return true;
    }
    return false;
  },

  hasNew60sModel() {
    return LiveInfinityDOM.toArray(document.querySelectorAll('div, span, p')).some((e) => {
      if (e.children.length > 2) return false;
      const txt = (e.textContent || '').trim();
      return txt.length < 90 && /(esta fixa[çc][aã]o termina|fixe por mais|fixar por mais)/i.test(txt);
    });
  },

  findPlus60Button() {
    const candidates = LiveInfinityDOM.toArray(document.querySelectorAll('button, [role="button"], div, span')).filter((b) => {
      if (!LiveInfinityDOM.isVisible(b)) return false;
      const txt = (b.textContent || '').trim();
      return /^\+\s*\d{1,3}\s*s$/.test(txt);
    });
    return candidates.length ? candidates[0] : null;
  },

  run60sExtensionCycle() {
    if (!this.active) return;
    if (!this.hasNew60sModel()) return;
    const btn = this.findPlus60Button();
    if (!btn) return;
    if (Date.now() - this.last60sTime < 8000) return;

    this.last60sTime = Date.now();
    LiveInfinityDOM.clickElement(btn);
    this.updateStatus('Fixação estendida +60s ✅ ' + new Date().toLocaleTimeString());
    LiveInfinityCore.log('Refixar', 'Fixação estendida em +60s');
  },

  runCycle() {
    if (!this.active) return;

    if (this.hasNew60sModel()) {
      const btn = this.findPlus60Button();
      if (btn) {
        if (Date.now() - this.last60sTime >= 8000) {
          this.last60sTime = Date.now();
          LiveInfinityDOM.clickElement(btn);
          this.updateStatus('Fixação estendida +60s ✅ ' + new Date().toLocaleTimeString());
        }
      } else {
        this.updateStatus('Modelo novo detectado — aguardando botão +60s...');
      }
      return;
    }

    const allButtons = LiveInfinityDOM.toArray(document.querySelectorAll('button, [role="button"]')).filter((b) => {
      const txt = (b.textContent || '').trim();
      return txt === 'Fixar' || txt === 'Desafixar';
    });

    const products = allButtons.filter(b => this.isProduct(b) && !this.isCoupon(b));

    if (products.length === 0) {
      if (this.attempts < 10) {
        this.attempts++;
        this.updateStatus(`Procurando produtos (${this.attempts}/10)...`);
        setTimeout(() => this.runCycle(), 2500);
      } else {
        this.updateStatus('Nenhum produto encontrado na lista.');
      }
      return;
    }

    this.attempts = 0;
    const targetProduct = products[0];

    const extraUnpins = allButtons.filter(b => b.textContent.trim() === 'Desafixar' && b !== targetProduct);
    if (extraUnpins.length > 0) {
      this.updateStatus('Removendo cupom/fixação extra...');
      LiveInfinityDOM.clickElement(extraUnpins[0]);
      setTimeout(() => this.runCycle(), 700);
      return;
    }

    if (targetProduct.textContent.trim() === 'Fixar') {
      LiveInfinityDOM.clickElement(targetProduct);
      this.updateStatus('Produto nº 1 fixado ✅ ' + new Date().toLocaleTimeString());
      LiveInfinityCore.log('Refixar', 'Produto nº 1 fixado com sucesso');
      return;
    }

    LiveInfinityDOM.clickElement(targetProduct);
    this.updateStatus('Refixando produto nº 1...');
    setTimeout(() => this.runCycle(), 600);
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityProductPin = LiveInfinityProductPin;
}
