'use strict';

/* ===== Live Infinity — Alertas de Vendas, Som de Caixa Registradora & ntfy.sh (v1.0.0) ===== */

const NTFY_CONFIG_KEY = 'liveInfinityNtfyConfig';

const LiveInfinitySalesAlert = {
  active: false,        // Notificações no celular ativadas (enabled)
  soundEnabled: true,   // Som de caixa registradora ativado
  channel: '',          // Canal ntfy.sh salvo
  draftChannel: '',     // Rascunho sendo editado no campo
  status: 'NÃO CONFIGURADO',
  lastSuccessfulTestAt: null,
  lastSentAt: null,
  lastErrorMsg: '',
  notifiedSalesCache: new Set(),
  audioInstance: null,

  async init() {
    await this.loadSettings();
    this.preloadSound();
    return true;
  },

  preloadSound() {
    try {
      let soundUrl = '';
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
        soundUrl = chrome.runtime.getURL('assets/audio/caixa-registradora.mp3');
      } else {
        soundUrl = 'assets/audio/caixa-registradora.mp3';
      }
      this.audioInstance = new Audio(soundUrl);
      this.audioInstance.volume = 0.85;
    } catch (e) {
      console.warn('[Live Infinity] Não foi possível pré-carregar o áudio de caixa registradora:', e);
    }
  },

  sanitizeProductName(value) {
    return String(value ?? '')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 80);
  },

  parseBRL(value) {
    if (typeof value === 'number') return isNaN(value) ? null : value;
    if (!value) return null;
    const str = String(value).trim();
    const cleanStr = str.replace(/\s/g, '').replace(/R\$/gi, '');
    if (!cleanStr) return null;

    let numericVal = NaN;
    if (/^\d{1,3}(\.\d{3})*,\d{2}$/.test(cleanStr)) {
      numericVal = parseFloat(cleanStr.replace(/\./g, '').replace(',', '.'));
    } else if (/^\d+(,\d+)?$/.test(cleanStr)) {
      numericVal = parseFloat(cleanStr.replace(',', '.'));
    } else if (!isNaN(parseFloat(cleanStr))) {
      numericVal = parseFloat(cleanStr);
    }

    return Number.isFinite(numericVal) && numericVal > 0 ? numericVal : null;
  },

  formatBRL(value) {
    const num = this.parseBRL(value);
    if (num === null) return 'aguardando confirmação';
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(num).replace(/\u00A0/g, ' ');
  },

  normalizeNtfyTopic(rawInput) {
    if (!rawInput || typeof rawInput !== 'string') return '';
    let str = rawInput.trim();
    if (!str) return '';

    str = str.replace(/^https?:\/\//i, '');
    str = str.replace(/^ntfy\.sh\//i, '');
    str = str.replace(/^\/+|\/+$/g, '');

    const qIdx = str.indexOf('?');
    if (qIdx > -1) str = str.slice(0, qIdx);
    const hIdx = str.indexOf('#');
    if (hIdx > -1) str = str.slice(0, hIdx);

    return str.trim();
  },

  validateNtfyChannel(channelStr) {
    const clean = this.normalizeNtfyTopic(channelStr);
    if (!clean) return false;
    return /^[a-zA-Z0-9_-]+$/.test(clean);
  },

  generateSecureChannel() {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let rand = '';
    for (let i = 0; i < 8; i++) {
      rand += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return `venda-realizada-${rand}`;
  },

  async loadSettings() {
    return new Promise((resolve) => {
      const applyData = (data) => {
        if (data && typeof data === 'object') {
          this.channel = this.normalizeNtfyTopic(data.channel || data.topic || '');
          this.draftChannel = this.channel;
          this.active = data.enabled !== undefined ? !!data.enabled : true;
          this.soundEnabled = data.soundEnabled !== undefined ? !!data.soundEnabled : true;
          this.lastSuccessfulTestAt = data.lastSuccessfulTestAt || null;
          this.lastSentAt = data.lastSentAt || null;

          if (!this.channel) {
            this.status = 'NÃO CONFIGURADO';
          } else {
            this.status = 'CONFIGURADO';
          }
        } else {
          this.channel = '';
          this.draftChannel = '';
          this.active = false;
          this.soundEnabled = true;
          this.status = 'NÃO CONFIGURADO';
        }
        this.updateUI();
        resolve();
      };

      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(NTFY_CONFIG_KEY, (res) => {
          applyData(res ? res[NTFY_CONFIG_KEY] : null);
        });
      } else {
        try {
          const raw = localStorage.getItem(NTFY_CONFIG_KEY);
          applyData(raw ? JSON.parse(raw) : null);
        } catch (e) {
          applyData(null);
        }
      }
    });
  },

  async saveSettings(newChannel = null) {
    const shadow = window.__liveInfinityShadow;
    const input = shadow ? shadow.getElementById('li-nv-canal') : null;
    const rawVal = newChannel !== null ? newChannel : (input ? input.value : this.draftChannel);

    const cleanChannel = this.normalizeNtfyTopic(rawVal);
    if (!cleanChannel || !/^[a-zA-Z0-9_-]+$/.test(cleanChannel)) {
      const msg = 'Por favor, informe um nome de canal válido (letras, números, hífens ou underlines sem espaços).';
      if (shadow) {
        const stText = shadow.getElementById('li-nv-status');
        if (stText) { stText.textContent = `❌ Erro: ${msg}`; stText.style.color = '#FF2834'; }
      } else {
        alert(msg);
      }
      return false;
    }

    this.channel = cleanChannel;
    this.draftChannel = cleanChannel;
    this.status = 'CONFIGURADO';

    if (input) {
      input.value = cleanChannel;
    }

    const payload = {
      channel: cleanChannel,
      enabled: this.active,
      soundEnabled: this.soundEnabled,
      savedAt: Date.now(),
      lastSuccessfulTestAt: this.lastSuccessfulTestAt,
      lastSentAt: this.lastSentAt
    };

    try {
      localStorage.setItem(NTFY_CONFIG_KEY, JSON.stringify(payload));
    } catch (e) {}

    return new Promise((resolve) => {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ [NTFY_CONFIG_KEY]: payload }, () => {
          chrome.storage.local.get(NTFY_CONFIG_KEY, (confirmRes) => {
            const confirmedData = confirmRes ? confirmRes[NTFY_CONFIG_KEY] : null;
            if (confirmedData && confirmedData.channel === cleanChannel) {
              this.updateUI();
              if (window.LiveInfinityCore) {
                LiveInfinityCore.log('Vendas', `Canal do ntfy.sh salvo com sucesso: ${cleanChannel}`);
              }
              resolve(true);
            } else {
              this.updateUI();
              resolve(false);
            }
          });
        });
      } else {
        this.updateUI();
        resolve(true);
      }
    });
  },

  async toggleActive(isEnabled) {
    this.active = isEnabled;
    await this.saveCurrentState();
  },

  async toggleSound(isEnabled) {
    this.soundEnabled = isEnabled;
    await this.saveCurrentState();
  },

  async saveCurrentState() {
    const payload = {
      channel: this.channel,
      enabled: this.active,
      soundEnabled: this.soundEnabled,
      savedAt: Date.now(),
      lastSuccessfulTestAt: this.lastSuccessfulTestAt,
      lastSentAt: this.lastSentAt
    };

    try {
      localStorage.setItem(NTFY_CONFIG_KEY, JSON.stringify(payload));
    } catch (e) {}

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ [NTFY_CONFIG_KEY]: payload });
    }

    this.updateUI();
  },

  copySavedChannel() {
    if (!this.channel) return;

    try {
      navigator.clipboard.writeText(this.channel);
      const shadow = window.__liveInfinityShadow;
      const btnCopy = shadow ? shadow.getElementById('li-btn-copy-ntfy') : null;
      if (btnCopy) {
        const origText = btnCopy.textContent;
        btnCopy.textContent = '✅ Copiado!';
        setTimeout(() => { btnCopy.textContent = origText; }, 2000);
      }
    } catch (e) {
      alert(`Canal salvo: ${this.channel}`);
    }
  },

  updateUI() {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;

    const input = shadow.getElementById('li-nv-canal');
    const badge = shadow.getElementById('li-ntfy-badge');
    const statusText = shadow.getElementById('li-nv-status');
    const toggleCell = shadow.getElementById('li-nv-celular-toggle');
    const toggleSound = shadow.getElementById('li-nv-som');

    const savedBox = shadow.getElementById('li-nv-saved-box');
    const savedTopicText = shadow.getElementById('li-nv-saved-topic');
    const lastTestTimeText = shadow.getElementById('li-nv-last-test-time');
    const btnTestMobile = shadow.getElementById('li-nv-teste');

    const isInputFocused = shadow.activeElement === input;

    if (input && !isInputFocused) {
      input.value = this.channel || '';
    }

    if (toggleCell) {
      toggleCell.checked = this.active;
    }

    if (toggleSound) {
      toggleSound.checked = this.soundEnabled;
    }

    if (badge) {
      if (this.channel) {
        badge.textContent = '● CONFIGURADO';
        badge.className = 'li-status-indicator li-status-active';
      } else {
        badge.textContent = 'NÃO CONFIGURADO';
        badge.className = 'li-status-indicator li-status-inactive';
      }
    }

    if (btnTestMobile) {
      btnTestMobile.disabled = !this.channel;
      btnTestMobile.title = this.channel ? 'Enviar notificação de teste para o celular' : 'Informe e salve um canal primeiro';
    }

    if (savedBox) {
      if (this.channel) {
        savedBox.style.display = 'block';
        if (savedTopicText) savedTopicText.textContent = this.channel;

        if (lastTestTimeText) {
          if (this.lastSuccessfulTestAt) {
            const dt = new Date(this.lastSuccessfulTestAt);
            lastTestTimeText.textContent = `Último teste enviado: ${dt.toLocaleDateString()} às ${dt.toLocaleTimeString().slice(0, 5)}`;
          } else {
            lastTestTimeText.textContent = 'Status: Canal configurado e pronto para envio.';
          }
        }
      } else {
        savedBox.style.display = 'none';
      }
    }

    if (statusText) {
      if (this.channel) {
        statusText.style.color = '#F4D675';
        statusText.textContent = `Canal salvo: ${this.channel}`;
      } else {
        statusText.style.color = '#C8BCA5';
        statusText.textContent = 'Informe ou gere um canal para receber alertas de vendas no celular.';
      }
    }
  },

  // ENVIO DE NOTIFICAÇÃO AO NTFY.SH (CORPO FORMATADO COMO TEXTO PLANO UTF-8)
  async sendNtfyNotification({ title, message, priority = 5, tags = 'moneybag', isTest = false }) {
    if (!this.channel) {
      this.lastErrorMsg = 'Nenhum canal salvo configurado. Salve um canal primeiro.';
      this.updateUI();
      return { ok: false, error: this.lastErrorMsg };
    }

    const targetChannel = this.channel;

    const directFallback = (c, tit, corp, tgs, cb) => {
      try {
        const url = new URL(`https://ntfy.sh/${encodeURIComponent(c)}`);
        url.searchParams.set('title', tit || '💵 Venda Realizada - Parabéns');
        if (tgs) url.searchParams.set('tags', Array.isArray(tgs) ? tgs.join(',') : String(tgs));
        url.searchParams.set('priority', String(priority || 5));

        fetch(url.toString(), {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain; charset=utf-8' },
          body: corp || ''
        })
          .then((r) => { if (cb) cb(r.ok); })
          .catch(() => { if (cb) cb(false); });
      } catch (e) {
        if (cb) cb(false);
      }
    };

    return new Promise((resolve) => {
      const msgObj = {
        type: 'live-infinity-ntfy',
        canal: targetChannel,
        titulo: title || '💵 Venda Realizada - Parabéns',
        corpo: message || '',
        tags: tags || 'moneybag',
        priority: priority
      };

      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage(msgObj, (resp) => {
          if (chrome.runtime.lastError || !resp || typeof resp.ok !== 'boolean') {
            directFallback(targetChannel, title, message, tags, (ok) => {
              this.handleResponse({ ok: ok }, isTest);
              resolve({ ok: ok });
            });
          } else {
            this.handleResponse(resp, isTest);
            resolve(resp);
          }
        });
      } else {
        directFallback(targetChannel, title, message, tags, (ok) => {
          this.handleResponse({ ok: ok }, isTest);
          resolve({ ok: ok });
        });
      }
    });
  },

  handleResponse(res, isTest) {
    if (res && res.ok) {
      this.lastSentAt = Date.now();
      if (isTest) {
        this.lastSuccessfulTestAt = this.lastSentAt;
        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Vendas', `Notificação de teste enviada com sucesso pro celular! ✅`);
        }
      }
    } else {
      this.lastErrorMsg = (res && res.error) || 'Falha no envio da notificação — confira o canal e a conexão de internet.';
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Vendas', `Erro no ntfy: ${this.lastErrorMsg}`);
      }
    }

    this.saveCurrentState();
    this.updateUI();
  },

  // BOTÃO DE TESTE (ENVIA VALOR SIMULADO DE TESTE DE R$ 10,00 COM MARCAÇÃO isTest: true)
  async sendTestNotification() {
    const shadow = window.__liveInfinityShadow;
    const btnTest = shadow ? shadow.getElementById('li-nv-teste') : null;
    if (btnTest) {
      btnTest.disabled = true;
      btnTest.textContent = 'Enviando teste...';
    }

    const title = '💵 Venda Realizada - Parabéns';
    const msg = 'Produto: Produto de teste • Valor: R$ 10,00';

    const res = await this.sendNtfyNotification({
      title: title,
      message: msg,
      priority: 5,
      tags: 'moneybag',
      isTest: true
    });

    if (btnTest) {
      btnTest.disabled = false;
      btnTest.textContent = 'Enviar teste para o celular';
    }

    return res;
  },

  playCashRegisterSound() {
    try {
      if (this.audioInstance) {
        this.audioInstance.currentTime = 0;
        const playPromise = this.audioInstance.play();
        if (playPromise !== undefined) {
          playPromise.catch(() => {
            this.fallbackAudioContextBeep();
          });
        }
        return;
      }

      let soundUrl = '';
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
        soundUrl = chrome.runtime.getURL('assets/audio/caixa-registradora.mp3');
      } else {
        soundUrl = 'assets/audio/caixa-registradora.mp3';
      }

      const audio = new Audio(soundUrl);
      audio.volume = 0.85;
      audio.play().catch(() => {
        this.fallbackAudioContextBeep();
      });
    } catch (e) {
      this.fallbackAudioContextBeep();
    }
  },

  fallbackAudioContextBeep() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(987.77, ctx.currentTime);
      osc.frequency.setValueAtTime(1318.51, ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } catch (e) {}
  },

  // INTEGRAÇÃO COM EVENTO DE VENDA REAL (CONSUMO DIRETO DO EVENTO CENTRAL PURCHASE_COMPLETED)
  onSaleDetected(saleData = {}) {
    const saleId = saleData.eventId || saleData.id || `purch_${saleData.buyerName || saleData.buyer || 'anon'}_${saleData.totalAmount || saleData.amount || ''}_${Math.floor(Date.now() / 10000)}`;

    if (this.notifiedSalesCache.has(saleId)) {
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Vendas', `[Sales] Evento de notificação duplicado ignorado: ${saleId}`);
      }
      return;
    }
    this.notifiedSalesCache.add(saleId);
    if (this.notifiedSalesCache.size > 300) {
      const first = this.notifiedSalesCache.values().next().value;
      this.notifiedSalesCache.delete(first);
    }

    // 1. Tocar som de caixa registradora se ativado
    if (this.soundEnabled) {
      this.playCashRegisterSound();
    }

    // 2. Enviar notificação celular se ativado e configurado
    if (!this.active || !this.channel) return;

    const rawProduct = saleData.productName || saleData.product || 'Produto TikTok Shop';
    const realProductName = this.sanitizeProductName(rawProduct) || 'Produto TikTok Shop';

    const rawValue = saleData.totalAmount !== undefined ? saleData.totalAmount : saleData.amount;
    const numValue = this.parseBRL(rawValue);
    const formattedValue = numValue !== null ? this.formatBRL(numValue) : 'aguardando confirmação';

    const originSource = saleData.amountSource || (numValue !== null ? 'purchase_event' : 'none');

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Vendas', `[Sales] Produto detectado: ${realProductName}`);
      LiveInfinityCore.log('Vendas', `[Sales] Quantidade detectada: ${saleData.quantity || 1}`);
      LiveInfinityCore.log('Vendas', `[Sales] Preço unitário: ${saleData.unitPrice ? this.formatBRL(saleData.unitPrice) : 'N/A'}`);
      LiveInfinityCore.log('Vendas', `[Sales] Valor total da venda: ${formattedValue}`);
      LiveInfinityCore.log('Vendas', `[Sales] Origem escolhida para o valor: ${originSource}`);
      LiveInfinityCore.log('Vendas', `[Ntfy] Valor enviado: ${formattedValue}`);
      LiveInfinityCore.log('Vendas', `[Ntfy] Evento enviado: ${saleId}`);
    }

    const title = '💵 Venda Realizada - Parabéns';
    const message = `Produto: ${realProductName} • Valor: ${formattedValue}`;

    this.sendNtfyNotification({
      title: title,
      message: message,
      priority: 5,
      tags: 'moneybag',
      isTest: false
    });
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinitySalesAlert = LiveInfinitySalesAlert;
}
