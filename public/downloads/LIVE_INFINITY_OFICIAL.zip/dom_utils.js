'use strict';

/* ===== Live Infinity — Utilitários de DOM & Eventos Sintéticos ===== */
const LiveInfinityDOM = {

  // Converte NodeList ou Iterable em Array seguro
  toArray(nodes) {
    if (!nodes) return [];
    return Array.prototype.slice.call(nodes);
  },

  // Verifica se elemento está visível no viewport
  isVisible(el) {
    if (!el) return false;
    try {
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none' && parseFloat(cs.opacity) >= 0.2;
    } catch (e) {
      return false;
    }
  },

  // Normaliza texto removendo acentos e espaços extras
  normalizeText(txt) {
    return (txt || '').toString().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
  },

  // Dispara evento de mouse sintético completo (PointerEvent + MouseEvent)
  clickElement(el) {
    if (!el) return;
    const target = el.closest('button, [role="button"], a') || el;
    try { target.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) {}

    const fire = (type) => {
      try {
        const r = target.getBoundingClientRect();
        const cx = Math.round(r.left + r.width / 2);
        const cy = Math.round(r.top + r.height / 2);
        let evt;
        if (type.indexOf('pointer') === 0 && window.PointerEvent) {
          evt = new PointerEvent(type, { bubbles: true, cancelable: true, view: window, pointerId: 1, pointerType: 'mouse', isPrimary: true, button: 0, buttons: type.indexOf('down') > -1 ? 1 : 0, clientX: cx, clientY: cy });
        } else {
          evt = new MouseEvent(type, { bubbles: true, cancelable: true, view: window, button: 0, buttons: type.indexOf('down') > -1 ? 1 : 0, clientX: cx, clientY: cy });
        }
        target.dispatchEvent(evt);
      } catch (e) {}
    };

    ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach(fire);
    try {
      if (typeof target.click === 'function') target.click();
      else fire('click');
    } catch (e) {}
  },

  // Simula hover completo sobre o elemento
  hoverElement(el) {
    if (!el) return;
    try {
      const r = el.getBoundingClientRect();
      const cx = Math.round(r.left + r.width / 2);
      const cy = Math.round(r.top + r.height / 2);
      ['pointerover', 'pointerenter', 'mouseover', 'mouseenter', 'pointermove', 'mousemove'].forEach((tp) => {
        try {
          el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy }));
        } catch (e) {}
      });
    } catch (e) {}
  },

  // Remove hover simulado
  unhoverElement(el) {
    if (!el) return;
    ['mouseout', 'mouseleave', 'pointerout', 'pointerleave'].forEach((tp) => {
      try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {}
    });
  },

  // Injeta valor em textarea/input disparando eventos nativos do React/Arco Design
  setInputValue(inputEl, val) {
    if (!inputEl) return;
    inputEl.focus();
    const nativeSetter = Object.getOwnPropertyDescriptor(
      inputEl.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype,
      'value'
    ).set;
    nativeSetter.call(inputEl, val);
    inputEl.dispatchEvent(new Event('input', { bubbles: true }));
  },

  // Busca o relógio da Live no ar (formato 00:00:00)
  findLiveTimerElement() {
    const candidates = this.toArray(document.querySelectorAll('div, span, p, b, strong'));
    for (let i = 0; i < candidates.length; i++) {
      const el = candidates[i];
      if (el.children.length === 0) {
        const txt = (el.textContent || '').trim();
        if (/^\d{1,2}:\d{2}:\d{2}$/.test(txt) && this.isVisible(el)) {
          let parent = el;
          let insideHub = false;
          while (parent) {
            if (parent.id === 'live-infinity-root-host') { insideHub = true; break; }
            parent = parent.parentElement;
          }
          if (!insideHub) return el;
        }
      }
    }
    return null;
  },

  // Encontra o botão de Desligar Live próximo ao relógio
  findPowerButton(timerEl) {
    if (!timerEl) return null;
    let curr = timerEl;
    const tr = timerEl.getBoundingClientRect();

    for (let up = 0; up < 9 && curr; up++) {
      curr = curr.parentElement;
      if (!curr) break;
      const candidates = this.toArray(curr.querySelectorAll('button, [role="button"], svg')).filter((b) => {
        if (!this.isVisible(b)) return false;
        if (((b.textContent || '').trim()) !== '') return false;
        const r = b.getBoundingClientRect();
        return (r.left > tr.right - 2 && Math.abs((r.top + r.height / 2) - (tr.top + tr.height / 2)) < 35);
      });
      if (candidates.length > 0) {
        candidates.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
        return candidates[0];
      }
    }
    return null;
  },

  // Encontra a caixa de texto de comentários do chat no TikTok Shop
  findChatTextarea() {
    const textareas = this.toArray(document.querySelectorAll('textarea')).filter((t) => {
      if (!this.isVisible(t)) return false;
      const ph = t.getAttribute('placeholder') || '';
      return /Digite|Diga|Say|coment|chat/i.test(ph);
    });
    if (textareas.length) return textareas[0];

    const fallback = this.toArray(document.querySelectorAll('textarea.arco-textarea')).filter(t => this.isVisible(t));
    return fallback.length ? fallback[0] : null;
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityDOM = LiveInfinityDOM;
}
