# Classificação de Arquivos Congelados — Live Infinity

Este documento estabelece as diretrizes de modificação para a equipe de desenvolvimento da **Live Infinity**.

---

## 1. Classificação dos Arquivos

| Arquivo | Classificação de Alteração | Regras de Modificação |
| :--- | :--- | :--- |
| `background.js` | **CONGELADO — NÃO ALTERAR** | Alterações proibidas sem regressão completa. |
| `content.js` | **CONGELADO — NÃO ALTERAR** | Alterações proibidas sem regressão completa. |
| `automation_store.js` | **CONGELADO — NÃO ALTERAR** | Alterações proibidas. Contém máquina de estados da live. |
| `license.js` | **CONGELADO — NÃO ALTERAR** | Alterações proibidas. Integração direta com painel seguro. |
| `timer.js` | **CONGELADO — NÃO ALTERAR** | Alterações proibidas. Contém motor de encerramento do LiveGoPro. |
| `ui_manager.js` | **INTERFACE — ALTERAÇÃO VISUAL RESTRITA** | Mudanças de layout não podem renomear IDs ou listeners. |
| `styles.js` | **ALTERAÇÃO VISUAL PERMITIDA** | Alteração de cores, tamanhos, fontes e espaçamentos permitida. |
| `manifest.json` | **CONFIGURAÇÃO — SOMENTE REGRESSÃO** | Ícones e versão permitidos; permissões e scripts congelados. |
| `assets/brand/*` | **ASSET — ALTERAÇÃO VISUAL PERMITIDA** | Substituição de imagens permitida mantendo caminhos. |

---

## 2. Regras Estritas para Alterações Visuais Futuras

1. **PROIBIDO** renomear elementos HTML ou IDs consumidos pelos scripts (`li-rt-armar`, `li-rt-restante`, `li-mini-panel`, etc.).
2. **PROIBIDO** alterar seletores nativos do TikTok.
3. **PROIBIDO** modificar callbacks de timer, eventos de clique ou listeners.
4. **PROIBIDO** alterar mensagens enviadas via `chrome.runtime.sendMessage`.
