'use strict';

/* ===== Live Infinity — Módulo de Licenciamento & License Gatekeeper (Validação Exclusiva por Chave) ===== */
const LiveInfinityLicense = {
  currentLicense: null,
  isValid: false,

  maskKey(key) {
    if (!key) return '';
    const clean = String(key).trim().toUpperCase();
    if (clean.length <= 10) return 'LIVEINF-****';
    return clean.slice(0, 7) + '-****-' + clean.slice(-5);
  },

  openRenewalPage() {
    const renewalUrl = LIVE_INFINITY_CONFIG.RENEWAL_URL || 'https://liveinfinitysite.vercel.app/';
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      try {
        chrome.runtime.sendMessage({ type: 'LIVE_INFINITY_OPEN_RENEWAL_PAGE' }, (res) => {
          if (chrome.runtime.lastError || (res && !res.ok)) {
            window.open(renewalUrl, '_blank', 'noopener,noreferrer');
          }
        });
      } catch (e) {
        window.open(renewalUrl, '_blank', 'noopener,noreferrer');
      }
    } else {
      window.open(renewalUrl, '_blank', 'noopener,noreferrer');
    }
  },

  openRecoveryPage() {
    const recoveryUrl = LIVE_INFINITY_CONFIG.RECOVERY_URL || 'https://api.valoranegocios.com.br/ativar-liveinfinity';
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      try {
        chrome.runtime.sendMessage({ type: 'LIVE_INFINITY_OPEN_RECOVERY_PAGE' }, (res) => {
          if (chrome.runtime.lastError || (res && !res.ok)) {
            window.open(recoveryUrl, '_blank', 'noopener,noreferrer');
          }
        });
      } catch (e) {
        window.open(recoveryUrl, '_blank', 'noopener,noreferrer');
      }
    } else {
      window.open(recoveryUrl, '_blank', 'noopener,noreferrer');
    }
  },

  getStoredLicense(callback) {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get([LIVE_INFINITY_CONFIG.STORAGE_KEYS.LICENSE], (res) => {
        callback(res && res[LIVE_INFINITY_CONFIG.STORAGE_KEYS.LICENSE] ? res[LIVE_INFINITY_CONFIG.STORAGE_KEYS.LICENSE] : null);
      });
      return;
    }
    try {
      const raw = localStorage.getItem(LIVE_INFINITY_CONFIG.STORAGE_KEYS.LICENSE);
      callback(raw ? JSON.parse(raw) : null);
    } catch (e) {
      callback(null);
    }
  },

  setStoredLicense(licData) {
    this.currentLicense = licData;
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ [LIVE_INFINITY_CONFIG.STORAGE_KEYS.LICENSE]: licData });
    }
    try {
      localStorage.setItem(LIVE_INFINITY_CONFIG.STORAGE_KEYS.LICENSE, JSON.stringify(licData));
    } catch (e) {}
  },

  clearStoredLicense() {
    this.currentLicense = null;
    this.isValid = false;
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.remove([LIVE_INFINITY_CONFIG.STORAGE_KEYS.LICENSE]);
    }
    try {
      localStorage.removeItem(LIVE_INFINITY_CONFIG.STORAGE_KEYS.LICENSE);
    } catch (e) {}
  },

  formatDateBR(isoString) {
    if (!isoString) return '--/--/---- às --:--';
    try {
      const d = new Date(isoString);
      if (isNaN(d.getTime())) return '--/--/---- às --:--';
      const day = String(d.getDate()).padStart(2, '0');
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const year = d.getFullYear();
      const hours = String(d.getHours()).padStart(2, '0');
      const minutes = String(d.getMinutes()).padStart(2, '0');
      return `${day}/${month}/${year} às ${hours}:${minutes}`;
    } catch (e) {
      return '--/--/---- às --:--';
    }
  },

  validateWithServer(key, callback) {
    const rawKey = String(key || '').trim().toUpperCase();
    if (!rawKey) {
      callback(false, 'empty', null);
      return;
    }

    const endpoint = LIVE_INFINITY_CONFIG.API_VALIDATE_ENDPOINT;
    const payload = { key: rawKey };

    fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    .then(async (res) => {
      let data = null;
      try {
        data = await res.json();
      } catch (e) {
        callback(false, 'server_error', null);
        return;
      }

      if (res.status === 200 && data && (data.ok || data.valid || data.status === 'active')) {
        const licInfo = data.license || {};
        const plan = (licInfo.plan || data.plan || '').toLowerCase();
        const days = typeof licInfo.days_remaining === 'number' ? licInfo.days_remaining : null;
        const expiresStr = licInfo.expires_at || data.expiresAt || null;

        // ETAPA 6: Detecção estrita de dados inconsistentes (Ex: Plano mensal alegando > 35 dias ou vencimento em 2053)
        if ((plan === 'monthly' || plan.includes('mensal') || licInfo.billing_cycle_days === 30) && (days > 35 || (expiresStr && new Date(expiresStr).getFullYear() > 2027))) {
          callback(false, 'inconsistent_data', data);
          return;
        }

        callback(true, 'active', data);
      } else if (res.status === 404 || (data && data.reason === 'invalid')) {
        callback(false, 'invalid', data);
      } else if (data && (data.reason === 'expired' || data.status === 'expired')) {
        callback(false, 'expired', data);
      } else if (data && (data.reason === 'blocked' || data.status === 'blocked')) {
        callback(false, 'blocked', data);
      } else if (data && (data.reason === 'revoked' || data.status === 'revoked' || data.status === 'refunded' || data.status === 'chargeback')) {
        callback(false, 'revoked', data);
      } else {
        callback(false, (data && data.reason) || 'invalid', data);
      }
    })
    .catch(() => {
      callback(false, 'network_error', null);
    });
  },

  getErrorMessage(reason) {
    const messages = {
      empty: 'Digite sua chave de acesso.',
      invalid: 'Chave de acesso inválida.',
      expired: 'Sua assinatura venceu. Faça a renovação e digite sua chave novamente para liberar o acesso.',
      blocked: 'Esta chave foi bloqueada administrativamente. Entre em contato com o suporte.',
      revoked: 'Esta assinatura foi cancelada ou reembolsada e não possui mais autorização.',
      inconsistent_data: 'Não foi possível confirmar o período desta assinatura. Revalide ou entre em contato com o suporte.',
      network_error: 'Servidor indisponível no momento. Verifique sua conexão e tente novamente.',
      server_error: 'Não foi possível validar sua licença com o servidor. Tente novamente.'
    };
    return messages[reason] || 'Não foi possível validar sua licença. Tente novamente.';
  },

  async resolveAccess() {
    return new Promise((resolve) => {
      this.getStoredLicense((lic) => {
        if (!lic || !lic.key) {
          this.isValid = false;
          resolve({ valid: false, reason: 'empty', licData: null });
          return;
        }

        const rawKey = String(lic.key).trim().toUpperCase();

        this.validateWithServer(rawKey, (ok, statusReason, data) => {
          if (ok && data) {
            const now = Date.now();
            const licInfo = data.license || {};

            // E-mail real vindo da resposta normalizada ou 'E-mail não vinculado' se ausente
            const email = licInfo.email || data.email || (lic && lic.email && lic.email !== 'Não informado' ? lic.email : 'E-mail não vinculado');
            const maskedKey = licInfo.masked_key || this.maskKey(rawKey);

            // Mapeamento correto de planos sem mascarar tipos legados/vitalícios
            const rawPlan = String(licInfo.plan || data.plan || 'monthly').toLowerCase();
            let planLabel = 'Mensal — 30 dias';
            if (rawPlan === 'lifetime' || rawPlan === 'vitalicio') {
              planLabel = 'Vitalício';
            } else if (rawPlan === 'trial') {
              planLabel = 'Período de Testes';
            } else if (rawPlan === 'manual') {
              planLabel = 'Licença Manual';
            }

            const expiresStr = licInfo.expires_at || data.expiresAt;
            const expiresMs = expiresStr ? new Date(expiresStr).getTime() : (now + 30 * 86400000);
            const serverDays = typeof licInfo.days_remaining === 'number' ? licInfo.days_remaining : Math.ceil((expiresMs - now) / 86400000);
            const daysRemaining = Math.max(0, serverDays);

            if (daysRemaining <= 0 || expiresMs <= now) {
              this.isValid = false;
              resolve({ valid: false, reason: 'expired', licData: lic });
              return;
            }

            const updatedLic = {
              key: rawKey,
              email: email,
              masked_key: maskedKey,
              plan: planLabel,
              cycle_started_at: licInfo.cycle_started_at || new Date().toISOString(),
              expires_at: expiresStr || new Date(expiresMs).toISOString(),
              days_remaining: daysRemaining,
              payment_status: licInfo.payment_status === 'paid' ? 'Em dia' : (licInfo.payment_status || 'Em dia'),
              token: data.token || '',
              status: 'active',
              last_checked: data.server_time ? this.formatDateBR(data.server_time).slice(-5) : new Date().toLocaleTimeString().slice(0, 5)
            };

            this.setStoredLicense(updatedLic);
            this.isValid = true;
            resolve({ valid: true, reason: 'active', licData: updatedLic });
          } else {
            if ((statusReason === 'network_error' || statusReason === 'server_error') && lic && lic.key) {
              // Falha temporária de internet/servidor indisponível: Mantém a licença salva em vigor!
              this.currentLicense = lic;
              this.currentLicense.last_checked = `Aguardando conexão (${new Date().toLocaleTimeString().slice(0, 5)})`;
              this.isValid = true;
              if (window.LiveInfinityCore) {
                LiveInfinityCore.log('Licença', 'Conexão de rede indisponível. Mantendo licença válida e aguardando reconexão...');
              }
              resolve({ valid: true, reason: 'offline_grace', licData: this.currentLicense });
              return;
            }

            this.isValid = false;
            resolve({ valid: false, reason: statusReason, licData: lic });
          }
        });
      });
    });
  },

  async cutoff(reason = 'expired') {
    this.isValid = false;
    if (window.LiveInfinityCore) {
      if (typeof LiveInfinityCore.stopAllAutomations === 'function') {
        await LiveInfinityCore.stopAllAutomations({ reason });
      } else if (typeof LiveInfinityCore.shutdownAllOperationalModules === 'function') {
        await LiveInfinityCore.shutdownAllOperationalModules({ reason });
      }
    }
    if (window.LiveInfinityUI) {
      LiveInfinityUI.destroyOrHideHubUI();
    }
    this.renderLicenseGate(reason);
  },

  periodicTimerId: null,
  _onlineListenerBound: false,

  startPeriodicScheduler() {
    if (this.periodicTimerId) {
      clearInterval(this.periodicTimerId);
      this.periodicTimerId = null;
    }

    const intervalMs = (typeof LIVE_INFINITY_CONFIG !== 'undefined' && LIVE_INFINITY_CONFIG.DEFAULTS && LIVE_INFINITY_CONFIG.DEFAULTS.LICENSE_CHECK_INTERVAL_MS) || (15 * 60 * 1000);
    this.periodicTimerId = setInterval(() => {
      this.periodicCheck();
    }, intervalMs);

    if (typeof window !== 'undefined' && !this._onlineListenerBound) {
      this._onlineListenerBound = true;
      window.addEventListener('online', () => {
        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Licença', 'Conexão de rede restabelecida. Executando verificação automática de licença...');
        }
        this.periodicCheck();
      });
    }
  },

  async periodicCheck() {
    const res = await this.resolveAccess();
    if (!res.valid) {
      await this.cutoff(res.reason);
      return false;
    }
    if (window.LiveInfinityUI) {
      LiveInfinityUI.renderLicenseInfo();
    }
    return true;
  },

  renderLicenseGate(reason = '') {
    const shadow = LiveInfinityUI.initHostOnly();
    let gate = shadow.getElementById('li-gate');

    if (!gate) {
      gate = document.createElement('div');
      gate.id = 'li-gate';
      gate.setAttribute('role', 'dialog');
      gate.setAttribute('aria-modal', 'true');
      gate.setAttribute('aria-labelledby', 'li-gate-title');
    }

    gate.style.display = 'flex';
    gate.innerHTML = `
      <div class="li-gate-card">
        <div class="login-symbol-frame">
          <img src="${typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL ? chrome.runtime.getURL('assets/brand/original/live-infinity-symbol-exact-transparent.png') : 'assets/brand/original/live-infinity-symbol-exact-transparent.png'}" alt="Live Infinity" />
        </div>

        <h1 class="license-brand-title">
          <span class="brand-live">Live</span> <span class="brand-infinity">Infinity</span>
        </h1>

        <div class="license-brand-subtitle">Automação Inteligente TikTok Shop</div>

        <div class="license-instruction">Digite a sua chave de acesso para liberar.</div>

        <input id="li-gate-key" class="li-gate-input" placeholder="SUA-CHAVE-DE-ACESSO" spellcheck="false" autocomplete="off" />

        <button type="button" id="li-gate-btn" class="li-gate-btn-primary">🚀 Liberar Acesso</button>

        <div id="li-gate-st" class="li-gate-st" aria-live="polite">${reason ? this.getErrorMessage(reason) : ''}</div>

        <div class="license-recovery-box">
          <div class="recovery-title">🔑 Não tem sua chave de acesso ainda?</div>
          <div class="recovery-subtext">Gere ou recupere usando seu e-mail de compra da Cakto em:</div>
          <button type="button" id="li-gate-btn-recover" class="li-gate-btn-gold" data-action="recover-key">
            👉 Gerar Minha Chave Live Infinity
          </button>
        </div>

        <div class="license-renew-wrapper">
          Sua assinatura venceu? <button type="button" id="li-gate-btn-renew" class="license-renew-link" data-action="renew-subscription">Renovar assinatura</button>
        </div>
      </div>
    `;

    shadow.appendChild(gate);

    const btnGo = shadow.getElementById('li-gate-btn');
    const btnRenew = shadow.getElementById('li-gate-btn-renew');
    const btnRecover = shadow.getElementById('li-gate-btn-recover');
    const inputKey = shadow.getElementById('li-gate-key');
    const stEl = shadow.getElementById('li-gate-st');

    if (btnRenew) {
      let isRenewing = false;
      btnRenew.addEventListener('click', (ev) => {
        ev.preventDefault(); ev.stopPropagation();
        if (isRenewing) return;
        isRenewing = true;
        this.openRenewalPage();
        setTimeout(() => { isRenewing = false; }, 1000);
      });
    }

    if (btnRecover) {
      let isRecovering = false;
      btnRecover.addEventListener('click', (ev) => {
        ev.preventDefault(); ev.stopPropagation();
        if (isRecovering) return;
        isRecovering = true;
        this.openRecoveryPage();
        setTimeout(() => { isRecovering = false; }, 1000);
      });
    }

    const handleActivate = () => {
      const k = (inputKey.value || '').trim().toUpperCase();

      if (!k) {
        stEl.style.color = '#FF2834';
        stEl.textContent = this.getErrorMessage('empty');
        return;
      }

      stEl.style.color = '#F4D675';
      stEl.textContent = '⏳ Validando chave com o servidor...';

      this.validateWithServer(k, (ok, statusReason, data) => {
        if (ok && data) {
          const now = Date.now();
          const licInfo = data.license || {};
          const email = licInfo.email || data.email || 'E-mail não vinculado';
          const expiresMs = licInfo.expires_at ? new Date(licInfo.expires_at).getTime() : (data.expiresAt ? new Date(data.expiresAt).getTime() : (now + 30 * 86400000));
          const daysRemaining = typeof licInfo.days_remaining === 'number' ? Math.max(0, licInfo.days_remaining) : Math.max(0, Math.ceil((expiresMs - now) / 86400000));

          if (daysRemaining <= 0 || expiresMs <= now) {
            stEl.style.color = '#FF2834';
            stEl.textContent = this.getErrorMessage('expired');
            return;
          }

          const newLicData = {
            key: k,
            email: email,
            masked_key: licInfo.masked_key || this.maskKey(k),
            plan: licInfo.plan ? (licInfo.plan.toLowerCase().includes('30') ? licInfo.plan : `${licInfo.plan} — 30 dias`) : 'Mensal — 30 dias',
            cycle_started_at: licInfo.cycle_started_at || new Date().toISOString(),
            expires_at: licInfo.expires_at || new Date(expiresMs).toISOString(),
            days_remaining: daysRemaining,
            payment_status: licInfo.payment_status === 'paid' ? 'Em dia' : (licInfo.payment_status || 'Em dia'),
            token: data.token || '',
            status: 'active',
            last_checked: data.server_time ? this.formatDateBR(data.server_time).slice(-5) : new Date().toLocaleTimeString().slice(0, 5)
          };

          this.setStoredLicense(newLicData);
          this.isValid = true;
          stEl.style.color = '#F4D675';
          stEl.textContent = 'Acesso liberado com sucesso!';

          setTimeout(async () => {
            gate.style.display = 'none';
            if (window.LiveInfinityCore) {
              await window.LiveInfinityCore.mountAndStartAllModules();
              window.LiveInfinityCore.log('Licença', `Chave ativada com sucesso: ${this.maskKey(k)}`);
            }
          }, 800);
        } else {
          this.isValid = false;
          stEl.style.color = '#FF2834';
          stEl.textContent = this.getErrorMessage(statusReason);
          if (window.LiveInfinityCore) {
            window.LiveInfinityCore.log('Licença', `Tentativa de ativação recusada: ${this.getErrorMessage(statusReason)}`);
          }
        }
      });
    };

    btnGo.addEventListener('click', handleActivate);
    inputKey.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') handleActivate(); });
  },

  hideLicenseGate() {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;
    const gate = shadow.getElementById('li-gate');
    if (gate) gate.style.display = 'none';
  },

  isCurrentValid() {
    return this.isValid && !!this.currentLicense;
  },

  async periodicCheck() {
    const res = await this.resolveAccess();
    if (!res.valid) {
      await this.cutoff(res.reason);
      return false;
    }
    if (window.LiveInfinityUI) {
      LiveInfinityUI.renderLicenseInfo();
    }
    return true;
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityLicense = LiveInfinityLicense;
}
