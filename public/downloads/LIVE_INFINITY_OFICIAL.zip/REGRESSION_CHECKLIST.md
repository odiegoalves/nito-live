# Checklist de Testes de Regressão — Live Infinity

Checklist obrigatório a ser executado antes de empacotar qualquer nova versão da **Live Infinity**.

---

## Checklist Mínimo

- [ ] 1. Licença válida desbloqueia a extensão e exibe o painel principal.
- [ ] 2. Licença inválida/vencida exibe o bloqueio de licença.
- [ ] 3. Pressionar F5 na página da Live do TikTok preserva o estado da sessão e o timer.
- [ ] 4. Rodapé exibe `● AGUARDANDO LIVE` sem transmissão e `● AO VIVO` com transmissão ativa.
- [ ] 5. Timer aceita entrada manual e botões de preset.
- [ ] 6. Timer pausa e retoma corretamente.
- [ ] 7. Ao zerar o timer, a extensão localiza o botão de energia à direita do contador nativo.
- [ ] 8. O controle de alternância de cámara (`Vídeo`) é EXPRESSAMENTE REJEITADO.
- [ ] 9. O modal `Finalizar LIVE?` é localizado e o botão verde `Confirmar` é clicado automaticamente.
- [ ] 10. A transmissão é encerrada e a sessão reinicia automaticamente para `AGUARDANDO LIVE`.
- [ ] 11. O painel da Live Infinity permanece aberto e pronto para uma segunda live.
- [ ] 12. Os comentários automáticos de produto são enviados em loop contínuo.
- [ ] 13. Menções de carrinho e compra contêm a menção de usuário correta.
- [ ] 14. O som da caixa registradora e o envio ao ntfy.sh disparam corretamente.
- [ ] 15. Verificador de integridade executado com resultado `FUNCTIONAL BASELINE: INTACT`.
