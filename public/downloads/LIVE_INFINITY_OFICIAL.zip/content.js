'use strict';

/* ===== Live Infinity — Content Script Entry Point (Orquestrador de Licenciamento & Módulos) ===== */

const LiveInfinityCore = {
  initialized: false,
  modulesMounted: false,
  activeMonitorTimer: null,

  async init() {
    if (this.initialized) return;
    this.initialized = true;

    // 1. Carregar Estado Persistido no Store Central PRIMEIRO
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.init();
    }

    // 2. Anexar apenas o Host & Shadow DOM para o License Gate (SEPARADO da Central de Comando)
    LiveInfinityUI.initHostOnly();

    // 3. Resolver Acesso de Licenciamento PRIMEIRO no Servidor Oficial
    const licenseResult = await LiveInfinityLicense.resolveAccess();

    if (!licenseResult.valid) {
      this.log('Core', `Acesso negado (${licenseResult.reason}). Exibindo tela de ativação por chave.`);
      await this.shutdownAllOperationalModules({ reason: licenseResult.reason });
      LiveInfinityLicense.renderLicenseGate(licenseResult.reason);
      return; // Interrompe totalmente! Nenhum motor ou Hub é criado!
    }

    // 4. Se licença estiver VÁLIDA: Ocultar License Gate e montar módulos
    LiveInfinityLicense.hideLicenseGate();
    await this.mountAndStartAllModules();
  },

  async mountAndStartAllModules() {
    if (this.modulesMounted) return;
    this.modulesMounted = true;

    // Montar Central de Comando (#li-hub) e Mini Painel
    await LiveInfinityUI.mountFullHubUI();

    if (window.LiveInfinityProducts) {
      await LiveInfinityProducts.init();
    }

    // Inicializar Dashboard, Timer e Proteção de Emergência
    LiveInfinityDashboard.start();
    if (window.LiveInfinityTimer) {
      await LiveInfinityTimer.restore();
    }
    if (window.LiveInfinityViolationProtect) {
      await LiveInfinityViolationProtect.init();
    }

    // Restauração das automações persistidas
    await this.restoreActiveAutomations();

    // Iniciar Gerenciador de Sessão da Live
    if (window.LiveSessionStore) {
      LiveSessionStore.init();
    }

    // Iniciar Monitor da Barra de Status e Agendador Único de Revalidação Automática
    this.startActiveMonitor();
    if (window.LiveInfinityLicense && typeof LiveInfinityLicense.startPeriodicScheduler === 'function') {
      LiveInfinityLicense.startPeriodicScheduler();
    }

    this.log('Core', 'Live Infinity v1.0.0 — Central de Comando liberada por chave válida e automações ativas! ✅');
  },

  async restoreActiveAutomations() {
    if (!window.LiveInfinityStateStore) return;
    const store = LiveInfinityStateStore.state;
    const autos = store.automations || {};

    if (autos.productPin && autos.productPin.desiredEnabled && window.LiveInfinityProductPin) {
      await LiveInfinityProductPin.restore();
    }

    if (autos.flashDeal && autos.flashDeal.desiredEnabled && window.LiveInfinityFlashDeal) {
      await LiveInfinityFlashDeal.restore();
    }

    if (autos.autoComments && autos.autoComments.desiredEnabled && window.LiveInfinityChat) {
      await LiveInfinityChat.restoreComments();
    }

    if (autos.autoReplies && autos.autoReplies.desiredEnabled && window.LiveInfinityChat) {
      await LiveInfinityChat.restoreReplies();
    }

    if (autos.buyerIntent && autos.buyerIntent.desiredEnabled && window.LiveInfinityBuyerIntent) {
      await LiveInfinityBuyerIntent.restore();
    }

    if (autos.purchaseThanks && autos.purchaseThanks.desiredEnabled && window.LiveInfinityPurchaseThanks) {
      await LiveInfinityPurchaseThanks.restore();
    }

    if (autos.nameBlock && autos.nameBlock.desiredEnabled && window.LiveInfinityNameBlock) {
      await LiveInfinityNameBlock.restore();
    }

    if (autos.violationProtection && autos.violationProtection.desiredEnabled && window.LiveInfinityViolationProtect) {
      await LiveInfinityViolationProtect.init();
    }

    if (autos.mobileNotification && autos.mobileNotification.desiredEnabled && window.LiveInfinitySalesAlert) {
      await LiveInfinitySalesAlert.toggleActive(true);
    }

    LiveInfinityUI.syncConversationToggles();
  },

  startActiveMonitor() {
    if (this.activeMonitorTimer) clearInterval(this.activeMonitorTimer);
    this.activeMonitorTimer = setInterval(() => this.updateActiveCount(), 1500);
  },

  updateActiveCount() {
    let active = 0;
    if (window.LiveInfinityProductPin && LiveInfinityProductPin.active) active++;
    if (window.LiveInfinityFlashDeal && LiveInfinityFlashDeal.active) active++;
    if (window.LiveInfinityChat && LiveInfinityChat.commentActive) active++;
    if (window.LiveInfinityChat && LiveInfinityChat.replyActive) active++;
    if (window.LiveInfinityBuyerIntent && LiveInfinityBuyerIntent.active) active++;
    if (window.LiveInfinityPurchaseThanks && LiveInfinityPurchaseThanks.active) active++;
    if (window.LiveInfinityNameBlock && LiveInfinityNameBlock.active) active++;
    if (window.LiveInfinityTimer && LiveInfinityTimer.fase === 'contando') active++;

    if (window.LiveInfinityUI && typeof LiveInfinityUI.updateActiveCount === 'function') {
      LiveInfinityUI.updateActiveCount(active);
    }
  },

  async stopAllAutomations(options = {}) {
    if (options.reason === 'expired' || options.reason === 'blocked' || options.reason === 'revoked' || options.reason === 'license') {
      return this.shutdownAllOperationalModules(options);
    }
    return this.stopOperationalAutomationsOnly(options.reason || 'manual_stop');
  },

  async stopOperationalAutomationsOnly(reason = 'timer_finished') {
    if (window.LiveInfinityProductPin) LiveInfinityProductPin.stop();
    if (window.LiveInfinityFlashDeal) LiveInfinityFlashDeal.stop();
    if (window.LiveInfinityChat) {
      LiveInfinityChat.stopComments();
      LiveInfinityChat.stopReplies();
    }
    if (window.LiveInfinityBuyerIntent) LiveInfinityBuyerIntent.stop();
    if (window.LiveInfinityPurchaseThanks) LiveInfinityPurchaseThanks.stop();
    if (window.LiveInfinityNameBlock) LiveInfinityNameBlock.stop();

    this.log('Core', `Automações operacionais encerradas (${reason}). O painel da extensão permanece ativo.`);
  },

  async shutdownAllOperationalModules(options = {}) {
    this.modulesMounted = false;
    if (this.activeMonitorTimer) clearInterval(this.activeMonitorTimer);
    this.activeMonitorTimer = null;

    LiveInfinityUI.destroyOrHideHubUI();

    if (window.LiveInfinityProductPin) LiveInfinityProductPin.stop();
    if (window.LiveInfinityFlashDeal) LiveInfinityFlashDeal.stop();
    if (window.LiveInfinityChat) {
      LiveInfinityChat.stopComments();
      LiveInfinityChat.stopReplies();
    }
    if (window.LiveInfinityBuyerIntent) LiveInfinityBuyerIntent.stop();
    if (window.LiveInfinityPurchaseThanks) LiveInfinityPurchaseThanks.stop();
    if (window.LiveInfinityNameBlock) LiveInfinityNameBlock.stop();

    if (window.LiveInfinityViolationProtect) {
      LiveInfinityViolationProtect.state = 'DISABLED_BY_LICENSE';
      LiveInfinityViolationProtect.updateUI();
    }

    this.log('Core', `Módulos operacionais interrompidos (${options.reason || 'Bloqueio de Licença'}).`);
  },

  log(tag, msg) {
    if (window.LiveInfinityUI && typeof LiveInfinityUI.log === 'function') {
      LiveInfinityUI.log(tag, msg);
    }
  }
};

// Executar bootstrap automático na inicialização do content script
if (typeof window !== 'undefined') {
  window.LiveInfinityCore = LiveInfinityCore;
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => LiveInfinityCore.init());
  } else {
    LiveInfinityCore.init();
  }
}
