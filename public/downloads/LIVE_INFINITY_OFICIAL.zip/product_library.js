'use strict';

/* ===== Live Infinity — Biblioteca de Produtos (LiveInfinityProductLibrary) ===== */

function assertStorageKeyProduct(key, moduleName) {
  if (typeof key !== 'string' || key.trim() === '') {
    throw new TypeError(`[${moduleName}] Chave de armazenamento inválida: "${key}"`);
  }
  return key.trim();
}

const LiveInfinityProductLibrary = {
  activeProductId: null,
  products: [],
  initialized: false,
  subscribers: [],

  async init() {
    if (this.initialized) return;
    this.initialized = true;
    await this.loadData();
  },

  getSnapshot() {
    return {
      activeProductId: this.activeProductId,
      products: [...this.products]
    };
  },

  getProductById(id) {
    if (!id) return null;
    return this.products.find(p => p.id === id) || null;
  },

  getActiveProduct() {
    return this.products.find(p => p.id === this.activeProductId) || this.products[0] || null;
  },

  async loadData() {
    const key = assertStorageKeyProduct(LIVE_INFINITY_CONFIG.STORAGE_KEYS.PRODUCTS_DATA, 'product_library');

    return new Promise((resolve) => {
      const applyRaw = (raw) => {
        if (raw) {
          this.parseData(raw);
        } else {
          this.migrateOrDefaults();
        }
        this.notifySubscribers();
        resolve();
      };

      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get([key], (result) => {
          const raw = result ? result[key] : null;
          applyRaw(raw);
        });
      } else {
        try {
          const raw = localStorage.getItem(key);
          applyRaw(raw ? JSON.parse(raw) : null);
        } catch (e) {
          applyRaw(null);
        }
      }
    });
  },

  parseData(data) {
    if (data && data.products && Array.isArray(data.products)) {
      this.products = data.products;
      this.activeProductId = data.activeProductId || (this.products[0] ? this.products[0].id : null);
    } else {
      this.migrateOrDefaults();
    }
  },

  migrateOrDefaults() {
    const oldPresetsKey = LIVE_INFINITY_CONFIG.STORAGE_KEYS.PRESETS_DATA || 'live_infinity_presets_data';

    let oldMsgs = null;
    try {
      oldMsgs = JSON.parse(localStorage.getItem(oldPresetsKey));
    } catch (e) {}

    const defaultComments1 = [
      '🔥 Esse ferro aquece muito rápido!',
      '👕 Ideal para deixar suas roupas impecáveis.',
      '🛒 Toque no carrinho para aproveitar a oferta!',
      '🚚 Frete grátis liberado para todo o Brasil!'
    ];

    const defaultComments2 = [
      '👕 Camiseta 100% Algodão Premium!',
      '✨ Conforto e caimento perfeito no corpo.',
      '🛒 Estoque limitado, aproveite o desconto!'
    ];

    const defaultComments3 = [
      '✂️ Fatiador Multifuncional 5 em 1!',
      '🔪 Agilidade e precisão para sua cozinha.',
      '🚚 Envio imediato para todo o Brasil!'
    ];

    const prod1 = {
      id: 'prod_' + Date.now() + '_1',
      name: 'Ferro de Passar',
      comments: (oldMsgs && oldMsgs[0]) ? oldMsgs[0].split('\n').filter(t => t.trim()) : defaultComments1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const prod2 = {
      id: 'prod_' + Date.now() + '_2',
      name: 'Camiseta Premium',
      comments: (oldMsgs && oldMsgs[1]) ? oldMsgs[1].split('\n').filter(t => t.trim()) : defaultComments2,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const prod3 = {
      id: 'prod_' + Date.now() + '_3',
      name: 'Fatiador Multifuncional',
      comments: (oldMsgs && oldMsgs[2]) ? oldMsgs[2].split('\n').filter(t => t.trim()) : defaultComments3,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.products = [prod1, prod2, prod3];
    this.activeProductId = prod1.id;
    this.saveData();
  },

  async saveData() {
    const key = assertStorageKeyProduct(LIVE_INFINITY_CONFIG.STORAGE_KEYS.PRODUCTS_DATA, 'product_library');
    const payload = {
      schemaVersion: 2,
      activeProductId: this.activeProductId,
      products: this.products
    };

    try {
      localStorage.setItem(key, JSON.stringify(payload));
    } catch (e) {}

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise((resolve) => {
        chrome.storage.local.set({ [key]: payload }, () => {
          const err = chrome.runtime && chrome.runtime.lastError;
          if (err) {
            console.warn('[Live Infinity] Aviso no storage.set:', err.message);
          }
          resolve(true);
        });
      });
    }
    this.notifySubscribers();
    return true;
  },

  async createProduct(data) {
    if (!data || typeof data.name !== 'string' || !data.name.trim()) {
      throw new Error('O nome do produto é obrigatório.');
    }

    const comments = Array.isArray(data.comments)
      ? data.comments.map(c => String(c).trim()).filter(c => c.length > 0)
      : String(data.comments || '').split(/\r?\n/).map(c => c.trim()).filter(c => c.length > 0);

    if (!comments.length) {
      throw new Error('Cadastre ao menos um comentário válido (uma frase por linha).');
    }

    const newProd = {
      id: 'prod_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      name: data.name.trim(),
      comments: comments,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.products.push(newProd);

    if (!this.activeProductId) {
      this.activeProductId = newProd.id;
    }

    await this.saveData();

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Biblioteca', `Novo produto "${newProd.name}" cadastrado.`);
    }

    return { success: true, product: newProd, productId: newProd.id };
  },

  async updateProduct(productId, changes) {
    if (typeof productId !== 'string' || !productId.trim()) {
      throw new TypeError('ID do produto é obrigatório.');
    }

    const targetId = productId.trim();
    const idx = this.products.findIndex(p => p.id === targetId);

    if (idx < 0) {
      throw new Error('Produto não encontrado.');
    }

    if (!changes || typeof changes.name !== 'string' || !changes.name.trim()) {
      throw new Error('O nome do produto é obrigatório.');
    }

    const comments = Array.isArray(changes.comments)
      ? changes.comments.map(c => String(c).trim()).filter(c => c.length > 0)
      : String(changes.comments || '').split(/\r?\n/).map(c => c.trim()).filter(c => c.length > 0);

    if (!comments.length) {
      throw new Error('Cadastre ao menos um comentário válido (uma frase por linha).');
    }

    const orig = this.products[idx];
    const updated = {
      ...orig,
      name: changes.name.trim(),
      comments: comments,
      updatedAt: new Date().toISOString()
    };

    this.products[idx] = updated;
    await this.saveData();

    if (this.activeProductId === targetId && window.LiveInfinityChat) {
      LiveInfinityChat.reloadActiveProductComments();
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Biblioteca', `Comentários do produto ativo "${updated.name}" atualizados.`);
      }
    } else if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Biblioteca', `Produto "${updated.name}" atualizado.`);
    }

    return { success: true, product: updated, productId: targetId };
  },

  // Alias unificado de conveniência que roteia com segurança para updateProduct ou createProduct
  async saveProduct(productData) {
    if (productData && productData.id && this.getProductById(productData.id)) {
      return await this.updateProduct(productData.id, productData);
    } else {
      return await this.createProduct(productData);
    }
  },

  async setActiveProduct(id) {
    const target = this.products.find(p => p.id === id);
    if (!target) return false;

    this.activeProductId = id;
    await this.saveData();

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Biblioteca', `Produto "${target.name}" ativado.`);
    }
    
    if (window.LiveInfinityChat) {
      LiveInfinityChat.reloadActiveProductComments();
    }

    if (window.LiveInfinityUI) {
      LiveInfinityUI.renderProductLibrary();
    }
    return true;
  },

  async activateProduct(id) {
    return await this.setActiveProduct(id);
  },

  async duplicateProduct(id) {
    const original = this.products.find(p => p.id === id);
    if (!original) return false;

    const copy = {
      id: 'prod_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      name: `${original.name} — Cópia`,
      comments: [...original.comments],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.products.push(copy);
    await this.saveData();

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Biblioteca', `Produto "${copy.name}" criado por duplicação.`);
    }
    return copy;
  },

  async deleteProduct(id) {
    const idx = this.products.findIndex(p => p.id === id);
    if (idx === -1) return false;

    const prod = this.products[idx];
    const wasActive = this.activeProductId === id;

    this.products.splice(idx, 1);

    if (wasActive) {
      this.activeProductId = this.products[0] ? this.products[0].id : null;
      if (window.LiveInfinityChat) {
        if (this.activeProductId) {
          LiveInfinityChat.reloadActiveProductComments();
        } else {
          LiveInfinityChat.stopComments();
        }
      }
    }

    await this.saveData();

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Biblioteca', `Produto "${prod.name}" removido.`);
    }
    return true;
  },

  subscribe(callback) {
    if (typeof callback === 'function') {
      this.subscribers.push(callback);
    }
  },

  notifySubscribers() {
    const snapshot = this.getSnapshot();
    this.subscribers.forEach(cb => {
      try { cb(snapshot); } catch (e) {}
    });
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityProductLibrary = LiveInfinityProductLibrary;
  window.LiveInfinityProducts = LiveInfinityProductLibrary; // Alias de compatibilidade total

  console.debug(
    "[Live Infinity] API de produtos:",
    Object.keys(window.LiveInfinityProducts ?? {})
  );
  console.debug(
    "[Live Infinity] API da biblioteca:",
    Object.keys(window.LiveInfinityProductLibrary ?? {})
  );
}
