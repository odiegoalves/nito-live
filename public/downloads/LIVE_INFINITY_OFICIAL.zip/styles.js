'use strict';

/* ===== Live Infinity — Design System & CSS (Botão de Recuperação de Chave no License Gate) ===== */
const LIVE_INFINITY_STYLES = `
:host {
  all: initial;
  font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
  color: #FFF8E7;
  font-size: 12px;
  line-height: 1.4;
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

/* ===== TELA DE ACESSO DE ALTA FIDELIDADE (LICENSE GATE REDESIGNED) ===== */
#li-gate {
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  width: 100vw;
  height: 100vh;
  z-index: 2147483647;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
  background: #07080d;
  pointer-events: auto;
  box-sizing: border-box;
  isolation: isolate;
  overflow-y: auto;
}

.li-gate-card {
  width: 340px;
  max-width: calc(100vw - 24px);
  background: #090a10;
  border: 1.2px solid rgba(212, 175, 55, 0.45);
  border-radius: 22px;
  padding: 24px 22px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.95), 0 0 35px rgba(242, 13, 24, 0.12);
  display: flex;
  flex-direction: column;
  align-items: center;
  box-sizing: border-box;
  margin: auto;
  pointer-events: auto;
  position: relative;
}

.login-symbol-frame {
  width: 104px;
  height: 68px;
  margin: 0 auto 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #050505;
  border: 1px solid rgba(212, 175, 55, 0.70);
  border-radius: 16px;
  box-shadow:
    0 0 18px rgba(215, 25, 32, 0.18),
    0 0 14px rgba(212, 175, 55, 0.12);
  overflow: hidden;
}

.login-symbol-frame img {
  width: 94px;
  height: auto;
  display: block;
  object-fit: contain;
}

.license-brand-title {
  font-size: 26px;
  font-weight: 900;
  line-height: 1.1;
  text-align: center;
  margin-bottom: 6px;
  font-family: inherit;
}

.brand-live {
  color: #f20d18;
}

.brand-infinity {
  color: #d4af37;
}

.license-brand-subtitle {
  font-size: 11.5px;
  font-weight: 700;
  color: #d4af37;
  text-align: center;
  margin-bottom: 20px;
  letter-spacing: 0.2px;
}

.license-instruction {
  font-size: 13.5px;
  font-weight: 500;
  color: rgba(255, 248, 231, 0.70);
  text-align: center;
  margin-bottom: 16px;
}

.li-gate-input {
  width: 100%;
  height: 50px;
  background: #050608;
  border: 1.2px solid rgba(212, 175, 55, 0.45);
  border-radius: 14px;
  padding: 0 14px;
  color: #fff8e7;
  font-family: 'Fira Code', monospace, sans-serif;
  font-size: 13px;
  font-weight: 700;
  text-align: center;
  letter-spacing: 1.5px;
  outline: none;
  transition: all 0.2s ease;
  margin-bottom: 14px;
  box-sizing: border-box;
}

.li-gate-input:focus {
  border-color: #d4af37;
  box-shadow: 0 0 12px rgba(212, 175, 55, 0.3);
}

.li-gate-input::placeholder {
  color: rgba(255, 248, 231, 0.25);
  font-weight: 700;
  letter-spacing: 1.5px;
}

.li-gate-btn-primary {
  width: 100%;
  height: 50px;
  background: #f20d18;
  border: none;
  border-radius: 14px;
  color: #ffffff;
  font-size: 14px;
  font-weight: 800;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  box-shadow: 0 4px 18px rgba(242, 13, 24, 0.4);
  transition: all 0.15s ease;
  font-family: inherit;
}

.li-gate-btn-primary:hover {
  background: #ff1f29;
  box-shadow: 0 6px 22px rgba(242, 13, 24, 0.6);
  transform: translateY(-1px);
}

.li-gate-btn-primary:active {
  transform: translateY(0);
}

.li-gate-st {
  font-size: 11.5px;
  font-weight: 700;
  color: #ff3b30;
  text-align: center;
  margin-top: 8px;
  min-height: 16px;
  line-height: 1.35;
}

.license-recovery-box {
  width: 100%;
  border: 1.5px dashed rgba(212, 175, 55, 0.45);
  border-radius: 14px;
  padding: 16px 14px;
  margin-top: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  box-sizing: border-box;
  background: rgba(5, 6, 8, 0.4);
}

.recovery-title {
  font-size: 12px;
  font-weight: 800;
  color: #d4af37;
  margin-bottom: 6px;
}

.recovery-subtext {
  font-size: 10.5px;
  color: rgba(255, 248, 231, 0.65);
  line-height: 1.35;
  margin-bottom: 12px;
}

.li-gate-btn-gold {
  width: 100%;
  height: 42px;
  background: #d4af37;
  border: none;
  border-radius: 10px;
  color: #07080d;
  font-size: 12px;
  font-weight: 800;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  box-shadow: 0 4px 14px rgba(212, 175, 55, 0.3);
  transition: all 0.15s ease;
  font-family: inherit;
}

.li-gate-btn-gold:hover {
  background: #ffe57f;
  box-shadow: 0 6px 18px rgba(212, 175, 55, 0.5);
  transform: translateY(-1px);
}

.license-renew-wrapper {
  margin-top: 16px;
  font-size: 11px;
  color: rgba(255, 248, 231, 0.6);
  text-align: center;
}

.license-renew-link {
  background: none;
  border: none;
  color: #d4af37;
  font-weight: 700;
  text-decoration: underline;
  cursor: pointer;
  font-family: inherit;
  font-size: 11px;
  padding: 0;
}

.license-renew-link:hover {
  color: #fff8e7;
}

/* BOTÃO DE RECUPERAÇÃO DE CHAVE NO LICENSE GATE */
.li-btn-recover-key {
  width: 100%;
  min-height: 42px;
  padding: 8px 12px;
  background: transparent !important;
  border: 1.5px solid #D4AF37 !important;
  border-radius: 9px;
  color: #F4D675 !important;
  font-size: 11px;
  font-weight: 800;
  cursor: pointer;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: none !important;
  font-family: inherit;
  box-sizing: border-box;
}

.li-btn-recover-key:hover {
  background: #D4AF37 !important;
  color: #160C08 !important;
  border-color: #F4D675 !important;
  box-shadow: 0 4px 14px rgba(212, 175, 55, 0.35) !important;
  transform: translateY(-1px);
}

.li-gate-link {
  color: #F4D675;
  text-decoration: underline;
  font-weight: 700;
  transition: color 0.15s ease;
}

.li-gate-link:hover {
  color: #FFF8E7;
}

/* Container Principal do Hub (Central de Comando 460px) */
#li-hub {
  position: fixed;
  top: 12px;
  right: 12px;
  z-index: 2147483645;
  width: 460px;
  max-width: calc(100vw - 24px);
  height: calc(100vh - 24px);
  max-height: 940px;
  background: #090909;
  color: #FFF8E7;
  border: 1px solid rgba(212, 175, 55, 0.35);
  border-radius: 16px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.9), 0 0 25px rgba(215, 25, 32, 0.15);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  isolation: isolate;
  backdrop-filter: blur(14px);
  transition: width 0.2s ease, transform 0.15s ease;
  pointer-events: auto;
}

/* Header Fixo e Compacto */
.li-header {
  height: 48px;
  background: linear-gradient(180deg, #12100F 0%, #090909 100%);
  border-bottom: 1px solid rgba(212, 175, 55, 0.25);
  padding: 0 14px;
  cursor: move;
  display: flex;
  align-items: center;
  gap: 8px;
  flex: none;
}

.li-logo-group {
  display: flex;
  align-items: center;
  gap: 8px;
}

.li-brand-title {
  font-size: 15px;
  font-weight: 800;
  background: linear-gradient(90deg, #FFF8E7 0%, #F4D675 70%, #D4AF37 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

/* Badge de Status Reativo no Cabeçalho */
.li-status-indicator {
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  transition: all 0.2s ease;
  white-space: nowrap;
}

.li-status-active {
  background: linear-gradient(135deg, #F4D675 0%, #D4AF37 100%);
  color: #160C08;
  border: 1px solid #D71920;
  box-shadow: 0 0 10px rgba(244, 214, 117, 0.4);
}

.li-status-starting {
  background: #8E6918;
  color: #FFF8E7;
  border: 1px solid #F4D675;
}

.li-status-waiting {
  background: #C99825;
  color: #160C08;
  border: 1px solid #D71920;
}

.li-status-inactive {
  background: #191513;
  color: #C8BCA5;
  border: 1px solid rgba(212, 175, 55, 0.25);
}

.li-status-error {
  background: #780B10;
  color: #FFF8E7;
  border: 1px solid #FF2834;
}

.li-status-blocked {
  background: #3B0003;
  color: #FF2834;
  border: 1px solid #FF2834;
}

.li-icon-btn {
  width: 28px;
  height: 28px;
  border-radius: 8px;
  border: 1px solid rgba(212, 175, 55, 0.25);
  background: #191513;
  color: #FFF8E7;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  font-size: 12px;
  transition: all 0.15s ease;
}

.li-icon-btn:hover {
  background: #211A16;
  border-color: #D4AF37;
  color: #F4D675;
}

/* Layout Principal (Sidebar + Workspace) */
.li-body-layout {
  display: flex;
  flex: 1;
  overflow: hidden;
  position: relative;
}

/* Sidebar de Navegação Lateral */
.li-sidebar {
  width: 56px;
  background: #12100F;
  border-right: 1px solid rgba(212, 175, 55, 0.2);
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 10px 0;
  gap: 6px;
  flex: none;
  z-index: 5;
}

.li-nav-item {
  width: 40px;
  height: 40px;
  border-radius: 10px;
  border: 1px solid transparent;
  background: transparent;
  color: #C8BCA5;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  cursor: pointer;
  position: relative;
  transition: all 0.15s ease;
}

.li-nav-item:hover {
  background: #191513;
  color: #FFF8E7;
  border-color: rgba(212, 175, 55, 0.3);
}

.li-nav-item.li-active {
  background: linear-gradient(135deg, #191513 0%, #211A16 100%);
  color: #F4D675;
  border-color: #D4AF37;
  box-shadow: 0 0 12px rgba(212, 175, 55, 0.25);
}

/* Área de Conteúdo Scrollável */
.li-workspace {
  flex: 1;
  background: #090909;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 14px;
  scrollbar-width: thin;
  scrollbar-color: #8E6918 #12100F;
}

.li-workspace::-webkit-scrollbar {
  width: 5px;
}
.li-workspace::-webkit-scrollbar-track {
  background: #12100F;
}
.li-workspace::-webkit-scrollbar-thumb {
  background: #8E6918;
  border-radius: 4px;
}

/* Views das Páginas */
.li-view {
  display: none;
  flex-direction: column;
  gap: 12px;
}

.li-view.li-view-active {
  display: flex;
}

/* Título de Seção */
.li-view-title {
  font-size: 14px;
  font-weight: 800;
  color: #F4D675;
  letter-spacing: 0.5px;
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 2px;
}

.li-view-sub {
  font-size: 11px;
  color: #C8BCA5;
  margin-bottom: 8px;
}

/* Cards Genéricos */
.li-card {
  background: #191513;
  border: 1px solid rgba(212, 175, 55, 0.2);
  border-radius: 12px;
  padding: 12px;
  transition: border-color 0.15s ease, transform 0.15s ease;
}

.li-card:hover {
  border-color: rgba(212, 175, 55, 0.4);
}

.li-card-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
  font-weight: 700;
  font-size: 12px;
  color: #FFF8E7;
}

/* ===== ESTILO DOS BOTÕES OPERACIONAIS (REGRA VISUAL: INATIVO = VERMELHO COM BORDA DOURADA / ATIVO = DOURADO COM BORDA VERMELHA) ===== */
.li-btn-go,
.li-operation-button {
  width: 100%;
  min-height: 38px;
  padding: 8px 12px;
  border: 1.5px solid #D4AF37;
  border-radius: 9px;
  background: linear-gradient(90deg, #B80F18 0%, #780B10 100%);
  color: #FFF8E7;
  font-weight: 800;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
  box-shadow: 0 4px 14px rgba(184, 15, 24, 0.25);
  font-family: inherit;
  font-size: 12px;
}

.li-btn-go:hover,
.li-operation-button:hover {
  background: linear-gradient(90deg, #D71920 0%, #B80F18 100%);
  border-color: #F4D675;
  box-shadow: 0 6px 18px rgba(215, 25, 32, 0.35);
  transform: translateY(-1px);
}

/* ESTADO ATIVO: Fundo Dourado (#F4D675 / #D4AF37), Borda Vermelha (#D71920) e Texto Escuro (#160C08) */
.li-operation-button[data-state="active"],
.li-operation-button.is-active,
.li-btn-go.is-active,
.li-btn-go[data-state="active"] {
  background: linear-gradient(135deg, #F4D675 0%, #D4AF37 55%, #B98A20 100%) !important;
  border: 2px solid #D71920 !important;
  color: #160C08 !important;
  box-shadow: 0 0 0 1px rgba(215, 25, 32, 0.25), 0 4px 14px rgba(212, 175, 55, 0.28) !important;
  font-weight: 800 !important;
}

.li-operation-button[data-state="active"]:hover,
.li-operation-button.is-active:hover,
.li-btn-go.is-active:hover,
.li-btn-go[data-state="active"]:hover {
  background: linear-gradient(135deg, #FFE28A 0%, #E2BB42 55%, #C99825 100%) !important;
  border-color: #FF2834 !important;
  color: #160C08 !important;
}

/* ESTADO INICIANDO: Fundo Dourado Escuro Opaco */
.li-operation-button[data-state="starting"],
.li-operation-button.is-starting,
.li-btn-go.is-starting,
.li-btn-go[data-state="starting"] {
  background: #8E6918 !important;
  border: 2px solid #D4AF37 !important;
  color: #FFF8E7 !important;
  opacity: 0.85;
  cursor: wait !important;
}

/* ESTADO AGUARDANDO LIVE: Fundo Dourado Suave com Borda Vermelha */
.li-operation-button[data-state="waiting"],
.li-operation-button.is-waiting,
.li-btn-go.is-waiting,
.li-btn-go[data-state="waiting"] {
  background: linear-gradient(135deg, #C99825 0%, #8E6918 100%) !important;
  border: 2px solid #D71920 !important;
  color: #FFF8E7 !important;
}

/* ESTADO ERRO: Fundo Vermelho Escuro com Borda Vívida */
.li-operation-button[data-state="error"],
.li-operation-button.is-error,
.li-btn-go.is-error,
.li-btn-go[data-state="error"] {
  background: #780B10 !important;
  border: 2px solid #FF2834 !important;
  color: #FFF8E7 !important;
}

/* BOTÕES SECUNDÁRIOS / DESTRUTIVOS (PRESERVAÇÃO SEMÂNTICA) */
.li-btn-secondary {
  background: #191513 !important;
  border: 1px solid rgba(212, 175, 55, 0.4) !important;
  color: #F4D675 !important;
  box-shadow: none !important;
}

.li-btn-secondary:hover {
  background: #211A16 !important;
  border-color: #D4AF37 !important;
  color: #FFF8E7 !important;
  box-shadow: 0 4px 12px rgba(212, 175, 55, 0.2) !important;
}

.li-btn-stop {
  background: #780B10 !important;
  border: 1.5px solid #FF2834 !important;
  color: #FFF8E7 !important;
  box-shadow: none !important;
}

.li-btn-stop:hover {
  background: #D71920 !important;
}

/* Inputs e Textareas */
.li-input, .li-textarea {
  width: 100%;
  background: #12100F;
  border: 1px solid rgba(212, 175, 55, 0.3);
  border-radius: 8px;
  padding: 8px 10px;
  color: #FFF8E7;
  font-family: inherit;
  font-size: 12px;
  outline: none;
  transition: border-color 0.15s ease;
}

.li-input::placeholder,
.li-textarea::placeholder,
.conversation-input::placeholder,
.conversation-textarea::placeholder {
  color: rgba(255, 248, 231, 0.28) !important;
  opacity: 1 !important;
  font-style: italic !important;
  font-weight: 400 !important;
}

.li-input:focus, .li-textarea:focus {
  border-color: #D4AF37;
  box-shadow: 0 0 8px rgba(212, 175, 55, 0.25);
}

.li-label {
  display: block;
  font-size: 10px;
  font-weight: 700;
  color: #C8BCA5;
  margin-top: 8px;
  margin-bottom: 4px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.li-desc {
  font-size: 11px;
  color: #C8BCA5;
  margin-bottom: 8px;
  line-height: 1.35;
}

/* Switch Toggles */
.li-switch-label {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 11px;
  color: #FFF8E7;
  cursor: pointer;
}

.li-switch {
  position: relative;
  display: inline-block;
  width: 38px;
  height: 20px;
}

.li-switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.li-slider {
  position: absolute;
  cursor: pointer;
  top: 0; left: 0; right: 0; bottom: 0;
  background-color: #211A16;
  border: 1px solid rgba(212, 175, 55, 0.3);
  transition: .3s;
  border-radius: 20px;
}

.li-slider:before {
  position: absolute;
  content: "";
  height: 14px;
  width: 14px;
  left: 2px;
  bottom: 2px;
  background-color: #C8BCA5;
  transition: .3s;
  border-radius: 50%;
}

input:checked + .li-slider {
  background: linear-gradient(90deg, #F4D675 0%, #D4AF37 100%);
  border-color: #D71920;
}

input:checked + .li-slider:before {
  transform: translateX(18px);
  background-color: #160C08;
}

/* Tab Bar */
.li-tab-bar {
  display: flex;
  gap: 6px;
  background: #12100F;
  padding: 4px;
  border-radius: 10px;
  border: 1px solid rgba(212, 175, 55, 0.2);
}

.li-tab-btn {
  flex: 1;
  padding: 6px 12px;
  border: none;
  background: transparent;
  color: #C8BCA5;
  font-weight: 700;
  border-radius: 7px;
  cursor: pointer;
  font-size: 11px;
  transition: all 0.15s ease;
}

.li-tab-btn.li-tab-active {
  background: #191513;
  color: #F4D675;
  border: 1px solid #D4AF37;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.5);
}

/* Presets Bar do Timer */
.li-preset-bar {
  display: flex;
  gap: 6px;
  margin-bottom: 10px;
}

.li-preset-pill {
  flex: 1;
  padding: 6px 0;
  border: 1px solid rgba(212, 175, 55, 0.25);
  background: #12100F;
  color: #C8BCA5;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 700;
  cursor: pointer;
  text-align: center;
  transition: all 0.15s ease;
}

.li-preset-pill:hover {
  border-color: #D4AF37;
  color: #FFF8E7;
}

.li-preset-pill.li-active,
.li-preset-pill.is-selected {
  background: linear-gradient(135deg, #191513 0%, #211A16 100%);
  border-color: #F4D675;
  color: #F4D675;
  box-shadow: 0 0 8px rgba(244, 214, 117, 0.2);
}

/* Gauge Semicírculo */
.li-gauge-semicircle-container {
  position: relative;
  width: 100%;
  max-width: 280px;
  margin: 0 auto;
}

.li-gauge-svg {
  width: 100%;
  height: auto;
  display: block;
}

.li-gauge-track {
  fill: none;
  stroke: #211A16;
  stroke-width: 16;
  stroke-linecap: round;
}

.li-gauge-progress {
  fill: none;
  stroke: url(#li_gauge_gold_grad);
  stroke-width: 16;
  stroke-linecap: round;
  stroke-dasharray: 377;
  stroke-dashoffset: 0;
  transition: stroke-dashoffset 0.8s ease-in-out;
}

.li-gauge-center-text {
  position: absolute;
  bottom: 15px;
  left: 0;
  right: 0;
  text-align: center;
}

.li-timer-display-hms {
  font-size: 24px;
  font-weight: 800;
  font-family: 'Fira Code', monospace;
  color: #F4D675;
  text-shadow: 0 0 10px rgba(244, 214, 117, 0.3);
}

.li-timer-end-time {
  font-size: 10px;
  color: #C8BCA5;
  margin-top: 2px;
}

/* Produtos na Biblioteca */
.li-product-card {
  background: #12100F;
  border: 1px solid rgba(212, 175, 55, 0.2);
  border-radius: 10px;
  padding: 10px;
  margin-bottom: 8px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  transition: all 0.2s ease;
}

.li-product-card.li-active {
  border: 2px solid #D71920 !important;
  background: linear-gradient(135deg, #211A16 0%, #191513 100%) !important;
  box-shadow: 0 0 14px rgba(212, 175, 55, 0.3) !important;
}

.li-product-card.li-active .li-status-indicator {
  background: linear-gradient(135deg, #F4D675 0%, #D4AF37 100%) !important;
  color: #160C08 !important;
  border: 1px solid #D71920 !important;
  font-weight: 800 !important;
}

.li-product-card-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.li-product-card-title {
  font-weight: 800;
  color: #F4D675;
  font-size: 12px;
}

.li-product-actions {
  display: flex;
  gap: 6px;
  margin-top: 4px;
}

/* Logs e Timeline */
.li-log-box {
  height: 140px;
  background: #12100F;
  border: 1px solid rgba(212, 175, 55, 0.2);
  border-radius: 8px;
  padding: 8px;
  font-family: 'Fira Code', monospace;
  font-size: 10px;
  color: #FFF8E7;
  overflow-y: auto;
  white-space: pre-wrap;
}

.li-timeline {
  display: flex;
  flex-direction: column;
  gap: 6px;
  max-height: 140px;
  overflow-y: auto;
}

.li-timeline-item {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  font-size: 10px;
  color: #C8BCA5;
  padding: 4px 0;
  border-bottom: 1px solid rgba(212, 175, 55, 0.1);
}

.li-timeline-icon {
  font-size: 11px;
}

/* Status Bar Rodapé */
.li-status-bar {
  height: 28px;
  background: #12100F;
  border-top: 1px solid rgba(212, 175, 55, 0.2);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 12px;
  font-size: 10px;
  color: #C8BCA5;
  flex: none;
}

/* Modais e Overlays */
.li-overlay-root {
  position: absolute;
  top: 0; left: 0; width: 100%; height: 100%;
  z-index: 200;
  display: none;
  align-items: center;
  justify-content: center;
}

.li-overlay-root.is-open {
  display: flex;
}

.li-backdrop {
  position: absolute;
  top: 0; left: 0; width: 100%; height: 100%;
  background: rgba(9, 9, 9, 0.85);
  backdrop-filter: blur(4px);
}

.li-operation-modal {
  position: relative;
  z-index: 201;
  width: 380px;
  max-width: 90%;
  background: #191513;
  border: 1px solid #D4AF37;
  border-radius: 14px;
  padding: 18px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.9);
}

.li-review-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 0;
  font-size: 11px;
  color: #FFF8E7;
}

.li-chat-preview-drawer {
  position: absolute;
  bottom: 0; left: 0; width: 100%;
  background: #191513;
  border-top: 2px solid #D4AF37;
  padding: 14px;
  z-index: 202;
  border-radius: 16px 16px 0 0;
  box-shadow: 0 -10px 30px rgba(0, 0, 0, 0.8);
}

.li-chat-bubble-preview {
  background: #12100F;
  border: 1px solid rgba(212, 175, 55, 0.3);
  border-radius: 8px;
  padding: 8px 10px;
  margin-top: 8px;
  font-size: 11px;
}

/* Mini Painel Informativo */
/* Mini Painel Informativo Compactado */
#li-mini-panel,
.live-infinity-minimized {
  position: fixed;
  top: 64px; right: 12px;
  z-index: 2147483645;
  width: 230px !important;
  min-width: 230px !important;
  max-width: 230px !important;
  height: 82px !important;
  min-height: 82px !important;
  max-height: 82px !important;
  background: #12100F;
  border: 1.5px solid #D4AF37;
  border-radius: 14px;
  padding: 8px 10px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.85);
  display: none;
  flex-direction: column;
  justify-content: space-between;
  cursor: grab;
  pointer-events: auto;
  overflow: hidden;
  box-sizing: border-box;
  isolation: isolate;
  transition: transform 0.15s ease;
}

#li-mini-panel.is-dragging {
  cursor: grabbing;
  transform: scale(1.02);
}

.li-mini-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 22px;
  min-width: 0;
}

.minimized-brand,
.li-mini-brand {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  white-space: nowrap;
  flex: 1 1 auto;
  overflow: hidden;
}

.minimized-brand-name {
  font-size: 11px;
  font-weight: 800;
  line-height: 1;
  white-space: nowrap;
  letter-spacing: 0.2px;
}

.li-mini-controls {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: 0 0 auto;
}

.minimized-status {
  font-size: 9px !important;
  padding: 3px 6px !important;
  white-space: nowrap;
  flex: 0 0 auto;
  line-height: 1;
}

.li-mini-body,
.minimized-metrics {
  display: grid;
  grid-template-columns: 1fr 1px 1fr;
  align-items: center;
  height: 35px;
  margin-top: 4px;
  background: #191513;
  padding: 2px 8px;
  border-radius: 8px;
  border: 1px solid rgba(212, 175, 55, 0.2);
}

.li-mini-metric {
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.li-mini-metric-label {
  font-size: 9px;
  color: #C8BCA5;
  font-weight: 700;
  line-height: 1;
  margin-bottom: 2px;
}

.li-mini-metric-value {
  font-size: 12px;
  font-weight: 800;
  color: #F4D675;
  line-height: 1;
}

.li-val-white {
  color: #FFF8E7;
}
`;

if (typeof window !== 'undefined') {
  window.LIVE_INFINITY_STYLES = LIVE_INFINITY_STYLES;
}
