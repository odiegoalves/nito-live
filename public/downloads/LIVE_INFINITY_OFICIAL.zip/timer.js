'use strict';

/* ===== Live Infinity — Timer de Encerramento (Motor de Encerramento do LiveGoPro Portado) ===== */
const LiveInfinityTimer = {
  fase: 'off', // 'off', 'contando', 'pausado', 'locating_end_button', 'awaiting_confirmation', 'confirming_end', 'completed', 'end_failed'
  duracaoTotalMs: 7200000, // 2 horas padrão
  deadline: 0,
  resto: 0,
  timerId: null,
  completionHandled: false,
  busy: false,
  endLiveInProgress: false,
  confirmando: false,

  // Isolamento estrito do Shadow DOM da Live Infinity
  isInsideLiveInfinity(el) {
    if (!el) return true;
    try {
      const root = el.getRootNode ? el.getRootNode() : null;
      if (root === window.__liveInfinityShadow) return true;
      if (el.closest && el.closest('#live-infinity-root-host, #li-hub, #li-mini-panel, [data-live-infinity], .live-infinity-panel')) {
        return true;
      }
    } catch (e) {}
    return false;
  },

  // Estrutura de Estado Única do Timer
  get status() {
    if (this.fase === 'contando') return 'running';
    if (this.fase === 'pausado') return 'paused';
    if (this.fase === 'completed') return 'completed';
    if (this.fase === 'end_failed') return 'end_failed';
    if (['locating_end_button', 'awaiting_confirmation', 'confirming_end'].includes(this.fase)) return 'ending';
    return 'idle';
  },

  getState() {
    return {
      status: this.status,
      fase: this.fase,
      endAt: this.fase === 'contando' ? this.deadline : null,
      remainingMs: this.fase === 'contando' ? Math.max(0, this.deadline - Date.now()) : (this.fase === 'pausado' ? this.resto : 0),
      durationMs: this.duracaoTotalMs
    };
  },

  init() {
    this.restore();
  },

  async restore() {
    if (!window.LiveInfinityStateStore) return;
    const store = LiveInfinityStateStore.state;
    const timerState = store.timer || {};

    if (timerState.status === 'COMPLETED' || timerState.completionHandled) {
      this.fase = 'completed';
      this.completionHandled = true;
      this.updateUI();
      return;
    }

    if (!timerState.desiredEnabled || timerState.status === 'OFF') {
      this.fase = 'off';
      this.updateUI();
      return;
    }

    if (timerState.status === 'RUNNING' && timerState.endsAt) {
      const now = Date.now();
      if (timerState.endsAt > now) {
        this.duracaoTotalMs = timerState.totalDurationMs || 7200000;
        this.deadline = timerState.endsAt;
        this.fase = 'contando';
        this.completionHandled = false;

        if (this.timerId) clearInterval(this.timerId);
        this.timerId = setInterval(() => this.tick(), 500);
        this.tick();
        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Timer', `Timer de encerramento restaurado pós-F5 (Término às ${new Date(this.deadline).toLocaleTimeString()})`);
        }
      } else if (!this.completionHandled && !this.endLiveInProgress) {
        this.handleTimeout();
      }
    } else if (timerState.status === 'PAUSED' && typeof timerState.pausedRemainingMs === 'number') {
      this.fase = 'pausado';
      this.duracaoTotalMs = timerState.totalDurationMs || 7200000;
      this.resto = timerState.pausedRemainingMs;
      this.updateUI();
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Timer', 'Timer de encerramento restaurado no estado PAUSADO');
      }
    }
  },

  fmtHHMMSS(ms) {
    if (ms < 0) ms = 0;
    const totalSec = Math.floor(ms / 1000);
    const hh = String(Math.floor(totalSec / 3600)).padStart(2, '0');
    const mm = String(Math.floor((totalSec % 3600) / 60)).padStart(2, '0');
    const ss = String(totalSec % 60).padStart(2, '0');
    return `${hh}:${mm}:${ss}`;
  },

  parseTimerDurationInput(inputVal) {
    if (typeof inputVal !== 'string') {
      return { ok: false, error: 'Digite minutos, como 36, ou uma duração como 01:30:00.' };
    }
    const normalized = inputVal.trim();
    if (!normalized) {
      return { ok: false, error: 'Digite a duração desejada antes de aplicar.' };
    }

    if (/^\d+$/.test(normalized)) {
      const totalMinutes = Number(normalized);
      if (totalMinutes <= 0) {
        return { ok: false, error: 'Informe uma duração maior que zero.' };
      }
      const durationMs = totalMinutes * 60 * 1000;
      return {
        ok: true,
        durationMs: durationMs,
        minutes: totalMinutes,
        formatted: this.fmtHHMMSS(durationMs)
      };
    }

    const parts = normalized.split(':').map(p => p.trim());
    if (parts.some(p => !/^\d+$/.test(p))) {
      return { ok: false, error: 'Digite minutos, como 36, ou uma duração como 01:30:00.' };
    }

    let totalSeconds = 0;
    if (parts.length === 3) {
      const h = Number(parts[0]);
      const m = Number(parts[1]);
      const s = Number(parts[2]);
      if (m > 59 || s > 59) {
        return { ok: false, error: 'Digite minutos, como 36, ou uma duração como 01:30:00.' };
      }
      totalSeconds = h * 3600 + m * 60 + s;
    } else if (parts.length === 2) {
      const m = Number(parts[0]);
      const s = Number(parts[1]);
      if (s > 59) {
        return { ok: false, error: 'Digite minutos, como 36, ou uma duração como 01:30:00.' };
      }
      totalSeconds = m * 60 + s;
    } else {
      return { ok: false, error: 'Digite minutos, como 36, ou uma duração como 01:30:00.' };
    }

    if (totalSeconds <= 0) {
      return { ok: false, error: 'Informe uma duração maior que zero.' };
    }

    const durationMs = totalSeconds * 1000;
    return {
      ok: true,
      durationMs: durationMs,
      minutes: Math.round(totalSeconds / 60),
      formatted: this.fmtHHMMSS(durationMs)
    };
  },

  applyPreset(minutes) {
    if (this.status !== 'idle') return;
    const mins = Number(minutes);
    if (!Number.isFinite(mins) || mins <= 0) return;

    this.duracaoTotalMs = mins * 60 * 1000;

    const shadow = window.__liveInfinityShadow;
    if (shadow) {
      const inputHMS = shadow.getElementById('li-rt-hms');
      if (inputHMS) inputHMS.value = this.fmtHHMMSS(this.duracaoTotalMs);

      const errBox = shadow.getElementById('li-rt-error');
      if (errBox) errBox.style.display = 'none';

      this.updateSelectedPresetPills(mins);
    }
    this.updateUI();
  },

  selectPreset(minutes) {
    this.applyPreset(minutes);
  },

  updateSelectedPresetPills(minutes) {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;
    const pills = shadow.querySelectorAll('.li-preset-pill');
    pills.forEach((p) => {
      const minAttr = parseInt(p.getAttribute('data-timer-preset-minutes') || p.getAttribute('data-min'), 10);
      p.classList.toggle('li-active', minAttr === minutes);
    });
  },

  onInputChange(valStr) {
    if (this.status !== 'idle') return;
    const shadow = window.__liveInfinityShadow;
    const errBox = shadow ? shadow.getElementById('li-rt-error') : null;

    const res = this.parseTimerDurationInput(valStr);
    if (res.ok) {
      if (errBox) errBox.style.display = 'none';
      this.duracaoTotalMs = res.durationMs;
      this.updateSelectedPresetPills(res.minutes);

      const displayHms = shadow ? shadow.getElementById('li-rt-restante') : null;
      if (displayHms) displayHms.textContent = res.formatted;
    }
  },

  onInputBlur(valStr) {
    if (this.status !== 'idle') return;
    const shadow = window.__liveInfinityShadow;
    const inputHMS = shadow ? shadow.getElementById('li-rt-hms') : null;
    const errBox = shadow ? shadow.getElementById('li-rt-error') : null;

    const res = this.parseTimerDurationInput(valStr);
    if (res.ok) {
      if (errBox) errBox.style.display = 'none';
      this.duracaoTotalMs = res.durationMs;
      if (inputHMS) inputHMS.value = res.formatted;
      this.updateSelectedPresetPills(res.minutes);
      this.updateUI();
    } else {
      if (errBox) {
        errBox.textContent = res.error;
        errBox.style.display = 'block';
      }
    }
  },

  async arm() {
    if (this.busy || this.status !== 'idle') return;
    this.busy = true;

    const shadow = window.__liveInfinityShadow;
    const inputHMS = shadow ? shadow.getElementById('li-rt-hms') : null;
    const errBox = shadow ? shadow.getElementById('li-rt-error') : null;
    const btnArm = shadow ? shadow.getElementById('li-rt-armar') : null;

    if (btnArm) btnArm.disabled = true;
    if (errBox) errBox.style.display = 'none';

    try {
      const valStr = inputHMS ? inputHMS.value : '';
      const parseRes = this.parseTimerDurationInput(valStr);

      if (!parseRes.ok) {
        if (errBox) {
          errBox.textContent = parseRes.error;
          errBox.style.display = 'block';
        }
        return;
      }

      this.duracaoTotalMs = parseRes.durationMs;
      if (inputHMS) inputHMS.value = parseRes.formatted;
      this.updateSelectedPresetPills(parseRes.minutes);

      this.deadline = Date.now() + this.duracaoTotalMs;
      this.fase = 'contando';
      this.completionHandled = false;
      this.endLiveInProgress = false;
      this.confirmando = false;

      if (window.LiveInfinityStateStore) {
        await LiveInfinityStateStore.setTimerState({
          desiredEnabled: true,
          status: 'RUNNING',
          totalDurationMs: this.duracaoTotalMs,
          endsAt: this.deadline,
          pausedRemainingMs: null,
          completionHandled: false
        });
      }

      if (this.timerId) clearInterval(this.timerId);
      this.timerId = setInterval(() => this.tick(), 500);
      this.tick();

      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Timer', `Timer ativado para ${parseRes.formatted}`);
      }
    } finally {
      setTimeout(() => {
        if (btnArm) btnArm.disabled = false;
        this.busy = false;
      }, 300);
    }
  },

  async pauseResume() {
    if (this.busy) return;
    this.busy = true;

    const shadow = window.__liveInfinityShadow;
    const btnPause = shadow ? shadow.getElementById('li-rt-pausa') : null;
    if (btnPause) btnPause.disabled = true;

    try {
      if (this.status === 'running') {
        this.fase = 'pausado';
        this.resto = Math.max(0, this.deadline - Date.now());
        if (this.timerId) clearInterval(this.timerId);

        if (window.LiveInfinityStateStore) {
          await LiveInfinityStateStore.setTimerState({
            desiredEnabled: true,
            status: 'PAUSED',
            totalDurationMs: this.duracaoTotalMs,
            endsAt: null,
            pausedRemainingMs: this.resto
          });
        }
        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Timer', 'Timer pausado pelo usuário.');
        }
      } else if (this.status === 'paused') {
        this.fase = 'contando';
        this.deadline = Date.now() + this.resto;

        if (window.LiveInfinityStateStore) {
          await LiveInfinityStateStore.setTimerState({
            desiredEnabled: true,
            status: 'RUNNING',
            totalDurationMs: this.duracaoTotalMs,
            endsAt: this.deadline,
            pausedRemainingMs: null
          });
        }

        if (this.timerId) clearInterval(this.timerId);
        this.timerId = setInterval(() => this.tick(), 500);
        this.tick();
        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Timer', 'Timer retomado pelo usuário.');
        }
      }
      this.updateUI();
    } finally {
      setTimeout(() => {
        if (btnPause) btnPause.disabled = false;
        this.busy = false;
      }, 300);
    }
  },

  async cancel() {
    if (this.busy) return;
    this.busy = true;

    const shadow = window.__liveInfinityShadow;
    const btnCancel = shadow ? shadow.getElementById('li-rt-cancel') : null;
    if (btnCancel) btnCancel.disabled = true;

    try {
      this.fase = 'off';
      this.endLiveInProgress = false;
      this.confirmando = false;
      if (this.timerId) clearInterval(this.timerId);
      this.timerId = null;

      if (window.LiveInfinityStateStore) {
        await LiveInfinityStateStore.setTimerState({
          desiredEnabled: false,
          status: 'OFF',
          endsAt: null,
          pausedRemainingMs: null,
          completionHandled: false
        });
      }

      this.updateUI();
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Timer', 'Timer cancelado pelo usuário.');
      }
    } finally {
      setTimeout(() => {
        if (btnCancel) btnCancel.disabled = false;
        this.busy = false;
      }, 300);
    }
  },

  stop() {
    this.cancel();
  },

  resetTimerToIdle() {
    this.fase = 'off';
    this.completionHandled = false;
    this.endLiveInProgress = false;
    this.confirmando = false;
    this.busy = false;
    if (this.timerId) clearInterval(this.timerId);
    this.timerId = null;

    const shadow = window.__liveInfinityShadow;
    if (shadow) {
      const displayHms = shadow.getElementById('li-rt-restante');
      const endTimeEl = shadow.getElementById('li-rt-termino');
      const statusEl = shadow.getElementById('li-rt-status');
      const btnArm = shadow.getElementById('li-rt-armar');
      const btnPause = shadow.getElementById('li-rt-pausa');
      const btnCancel = shadow.getElementById('li-rt-cancel');
      const inputHMS = shadow.getElementById('li-rt-hms');
      const pills = shadow.querySelectorAll('.li-preset-pill');

      if (displayHms) displayHms.textContent = this.fmtHHMMSS(this.duracaoTotalMs);
      if (endTimeEl) endTimeEl.textContent = 'Término previsto: --:--';
      if (statusEl) statusEl.textContent = 'Timer desligado.';

      if (btnArm) {
        btnArm.style.display = 'block';
        btnArm.disabled = false;
        btnArm.textContent = '▶ Iniciar Timer';
        btnArm.setAttribute('data-state', 'inactive');
      }
      if (btnPause) btnPause.style.display = 'none';
      if (btnCancel) btnCancel.style.display = 'none';

      pills.forEach((p) => {
        p.disabled = false;
        p.style.opacity = '1';
        p.style.cursor = 'pointer';
      });
      if (inputHMS) inputHMS.disabled = false;
    }
    this.updateUI();
  },

  /* ===== PORT DIRETO DAS FUNÇÕES NATIVAS DO LIVEGOPRO ===== */

  $s(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  },

  vis(el) {
    if (!el || this.isInsideLiveInfinity(el)) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  },

  fora(el) {
    return !this.isInsideLiveInfinity(el);
  },

  clicar(el) {
    if (!el || this.isInsideLiveInfinity(el)) return;
    const alvo = (el.closest && el.closest('button, [role="button"], a')) || el;
    try {
      alvo.scrollIntoView({ block: 'center' });
    } catch (e) {}

    const fire = (tp) => {
      try {
        const r = alvo.getBoundingClientRect();
        const cx = Math.round(r.left + r.width / 2);
        const cy = Math.round(r.top + r.height / 2);
        let E;
        if (tp.indexOf('pointer') === 0 && window.PointerEvent) {
          E = new PointerEvent(tp, {
            bubbles: true, cancelable: true, view: window,
            pointerId: 1, pointerType: 'mouse', isPrimary: true,
            button: 0, buttons: tp.indexOf('down') > -1 ? 1 : 0,
            clientX: cx, clientY: cy
          });
        } else {
          E = new MouseEvent(tp, {
            bubbles: true, cancelable: true, view: window,
            button: 0, buttons: tp.indexOf('down') > -1 ? 1 : 0,
            clientX: cx, clientY: cy
          });
        }
        alvo.dispatchEvent(E);
      } catch (e) {}
    };

    ['pointerover', 'mouseover', 'pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach(fire);
    try {
      if (typeof alvo.click === 'function') {
        alvo.click();
      } else {
        fire('click');
      }
    } catch (e) {}
  },

  inspectOnly: false,

  // LISTA EXPLÍCITA DE REJEIÇÃO PROIBITIVA (Item 6 & Item 7)
  isForbiddenEndLiveCandidate(element) {
    if (!element) return true;
    if (this.isInsideLiveInfinity(element)) return true;

    // Proibir qualquer controle de alternância (switch / checkbox)
    const role = (element.getAttribute('role') || '').toLowerCase();
    const type = (element.getAttribute('type') || '').toLowerCase();
    if (role === 'switch' || role === 'checkbox' || type === 'checkbox' || element.getAttribute('aria-checked') !== null || element.closest('[role="switch"]')) {
      return true;
    }

    // Proibir controles cujo texto ou contexto contenha Vídeo, Roteiro, Áudio, Câmera
    const contextText = (
      (element.textContent || '') + ' ' +
      (element.getAttribute('aria-label') || '') + ' ' +
      (element.getAttribute('title') || '') + ' ' +
      (element.parentElement ? element.parentElement.textContent || '' : '') + ' ' +
      (element.closest('div') ? element.closest('div').textContent || '' : '')
    ).toLowerCase();

    if (/(video|vídeo|roteiro|audio|áudio|câmera|camera|microfone|mic|qualidade|espelhar)/i.test(contextText)) {
      return true;
    }

    return false;
  },

  acharTimer() {
    const els = this.$s('div, span, p, b, strong');
    for (let i = 0; i < els.length; i++) {
      const e = els[i];
      if (e.children.length === 0) {
        const t = (e.textContent || '').trim();
        if (/^\d{1,2}:\d{2}:\d{2}$/.test(t) && this.vis(e) && this.fora(e)) {
          return e;
        }
      }
    }
    return null;
  },

  acharPower(tm) {
    if (!tm) return null;
    let el = tm;
    const tr = tm.getBoundingClientRect();
    for (let up = 0; up < 9 && el; up++) {
      el = el.parentElement;
      if (!el || this.isInsideLiveInfinity(el)) break;

      const cands = this.$s('button, [role="button"], svg, a', el).filter((b) => {
        if (!this.vis(b) || !this.fora(b)) return false;
        if (this.isForbiddenEndLiveCandidate(b)) return false;

        const txt = (b.textContent || '').trim();

        // No LiveGoPro original: o botão de encerramento NÃO possui texto textual (txt === '')
        if (txt !== '') return false;

        const r = b.getBoundingClientRect();
        // O botão de encerramento DEVE ficar estritamente à DIREITA do timer nativo (r.left > tr.right - 2)
        const isRightOfTimer = (r.left > tr.right - 2 && Math.abs((r.top + r.height / 2) - (tr.top + tr.height / 2)) < 30);
        if (!isRightOfTimer) return false;

        return b.tagName === 'BUTTON' || getComputedStyle(b).cursor === 'pointer';
      });

      if (cands.length) {
        cands.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
        return cands[0];
      }
    }
    return null;
  },

  findTikTokEndLiveButton() {
    const tm = this.acharTimer();
    return tm ? this.acharPower(tm) : null;
  },

  botaoConfirmar() {
    const bs = this.$s('button, [role="button"]').filter((b) => {
      if (this.isForbiddenEndLiveCandidate(b)) return false;
      const t = (b.textContent || '').trim();
      return this.vis(b) && this.fora(b) && /Encerrar|Confirmar|Sim|End/i.test(t) && !/Cancelar|Cancel|Voltar/i.test(t) && t.length < 40;
    });
    return bs.length ? bs[bs.length - 1] : null;
  },

  async tick() {
    if (this.confirmando) {
      const cf = this.botaoConfirmar();
      if (cf) {
        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Timer', `[EndLive-Ported] Confirmar encontrado (${cf.textContent.trim()})`);
        }
        this.clicar(cf);
        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Timer', '[EndLive-Ported] Confirmar clicado');
        }
      }

      if (!this.acharTimer()) {
        this.confirmando = false;
        this.fase = 'completed';
        this.completionHandled = true;
        this.endLiveInProgress = false;

        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Timer', '[EndLive-Ported] Modal fechado');
          LiveInfinityCore.log('Timer', '[EndLive-Ported] Live realmente encerrada');
        }

        if (window.LiveInfinityStateStore) {
          await LiveInfinityStateStore.setTimerState({
            desiredEnabled: false,
            status: 'COMPLETED',
            endsAt: null,
            pausedRemainingMs: null,
            completionHandled: true
          });
        }

        this.updateUI();

        if (window.LiveSessionStore) {
          if (window.LiveInfinityCore) {
            LiveInfinityCore.log('Timer', '[EndLive-Ported] Sessão reiniciada');
          }
          await LiveSessionStore.resetLiveSession('live_ended_by_timer');
        }
      }
      return;
    }

    if (this.status !== 'running') return;
    const faltaMs = this.deadline - Date.now();
    if (faltaMs <= 0) {
      await this.handleTimeout();
    } else {
      this.updateUI(faltaMs);
    }
  },

  async handleTimeout() {
    if (this.endLiveInProgress) return;
    this.endLiveInProgress = true;

    if (this.inspectOnly) {
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Timer', '[EndLive-InspectMode] MODO DIAGNÓSTICO ATIVO — AUDITANDO CANDIDATOS...');
      }
      const tmInspect = this.acharTimer();
      const pwInspect = tmInspect ? this.acharPower(tmInspect) : null;
      if (pwInspect) {
        pwInspect.style.border = '3px solid #FF0000';
        pwInspect.style.boxShadow = '0 0 12px #FF0000';
        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Timer', `[EndLive-InspectMode] ✅ Botão de energia localizado à direita do timer: Tag=${pwInspect.tagName}, Role=${pwInspect.getAttribute('role') || 'none'}, Forbidden=${this.isForbiddenEndLiveCandidate(pwInspect)}`);
        }
      } else {
        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Timer', '[EndLive-InspectMode] ❌ Nenhum botão válido localizado à direita do timer. Toggle Vídeo rejeitado com sucesso.');
        }
      }
      this.endLiveInProgress = false;
      return;
    }

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Timer', '[EndLive-Ported] Timer chegou a zero');
    }

    // VERIFICAR SE O MODAL JÁ ESTÁ ABERTO ANTES DE TENTAR CLICAR NO BOTÃO DE POWER
    const existingConfirm = this.botaoConfirmar();
    const modalExistente = !!existingConfirm;

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Timer', `[EndLive-Ported] Modal existente encontrado: ${modalExistente}`);
    }

    if (modalExistente) {
      this.confirmando = true;
      this.fase = 'confirming_end';
      this.updateUI();
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Timer', '[EndLive-Ported] Modal Finalizar LIVE encontrado');
        LiveInfinityCore.log('Timer', '[EndLive-Ported] Confirmar encontrado');
      }
      this.clicar(existingConfirm);
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Timer', '[EndLive-Ported] Confirmar clicado');
      }
      return;
    }

    // SE O MODAL NÃO ESTIVER ABERTO, ENCONTRAR O BOTÃO INICIAL
    const tm = this.acharTimer();
    if (!tm) {
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Timer', '[EndLive-Ported] Tempo esgotado — LIVE já estava fora do ar.');
      }
      this.cancel();
      return;
    }

    const pw = this.acharPower(tm);
    if (!pw) {
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Timer', '[EndLive-Ported] ⏰ Tempo esgotado, mas botão inicial não encontrado.');
      }
      return;
    }

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Timer', '[EndLive-Ported] Botão inicial encontrado');
    }

    this.clicar(pw);

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Timer', '[EndLive-Ported] Primeiro clique executado');
    }

    this.confirmando = true;
    this.fase = 'awaiting_confirmation';
    this.updateUI();

    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Timer', '⏰ Tempo esgotado — ENCERRANDO A LIVE!');
    }
  },

  updateUI(faltaMs = null) {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;

    const displayHms = shadow.getElementById('li-rt-restante');
    const endTimeEl = shadow.getElementById('li-rt-termino');
    const statusEl = shadow.getElementById('li-rt-status');
    const btnArm = shadow.getElementById('li-rt-armar');
    const btnPause = shadow.getElementById('li-rt-pausa');
    const btnCancel = shadow.getElementById('li-rt-cancel');
    const gaugeProgress = shadow.getElementById('li-gauge-progress');
    const pills = shadow.querySelectorAll('.li-preset-pill');
    const inputHMS = shadow.getElementById('li-rt-hms');

    const state = this.getState();

    switch (state.fase) {
      case 'contando': {
        const remaining = faltaMs !== null ? faltaMs : Math.max(0, this.deadline - Date.now());
        if (displayHms) displayHms.textContent = this.fmtHHMMSS(remaining);
        if (endTimeEl) endTimeEl.textContent = `Término previsto: ${new Date(this.deadline).toLocaleTimeString().slice(0, 5)}`;
        if (statusEl) statusEl.textContent = '⏱ Timer rodando — encerra automaticamente ao zerar.';

        if (btnArm) btnArm.style.display = 'none';
        if (btnPause) {
          btnPause.style.display = 'block';
          btnPause.textContent = '⏸ Pausar';
          btnPause.setAttribute('data-state', 'active');
        }
        if (btnCancel) btnCancel.style.display = 'block';

        pills.forEach((p) => {
          p.disabled = true;
          p.style.opacity = '0.5';
          p.style.cursor = 'not-allowed';
        });
        if (inputHMS) inputHMS.disabled = true;

        if (gaugeProgress && this.duracaoTotalMs > 0) {
          const ratio = Math.max(0, Math.min(1, remaining / this.duracaoTotalMs));
          const offset = 377 * (1 - ratio);
          gaugeProgress.style.strokeDashoffset = String(offset);
        }
        break;
      }

      case 'pausado': {
        if (displayHms) displayHms.textContent = this.fmtHHMMSS(this.resto);
        if (endTimeEl) endTimeEl.textContent = 'Timer pausado';
        if (statusEl) statusEl.textContent = '⏸ Timer pausado.';

        if (btnArm) btnArm.style.display = 'none';
        if (btnPause) {
          btnPause.style.display = 'block';
          btnPause.textContent = '▶ Retomar';
          btnPause.setAttribute('data-state', 'inactive');
        }
        if (btnCancel) btnCancel.style.display = 'block';

        pills.forEach((p) => {
          p.disabled = true;
          p.style.opacity = '0.5';
          p.style.cursor = 'not-allowed';
        });
        if (inputHMS) inputHMS.disabled = true;
        break;
      }

      case 'locating_end_button':
      case 'awaiting_confirmation':
      case 'confirming_end': {
        if (displayHms) displayHms.textContent = '00:00:00';
        if (endTimeEl) endTimeEl.textContent = 'Transmissão finalizando...';
        if (statusEl) statusEl.textContent = 'Encerrando a LIVE automaticamente...';

        if (btnArm) {
          btnArm.style.display = 'none';
          btnArm.disabled = true;
        }
        if (btnPause) btnPause.style.display = 'none';
        if (btnCancel) btnCancel.style.display = 'none';

        pills.forEach((p) => {
          p.disabled = true;
          p.style.opacity = '0.5';
          p.style.cursor = 'not-allowed';
        });
        if (inputHMS) inputHMS.disabled = true;

        if (gaugeProgress) gaugeProgress.style.strokeDashoffset = '377';
        break;
      }

      case 'completed': {
        if (displayHms) displayHms.textContent = '00:00:00';
        if (endTimeEl) endTimeEl.textContent = 'Transmissão finalizada';
        if (statusEl) statusEl.textContent = '✅ Transmissão encerrada automaticamente!';

        if (btnArm) {
          btnArm.style.display = 'block';
          btnArm.disabled = false;
          btnArm.textContent = '▶ Iniciar Novo Timer';
          btnArm.setAttribute('data-state', 'inactive');
        }
        if (btnPause) btnPause.style.display = 'none';
        if (btnCancel) btnCancel.style.display = 'none';

        pills.forEach((p) => {
          p.disabled = false;
          p.style.opacity = '1';
          p.style.cursor = 'pointer';
        });
        if (inputHMS) inputHMS.disabled = false;

        if (gaugeProgress) gaugeProgress.style.strokeDashoffset = '377';
        break;
      }

      case 'end_failed': {
        if (displayHms) displayHms.textContent = '00:00:00';
        if (endTimeEl) endTimeEl.textContent = 'Falha no encerramento';
        if (statusEl) statusEl.textContent = '🚨 Não foi possível encerrar a LIVE automaticamente. Encerrar manualmente no TikTok.';

        if (btnArm) {
          btnArm.style.display = 'block';
          btnArm.disabled = false;
          btnArm.textContent = '▶ Tentar Novamente';
          btnArm.setAttribute('data-state', 'inactive');
        }
        if (btnPause) btnPause.style.display = 'none';
        if (btnCancel) btnCancel.style.display = 'block';

        pills.forEach((p) => {
          p.disabled = false;
          p.style.opacity = '1';
          p.style.cursor = 'pointer';
        });
        if (inputHMS) inputHMS.disabled = false;

        if (gaugeProgress) gaugeProgress.style.strokeDashoffset = '377';
        break;
      }

      default: {
        // 'off'
        if (displayHms) displayHms.textContent = this.fmtHHMMSS(this.duracaoTotalMs);
        if (endTimeEl) endTimeEl.textContent = 'Término previsto: --:--';
        if (statusEl) statusEl.textContent = 'Timer desligado.';

        if (btnArm) {
          btnArm.style.display = 'block';
          btnArm.disabled = false;
          btnArm.textContent = '▶ Iniciar Timer';
          btnArm.setAttribute('data-state', 'inactive');
        }
        if (btnPause) btnPause.style.display = 'none';
        if (btnCancel) btnCancel.style.display = 'none';

        pills.forEach((p) => {
          p.disabled = false;
          p.style.opacity = '1';
          p.style.cursor = 'pointer';
        });
        if (inputHMS) inputHMS.disabled = false;

        if (gaugeProgress) gaugeProgress.style.strokeDashoffset = '0';
        break;
      }
    }
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityTimer = LiveInfinityTimer;
}
