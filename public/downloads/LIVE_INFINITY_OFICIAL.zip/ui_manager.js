'use strict';

/* ===== Live Infinity — UI Manager (Gerenciador do Status Operacional & Badge Reativo) ===== */
const LiveInfinityUI = {
  hostEl: null,
  shadowRoot: null,
  activeView: 'overview',
  editingProductId: null,
  isSavingProduct: false,
  eventLogs: [],
  lastOperationalStatus: null,
  hubMounted: false,

  navigationState: {
    currentSection: 'overview',
    productTab: 'automation'
  },

  initHostOnly() {
    if (document.getElementById('live-infinity-root-host')) {
      return this.shadowRoot;
    }

    // 1. Criar Host para Shadow DOM
    this.hostEl = document.createElement('div');
    this.hostEl.id = 'live-infinity-root-host';
    this.hostEl.style.cssText = 'position:fixed; top:0; left:0; width:100vw; height:100vh; pointer-events:none; z-index:2147483645;';
    document.body.appendChild(this.hostEl);

    // 2. Anexar Shadow Root
    this.shadowRoot = this.hostEl.attachShadow({ mode: 'open' });
    window.__liveInfinityShadow = this.shadowRoot;

    // 3. Injetar Estilos CSS Encapsulados
    const styleEl = document.createElement('style');
    styleEl.textContent = LIVE_INFINITY_STYLES;
    this.shadowRoot.appendChild(styleEl);

    return this.shadowRoot;
  },

  async mountFullHubUI() {
    this.initHostOnly();

    if (this.hubMounted) {
      const hub = this.shadowRoot.getElementById('li-hub');
      if (hub) hub.style.display = 'flex';
      this.renderLicenseInfo();
      this.updateOperationalStatus();
      return;
    }

    this.hubMounted = true;
    this.buildHubUI();
    this.buildMiniPanelUI();
    this.setupDragAndDrop();
    this.bindEvents();
    this.loadPersistedSettings();
    this.renderProductLibrary();
    this.renderLicenseInfo();

    if (window.LiveInfinitySalesAlert) {
      await LiveInfinitySalesAlert.init();
    }

    this.updateOperationalStatus();
  },

  destroyOrHideHubUI() {
    if (!this.shadowRoot) return;
    const hub = this.shadowRoot.getElementById('li-hub');
    const mini = this.shadowRoot.getElementById('li-mini-panel');
    if (hub) hub.style.display = 'none';
    if (mini) mini.style.display = 'none';
  },

  async init() {
    this.initHostOnly();
  },

  navigateToProducts(tab = 'automation') {
    this.switchView('products');
    this.switchProductTab(tab);
  },

  switchProductTab(tab = 'automation') {
    const shadow = this.shadowRoot;
    if (!shadow) return;

    const autoBtn = shadow.getElementById('li-ptab-automation');
    const libBtn = shadow.getElementById('li-ptab-library');
    const autoSec = shadow.getElementById('li-product-automation');
    const libSec = shadow.getElementById('li-product-library');

    if (tab === 'library') {
      if (autoBtn) {
        autoBtn.setAttribute('aria-selected', 'false');
        autoBtn.classList.remove('li-tab-active');
      }
      if (libBtn) {
        libBtn.setAttribute('aria-selected', 'true');
        libBtn.classList.add('li-tab-active');
      }
      if (autoSec) {
        autoSec.hidden = true;
        autoSec.style.display = 'none';
      }
      if (libSec) {
        libSec.hidden = false;
        libSec.style.display = 'block';
      }
      this.navigationState.productTab = 'library';
      this.renderProductLibrary();

      const title = shadow.getElementById('li-product-library-title');
      if (title) title.focus();
    } else {
      if (autoBtn) {
        autoBtn.setAttribute('aria-selected', 'true');
        autoBtn.classList.add('li-tab-active');
      }
      if (libBtn) {
        libBtn.setAttribute('aria-selected', 'false');
        libBtn.classList.remove('li-tab-active');
      }
      if (autoSec) {
        autoSec.hidden = false;
        autoSec.style.display = 'block';
      }
      if (libSec) {
        libSec.hidden = true;
        libSec.style.display = 'none';
      }
      this.navigationState.productTab = 'automation';
    }
  },

  buildHubUI() {
    const hub = document.createElement('div');
    hub.id = 'li-hub';
    hub.innerHTML = `
      <!-- HEADER FIXO DA CENTRAL DE COMANDO -->
      <div id="li-header" class="li-header">
        <div class="li-brand" style="display:flex; align-items:center; gap:8px;">
          <img class="header-brand-symbol" src="${typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL ? chrome.runtime.getURL('assets/brand/original/live-infinity-symbol-exact-transparent.png') : 'assets/brand/original/live-infinity-symbol-exact-transparent.png'}" alt="Live Infinity" style="height:24px; width:auto; object-fit:contain;" />
          <span class="li-brand-title" style="font-size:15px; font-weight:900; letter-spacing:0.5px;"><span style="color:#FF2438">LIVE</span> <span style="color:#F3A519">INFINITY</span></span>
        </div>
        <div style="flex:1"></div>
        <div id="li-status-badge" class="li-status-indicator li-status-inactive" title="Nenhuma automação está em execução.">● INATIVO</div>
        <button type="button" id="li-btn-cfg" class="li-icon-btn" title="Configurações">⚙️</button>
        <button type="button" id="li-btn-min" class="li-icon-btn" title="Minimizar">−</button>
      </div>

      <!-- LAYOUT PRINCIPAL: SIDEBAR (6 ITENS OFICIAIS) + WORKSPACE -->
      <div class="li-body-layout">
        <!-- SIDEBAR DE NAVEGAÇÃO LATERAL -->
        <div class="li-sidebar">
          <button type="button" id="li-nav-overview" class="li-nav-item li-active" title="Visão geral">🏠</button>
          <button type="button" id="li-nav-products" class="li-nav-item" title="Produtos">📌</button>
          <button type="button" id="li-nav-chat" class="li-nav-item" title="Conversas">💬</button>
          <button type="button" id="li-nav-sales" class="li-nav-item" title="Vendas">🎉</button>
          <button type="button" id="li-nav-security" class="li-nav-item" title="Segurança">🛡️</button>
          <button type="button" id="li-nav-settings" class="li-nav-item" title="Configurações">⚙️</button>
        </div>

        <!-- WORKSPACE DE VIEWS DINÂMICAS -->
        <div class="li-workspace">
          
          <!-- VIEW 1: VISÃO GERAL -->
          <div id="li-view-overview" class="li-view li-view-active">
            <div class="li-view-title">Visão geral</div>
            <div class="li-view-sub">Métricas em tempo real, automações e timer de encerramento programado.</div>
            
            <div class="li-card" style="background: linear-gradient(135deg, #191513 0%, #12100F 100%); border-color:#D4AF37">
              <div class="li-card-head">
                <span style="font-size:10px; color:#C8BCA5; letter-spacing:0.8px; text-transform:uppercase">FATURAMENTO (GMV)</span>
                <span style="color:#D4AF37; font-size:10px; font-weight:800">● AO VIVO</span>
              </div>
              <div id="li-dash-gmv" style="font-size:26px; font-weight:800; color:#F4D675; text-shadow:0 0 10px rgba(244,214,117,0.3)">—</div>
            </div>

            <div style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap:8px">
              <div class="li-card" style="padding:8px">
                <div style="font-size:9px; color:#C8BCA5; font-weight:700">VENDAS</div>
                <div id="li-dash-vendas" style="font-size:16px; font-weight:800; color:#FFF8E7; margin-top:2px">0</div>
              </div>
              <div class="li-card" style="padding:8px">
                <div style="font-size:9px; color:#C8BCA5; font-weight:700">TICKET MÉDIO</div>
                <div id="li-dash-ticket" style="font-size:16px; font-weight:800; color:#D4AF37; margin-top:2px">—</div>
              </div>
              <div class="li-card" style="padding:8px">
                <div style="font-size:9px; color:#C8BCA5; font-weight:700">ITENS</div>
                <div id="li-dash-itens" style="font-size:16px; font-weight:800; color:#FFF8E7; margin-top:2px">0</div>
              </div>
            </div>

            <div class="li-card" style="display:flex; align-items:center; justify-content:space-between">
              <div>
                <div style="font-weight:700; color:#FFF8E7">Automações Ativas</div>
                <div id="li-active-count-text" style="font-size:11px; color:#C8BCA5">Nenhuma automação rodando</div>
              </div>
              <div id="li-active-ring" style="width:36px; height:36px; border-radius:50%; border:3px solid #780B10; display:flex; align-items:center; justify-content:center; font-weight:800; color:#FF2834">0</div>
            </div>

            <button type="button" id="li-btn-op-iniciar" class="li-btn-go li-operation-button" style="font-size:13px; min-height:42px">🚀 INICIAR OPERAÇÃO</button>
            <button type="button" id="li-btn-op-encerrar" class="li-btn-go li-btn-stop" style="display:none">■ Encerrar automações</button>

            <!-- CARD TIMER DE ENCERRAMENTO -->
            <div class="li-card" style="border-color: rgba(212, 175, 55, 0.3)">
              <div class="li-card-head">
                <span>⏱ Timer de encerramento</span>
                <span style="font-size:10px; color:#C8BCA5">Encerramento automático</span>
              </div>

              <div class="li-gauge-semicircle-container" style="margin-bottom:10px">
                <svg class="li-gauge-svg" viewBox="0 0 320 180" aria-hidden="true">
                  <defs>
                    <linearGradient id="li_gauge_gold_grad" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stop-color="#FF2834"/>
                      <stop offset="50%" stop-color="#F4D675"/>
                      <stop offset="100%" stop-color="#D4AF37"/>
                    </linearGradient>
                  </defs>
                  <path class="li-gauge-track" d="M 40 150 A 120 120 0 0 1 280 150" />
                  <path id="li-gauge-progress" class="li-gauge-progress" d="M 40 150 A 120 120 0 0 1 280 150" />
                  <circle cx="40" cy="150" r="3" fill="#D4AF37" />
                  <circle cx="75" cy="65" r="3" fill="#D4AF37" />
                  <circle cx="160" cy="30" r="3" fill="#D4AF37" />
                  <circle cx="245" cy="65" r="3" fill="#D4AF37" />
                  <circle cx="280" cy="150" r="3" fill="#D4AF37" />
                </svg>
                <div class="li-gauge-center-text">
                  <div id="li-rt-restante" class="li-timer-display-hms">02:00:00</div>
                  <div id="li-rt-termino" class="li-timer-end-time">Término previsto: --:--</div>
                </div>
              </div>

              <div class="li-preset-bar" id="li-preset-bar">
                <button type="button" class="li-preset-pill" data-timer-preset-minutes="60" data-min="60">1h</button>
                <button type="button" class="li-preset-pill li-active is-selected" data-timer-preset-minutes="120" data-min="120">2h</button>
                <button type="button" class="li-preset-pill" data-timer-preset-minutes="240" data-min="240">4h</button>
                <button type="button" class="li-preset-pill" data-timer-preset-minutes="360" data-min="360">6h</button>
                <button type="button" class="li-preset-pill" data-timer-preset-minutes="480" data-min="480">8h</button>
              </div>

              <label class="li-label">Entrada manual — minutos ou HH:MM:SS</label>
              <input id="li-rt-hms" type="text" class="li-input" value="02:00:00" placeholder="Ex.: 36 ou 01:30:00" style="font-family:'Fira Code',monospace; font-size:14px; font-weight:700; text-align:center" spellcheck="false" autocomplete="off" />
              <div style="font-size:9px; color:#C8BCA5; margin-top:2px; text-align:center">Digite somente o número de minutos ou use Horas:Minutos:Segundos.</div>
              <div id="li-rt-error" style="display:none; color:#FF2834; font-size:10px; margin-top:4px; text-align:center"></div>

              <button type="button" id="li-rt-armar" class="li-btn-go li-operation-button" data-state="inactive" aria-pressed="false" style="margin-top:12px; font-size:13px">▶ Iniciar Timer</button>
              
              <div style="display:flex; gap:6px; margin-top:6px">
                <button type="button" id="li-rt-pausa" class="li-btn-go li-operation-button" data-state="inactive" aria-pressed="false" style="display:none">⏸ Pausar</button>
                <button type="button" id="li-rt-cancel" class="li-btn-go li-btn-stop" style="display:none">✕ Cancelar</button>
              </div>

              <div id="li-rt-status" class="li-status-text" style="margin-top:8px">Timer desligado.</div>
            </div>

            <div class="li-card">
              <div class="li-card-head">Atividades recentes</div>
              <div id="li-timeline-feed" class="li-timeline">
                <div class="li-timeline-item">
                  <div class="li-timeline-icon">ℹ️</div>
                  <div>Sistema pronto. Nenhuma live detectada ainda.</div>
                </div>
              </div>
            </div>
          </div>

          <!-- VIEW 2: PRODUTOS -->
          <div id="li-view-products" class="li-view">
            <div class="li-view-title">Produtos</div>
            <div class="li-view-sub">Gerencie a refixação, a oferta relâmpago e sua biblioteca de produtos.</div>

            <div class="li-tab-bar" role="tablist" aria-label="Áreas de produtos">
              <button type="button" role="tab" id="li-ptab-automation" data-product-tab="automation" aria-selected="true" aria-controls="li-product-automation" class="li-tab-btn li-tab-active">Automação</button>
              <button type="button" role="tab" id="li-ptab-library" data-product-tab="library" aria-selected="false" aria-controls="li-product-library" class="li-tab-btn">Biblioteca</button>
            </div>

            <section id="li-product-automation" role="tabpanel" aria-labelledby="li-ptab-automation">
              <div class="li-card" style="margin-bottom:10px">
                <div class="li-card-head">📌 Refixação do Produto Nº 1</div>
                <div class="li-desc">Mantém o produto nº 1 em destaque constante na LIVE e desafixa cupons.</div>
                <label class="li-label">Intervalo de Refixação (segundos):</label>
                <input id="li-rf-intervalo" type="number" class="li-input" min="10" value="40" />
                <button type="button" id="li-rf-botao" class="li-btn-go li-operation-button" data-state="inactive" aria-pressed="false" style="margin-top:10px">▶ Iniciar Refixação</button>
                <div id="li-rf-status" class="li-status-text">Desligado.</div>
              </div>

              <div class="li-card">
                <div class="li-card-head">⚡ Oferta Relâmpago</div>
                <div class="li-desc">Duplica e relança automaticamente a Oferta Relâmpago quando o tempo esgotar.</div>
                <button type="button" id="li-rd-botao" class="li-btn-go li-operation-button" data-state="inactive" aria-pressed="false">▶ Iniciar Oferta Relâmpago</button>
                <div id="li-rd-status" class="li-status-text">Desligado.</div>
              </div>
            </section>

            <section id="li-product-library" role="tabpanel" aria-labelledby="li-ptab-library" hidden style="display:none">
              <div class="li-card">
                <div class="li-card-head">
                  <span id="li-product-library-title" tabindex="-1">📦 Biblioteca de Produtos</span>
                  <button type="button" id="li-btn-new-product" data-action="new-product" class="li-btn-go li-btn-secondary" style="width:auto; padding:4px 10px; min-height:28px">+ Novo produto</button>
                </div>
                <div class="li-desc">Cadastre perfis de mensagens para seus produtos. Somente um produto fica ATIVO por vez para alimentar os Comentários Automáticos.</div>

                <div id="li-products-list" style="margin-top:10px"></div>
              </div>
            </section>
          </div>

          <!-- VIEW 3: CONVERSAS -->
          <div id="li-view-chat" class="li-view">
            <div class="li-view-title">Conversas</div>
            <div class="li-view-sub">Configure e ative cada automação de chat de forma totalmente independente.</div>

            <div class="li-card" style="background: linear-gradient(90deg, #191513 0%, #211A16 100%); border-color: #D4AF37; display:flex; align-items:center; justify-content:space-between">
              <div>
                <span style="font-size:10px; color:#C8BCA5; font-weight:700; text-transform:uppercase">PRODUTO ATIVO NA BIBLIOTECA:</span>
                <div id="li-chat-active-prod-name" style="font-size:13px; font-weight:800; color:#F4D675">Ferro de Passar</div>
              </div>
              <button type="button" id="li-btn-switch-product-library" data-action="change-active-product" class="li-btn-go li-btn-secondary" style="width:auto; padding:4px 10px; min-height:28px">Trocar produto</button>
            </div>

            <button type="button" id="li-btn-open-preview" class="li-btn-go li-btn-secondary" style="margin-bottom:4px">👁️ Ver prévia do chat</button>

            <div class="li-card">
              <div class="li-card-head">
                <span>💬 Comentários automáticos</span>
                <label class="li-switch" title="Ativar Comentários">
                  <input id="li-box-toggle-comments" type="checkbox" />
                  <span class="li-slider"></span>
                </label>
              </div>
              <div class="li-desc">Envia comentários programados em rotação do produto ativo na Biblioteca de Produtos.</div>
              <label class="li-label">Intervalo de envio (segundos):</label>
              <input id="li-rc-int" type="number" class="li-input" min="10" value="90" />
              <div id="li-rc-status" class="li-status-text">Desligado.</div>
            </div>

            <div class="li-card">
              <div class="li-card-head">
                <span>🤖 Respostas por palavra-chave</span>
                <label class="li-switch" title="Ativar Respostas">
                  <input id="li-box-toggle-replies" type="checkbox" />
                  <span class="li-slider"></span>
                </label>
              </div>
              <div class="li-desc">Responde automaticamente quando o cliente envia uma das palavras cadastradas.</div>
              <label class="li-label">REGRAS — UMA POR LINHA:</label>
              <textarea id="li-ra-regras" class="li-textarea conversation-textarea" style="height:90px" placeholder="frete = 🚚 O valor do frete aparece ao finalizar o pedido.&#10;tamanho = 📏 Clique em Comprar para conferir os tamanhos disponíveis.&#10;cupom = 🎟️ Confira os cupons disponíveis antes de finalizar a compra."></textarea>
              <div style="display:flex; justify-content:space-between; align-items:center; margin-top:8px">
                <label class="li-switch-label" style="margin:0">
                  <input id="li-ra-mencao" type="checkbox" checked />
                  Mencionar @usuario
                </label>
                <button type="button" id="li-ra-save-btn" class="li-btn-go li-btn-secondary" style="width:auto; padding:4px 10px; min-height:28px">Salvar</button>
              </div>
              <div id="li-ra-status" class="li-status-text">Desligado.</div>
            </div>

            <div class="li-card">
              <div class="li-card-head">
                <span>🛒 Resposta para quem adicionou ao carrinho</span>
                <label class="li-switch" title="Ativar Intenção">
                  <input id="li-box-toggle-intent" type="checkbox" />
                  <span class="li-slider"></span>
                </label>
              </div>
              <div class="li-desc">Menciona automaticamente a pessoa que adicionou o produto ao carrinho.</div>
              <label class="li-label">MENSAGEM PARA QUEM ADICIONOU AO CARRINHO:</label>
              <input id="li-ic-cart" class="li-input conversation-input" placeholder="Vi que você colocou o item no carrinho, finalize seu pedido antes que o estoque acabe! 🛒" />
              <div style="display:flex; justify-content:space-between; align-items:center; margin-top:8px">
                <span style="font-size:10px; color:#C8BCA5">Inclui @usuário automaticamente</span>
                <button type="button" id="li-ic-save-btn" class="li-btn-go li-btn-secondary" style="width:auto; padding:4px 10px; min-height:28px">Salvar</button>
              </div>
              <div id="li-ic-status" class="li-status-text">Desligado.</div>
            </div>

            <div class="li-card">
              <div class="li-card-head">
                <span>🎉 Parabenizar compradores</span>
                <label class="li-switch" title="Ativar Agradecimentos">
                  <input id="li-box-toggle-thanks" type="checkbox" />
                  <span class="li-slider"></span>
                </label>
              </div>
              <div class="li-desc">Menciona automaticamente o comprador quando a venda é confirmada.</div>
              <label class="li-label">MENSAGEM PARA O COMPRADOR:</label>
              <input id="li-vc-msg" class="li-input conversation-input" placeholder="🎉 Parabéns pela sua compra! Volte aqui para dar o seu feedback quando o produto chegar!" />
              <div style="display:flex; justify-content:space-between; align-items:center; margin-top:8px">
                <span style="font-size:10px; color:#C8BCA5">Inclui @comprador automaticamente</span>
                <button type="button" id="li-vc-save-btn" class="li-btn-go li-btn-secondary" style="width:auto; padding:4px 10px; min-height:28px">Salvar</button>
              </div>
              <div id="li-vc-status" class="li-status-text">Desligado.</div>
            </div>
          </div>

          <!-- VIEW 4: VENDAS -->
          <div id="li-view-sales" class="li-view">
            <div class="li-view-title">Vendas</div>
            <div class="li-view-sub">Canais de notificação e alertas de vendas em tempo real.</div>

            <!-- CANAL 1: CHAT -->
            <div class="li-card">
              <div class="li-card-head">
                <span>💬 Canal 1: Mensagem no Chat</span>
                <span class="li-status-indicator li-status-active">● ATIVO</span>
              </div>
              <div class="li-desc">Envia mensagem parabenizando o comprador assim que a venda é identificada.</div>
            </div>

            <!-- CANAL 2: SOM PC -->
            <div class="li-card">
              <div class="li-card-head">
                <span>🔊 Canal 2: Som no Computador</span>
                <span class="li-status-indicator li-status-active">● ATIVO</span>
              </div>
              <div style="display:flex; justify-content:space-between; align-items:center">
                <label class="li-switch-label" style="margin:0">
                  <span class="li-switch">
                    <input id="li-nv-som" type="checkbox" checked />
                    <span class="li-slider"></span>
                  </span>
                  Tocar som de caixa registradora ao vender
                </label>
                <button type="button" id="li-nv-btn-test-sound" class="li-btn-go li-btn-secondary" style="width:auto; padding:4px 10px; min-height:28px" title="Testar som de caixa registradora">🔊 TESTAR SOM</button>
              </div>
            </div>

            <!-- CANAL 3: NOTIFICAÇÃO NO CELULAR (NTFY.SH COM INPUT TOTALMENTE EDITÁVEL) -->
            <div class="li-card">
              <div class="li-card-head">
                <span>🔔 Canal 3: Notificação no Celular (ntfy.sh)</span>
                <span id="li-ntfy-badge" class="li-status-indicator li-status-inactive">NÃO CONFIGURADO</span>
              </div>
              
              <div class="li-desc" style="margin-bottom:8px">
                No aplicativo ntfy (Android/iOS), inscreva-se neste mesmo canal para receber os alertas de vendas.
              </div>

              <label class="li-label">Canal do ntfy:</label>
              <div style="display:flex; gap:6px; margin-bottom:6px">
                <input id="li-nv-canal" type="text" class="li-input" placeholder="Ex.: live-infinity-vendas-x7k9p2" autocomplete="off" spellcheck="false" />
                <button type="button" id="li-btn-gen-ntfy-channel" class="li-btn-go li-btn-secondary" style="width:auto; padding:0 10px; font-size:10px; white-space:nowrap" title="Gerar canal aleatório seguro">⚡ Gerar canal seguro</button>
              </div>

              <div id="li-nv-draft-notice" style="display:none; color:#F4D675; font-size:11px; font-weight:700; margin-bottom:6px">⚠️ Alterações não salvas no campo acima.</div>

              <div style="display:flex; justify-content:space-between; align-items:center; margin-top:8px">
                <label class="li-switch-label" style="margin:0">
                  <span class="li-switch">
                    <input id="li-nv-celular-toggle" type="checkbox" />
                    <span class="li-slider"></span>
                  </span>
                  Ativar notificações no celular
                </label>

                <div style="display:flex; gap:6px">
                  <button type="button" id="li-btn-save-ntfy-channel" class="li-btn-go li-btn-secondary" style="width:auto; padding:4px 10px; min-height:28px">Salvar canal</button>
                  <button type="button" id="li-nv-teste" class="li-btn-go" style="width:auto; padding:4px 12px; min-height:28px">Enviar teste para o celular</button>
                </div>
              </div>

              <!-- CARD DO CANAL SALVO -->
              <div id="li-nv-saved-box" style="display:none; margin-top:12px; padding:10px; background:#12100F; border:1px solid #D4AF37; border-radius:6px">
                <div style="font-size:10px; color:#C8BCA5; font-weight:700; text-transform:uppercase">CANAL SALVO:</div>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:4px">
                  <span id="li-nv-saved-topic" style="font-family:'Fira Code',monospace; font-size:13px; font-weight:800; color:#F4D675">live-infinity-diagnostico-7x9k4m2p</span>
                  <div style="display:flex; gap:6px">
                    <button type="button" id="li-btn-copy-ntfy" class="li-btn-go li-btn-secondary" style="width:auto; padding:2px 8px; font-size:10px; min-height:24px">📋 Copiar</button>
                    <button type="button" id="li-btn-change-ntfy" class="li-btn-go li-btn-secondary" style="width:auto; padding:2px 8px; font-size:10px; min-height:24px">✏️ Trocar canal</button>
                  </div>
                </div>
                <div style="font-size:10px; color:#C8BCA5; margin-top:4px">Este é o canal que deve ser adicionado no aplicativo ntfy no celular.</div>
                <div id="li-nv-last-test-time" style="font-size:10px; color:#D4AF37; margin-top:2px"></div>
              </div>

              <div id="li-nv-status" class="li-status-text" style="margin-top:8px">Informe ou gere um canal para receber alertas no celular.</div>
            </div>
          </div>

          <!-- VIEW 5: SEGURANÇA -->
          <div id="li-view-security" class="li-view">
            <div class="li-view-title">Segurança</div>
            <div class="li-view-sub">Níveis de proteção e bloqueio automatizado.</div>

            <!-- CARD DE ESTADO AUTOMÁTICO DA PROTEÇÃO DE EMERGÊNCIA (OBRIGATÓRIA) -->
            <div class="li-card" style="border-color:#D4AF37; background: linear-gradient(135deg, #191513 0%, #12100F 100%)">
              <div class="li-card-head">
                <span>🛡️ Proteção de Emergência (Obrigatória)</span>
                <span id="li-rv-badge" class="li-status-indicator li-status-active" data-state="active">● PROTEÇÃO ATIVA</span>
              </div>
              <div id="li-rv-state-desc" style="font-size:12px; font-weight:800; color:#F4D675; margin-bottom:4px">ARMADA — monitorando violações automaticamente</div>
              <div class="li-desc">Monitoramento automatizado contra violações de diretrizes do TikTok Shop. Permanece ativa durante toda a transmissão.</div>
              
              <label class="li-label">Delay antes de encerrar (segundos, 0-120):</label>
              <input id="li-rv-delay" type="number" class="li-input" min="0" max="120" value="0" style="font-weight:700" />

              <div id="li-rv-countdown-box" style="display:none; margin-top:10px; padding:8px; background:#211A16; border:1px solid #FF2834; border-radius:8px; text-align:center">
                <div id="li-rv-countdown-text" style="font-size:13px; font-weight:800; color:#FF2834">🚨 Violação confirmada — Encerramento em 10s</div>
                <button type="button" id="li-btn-cancel-rv" class="li-btn-go li-btn-secondary" style="margin-top:6px; font-size:11px">Cancelar encerramento desta live</button>
              </div>

              <div id="li-rv-status" class="li-status-text" style="margin-top:8px">Proteção de Emergência armada e monitorando a LIVE.</div>
            </div>

            <div class="li-card">
              <div class="li-card-head">🚫 Nível 2: Bloqueio por Nome Suspeito</div>
              <label class="li-label">Palavras Suspeitas (uma por linha):</label>
              <textarea id="li-bn-palavras" class="li-textarea">recomenda\nachadinhos\nindica</textarea>
              <button type="button" id="li-bn-botao" class="li-btn-go li-operation-button" data-state="inactive" aria-pressed="false" style="margin-top:8px">▶ Iniciar Bloqueio</button>
              <div id="li-bn-status" class="li-status-text">Desligado.</div>
            </div>
          </div>

          <!-- VIEW 6: CONFIGURAÇÕES -->
          <div id="li-view-settings" class="li-view">
            <div class="li-view-title">Configurações</div>
            <div class="li-view-sub">Gerenciamento da licença por chave e diagnóstico do sistema.</div>

            <div class="li-card">
              <div class="li-card-head">🔑 Status da Licença</div>
              <div style="line-height:1.8; font-size:12px">
                <div>Status: <b id="li-lic-status-label" style="color:#F4D675">● Licença válida</b></div>
                <div>E-mail: <b id="li-lic-email" style="color:#FFF8E7">cliente@gmail.com</b></div>
                <div>Plano: <b id="li-lic-plan" style="color:#FFF8E7">Mensal — 30 dias</b></div>
                <div>Chave: <b id="li-lic-key" style="color:#F4D675">LIVEINF-****-59AF4</b></div>
                <div>Dias restantes: <b id="li-lic-days-remaining" style="color:#F4D675; font-weight:800">30 dias</b></div>
                <div>Vencimento: <b id="li-lic-expires-at" style="color:#FFF8E7">30/08/2026 às 23:59</b></div>
                <div>Pagamento: <b id="li-lic-payment-status" style="color:#4ADE80">Em dia</b></div>
                <div style="font-size:10px; color:#C8BCA5; margin-top:4px">Última verificação automática: <span id="li-lic-last-checked">hoje às 14:30</span></div>
              </div>

              <div id="li-lic-warning-banner" style="display:none; margin-top:10px; padding:8px; background:#211A16; border:1px solid #F4D675; border-radius:6px; color:#F4D675; font-size:11px; font-weight:700; text-align:center">
                ⚠️ Sua assinatura vence em breve. Renove para não perder o acesso!
              </div>

              <div style="display:flex; gap:6px; margin-top:12px">
                <button type="button" id="li-btn-change-key" class="li-btn-go li-btn-secondary" style="width:100%">🔑 Trocar Chave</button>
              </div>

              <div style="margin-top:10px; display:flex; flex-direction:column; gap:6px; text-align:center; font-size:10px">
                <a href="https://liveinfinitysite.vercel.app/" target="_blank" rel="noopener noreferrer" class="li-gate-link" data-action="renew-subscription">
                  💳 Renovar assinatura no site oficial
                </a>
                <a href="https://api.valoranegocios.com.br/ativar-liveinfinity" target="_blank" rel="noopener noreferrer" class="li-gate-link" data-action="recover-key">
                  🔑 Esqueceu sua chave? Clique aqui para recuperar
                </a>
              </div>
            </div>

            <div class="li-card">
              <div class="li-card-head">📜 Log de Eventos Técnicos</div>
              <div id="li-log-box" class="li-log-box"></div>
            </div>
          </div>

        </div>
      </div>

      <!-- MODAL EDITOR DE PRODUTO DENTRO DO #li-hub -->
      <div id="li-overlay-product-editor" class="li-overlay-root">
        <div class="li-backdrop"></div>
        <div class="li-operation-modal" role="dialog" aria-modal="true">
          <div id="li-ped-title" style="font-size:16px; font-weight:800; color:#F4D675; text-align:center; margin-bottom:12px">Editar Produto</div>
          
          <label class="li-label">Nome do Produto:</label>
          <input id="li-ped-name" class="li-input" placeholder="ex: Ferro de Passar" />

          <label class="li-label">Comentários do Produto (um por linha):</label>
          <textarea id="li-ped-comments" class="li-textarea" style="height:120px" placeholder="Digite os comentários específicos deste produto..."></textarea>
          
          <div id="li-ped-error" style="display:none; color:#FF2834; font-size:11px; margin-top:6px; text-align:center"></div>
          <div id="li-ped-status" style="display:none; color:#F4D675; font-size:11px; margin-top:6px; text-align:center"></div>

          <div style="display:flex; gap:8px; margin-top:14px">
            <button type="button" id="li-btn-cancel-product" class="li-btn-go li-btn-secondary">Cancelar</button>
            <button type="button" id="li-btn-save-product" class="li-btn-go">Salvar produto</button>
          </div>
        </div>
      </div>

      <!-- OVERLAY MANAGER FIXO DENTRO DO #li-hub -->
      <div id="li-overlay-review" class="li-overlay-root">
        <div class="li-backdrop"></div>
        <div class="li-operation-modal" role="dialog" aria-modal="true">
          <div style="font-size:16px; font-weight:800; color:#F4D675; text-align:center; margin-bottom:4px">Revisão da Operação</div>
          <div style="font-size:11px; color:#C8BCA5; text-align:center; margin-bottom:14px">Confirme as automações configuradas antes de iniciar a transmissão.</div>
          
          <div id="li-review-checklist">
            <div class="li-review-item"><input type="checkbox" checked /> 📌 Refixação Produto Nº 1 (Intervalo 40s)</div>
            <div class="li-review-item"><input type="checkbox" checked /> ⚡ Oferta Relâmpago Automática</div>
            <div class="li-review-item"><input type="checkbox" checked /> 💬 Comentários Automáticos (Produto Ativo)</div>
            <div class="li-review-item"><input type="checkbox" checked /> 🤖 Respostas Automáticas por Palavra-Chave</div>
            <div class="li-review-item"><input type="checkbox" checked /> 🛡️ Proteção Contra Violação (Obrigatória Automática)</div>
          </div>

          <button type="button" id="li-btn-confirm-operation" class="li-btn-go" style="margin-top:14px; font-size:13px">Confirmar e iniciar</button>
          <button type="button" id="li-btn-cancel-review" class="li-btn-go li-btn-secondary" style="margin-top:6px">Voltar e ajustar</button>
        </div>
      </div>

      <!-- DRAWER DA PRÉVIA DO CHAT FIXO DENTRO DO #li-hub -->
      <div id="li-overlay-preview" class="li-overlay-root">
        <div class="li-backdrop"></div>
        <section class="li-chat-preview-drawer">
          <div style="display:flex; justify-content:space-between; align-items:center">
            <span style="font-size:13px; font-weight:700; color:#F4D675">Prévia do Chat</span>
            <button type="button" id="li-btn-close-preview" class="li-icon-btn">✖</button>
          </div>
          <div class="li-chat-bubble-preview">
            <b style="color:#F4D675">Live Infinity [Oficial]:</b>
            <div id="li-preview-text" style="margin-top:4px">Oi! Sejam bem-vindos à LIVE! 🛒 Frete grátis liberado para todo o Brasil!</div>
          </div>
          <div style="font-size:10px; color:#C8BCA5; margin-top:12px; text-align:right">Fila: Próximo envio em 4.5s</div>
        </section>
      </div>

      <!-- BARRA DE STATUS PERSISTENTE (RODAPÉ) -->
      <div id="li-status-bar" class="li-status-bar">
        <div id="li-bar-live-status">● AGUARDANDO LIVE</div>
        <div id="li-bar-active-count">0 Ativas</div>
        <div id="li-bar-next-action">Próx: --</div>
        <div style="color:#F4D675">Licença: Válida 🟢</div>
      </div>
    `;

    this.shadowRoot.appendChild(hub);
  },

  buildMiniPanelUI() {
    const mini = document.createElement('div');
    mini.id = 'li-mini-panel';
    mini.setAttribute('role', 'region');
    mini.setAttribute('aria-label', 'Mini Painel Live Infinity');
    mini.setAttribute('tabindex', '0');
    mini.title = 'Clique para restaurar ou arraste para reposicionar';
    
    mini.innerHTML = `
      <div class="li-mini-header">
        <div class="minimized-brand li-mini-brand">
          <img class="minimized-brand-symbol" src="${typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL ? chrome.runtime.getURL('assets/brand/original/live-infinity-symbol-exact-transparent.png') : 'assets/brand/original/live-infinity-symbol-exact-transparent.png'}" alt="Live Infinity" style="width:30px; height:24px; object-fit:contain; flex:0 0 auto;" />
          <span class="minimized-brand-name"><span style="color:#FF2438">LIVE</span> <span style="color:#F3A519">INFINITY</span></span>
        </div>
        <div class="li-mini-controls">
          <span id="li-mini-live-status" class="li-status-indicator li-status-inactive minimized-status">AGUARDANDO</span>
          <button type="button" id="li-mini-restore-btn" class="li-icon-btn" style="width:20px; height:20px; font-size:11px; flex:0 0 auto;" title="Expandir Live Infinity">⤢</button>
        </div>
      </div>
      <div class="li-mini-body minimized-metrics">
        <div class="li-mini-metric">
          <span class="li-mini-metric-label">GMV</span>
          <span id="li-mini-gmv" class="li-mini-metric-value" style="font-size:12px; font-weight:800; color:#F4D675;">R$ 0,00</span>
        </div>
        <div style="width:1px; height:22px; background:rgba(212,175,55,0.2)"></div>
        <div class="li-mini-metric" style="text-align:right">
          <span class="li-mini-metric-label">VENDAS</span>
          <span id="li-mini-vendas" class="li-mini-metric-value li-val-white" style="font-size:12px; font-weight:800; color:#FFF8E7;">0</span>
        </div>
      </div>
    `;
    this.shadowRoot.appendChild(mini);
  },

  renderLicenseInfo() {
    const shadow = this.shadowRoot;
    if (!shadow) return;

    const lic = window.LiveInfinityLicense ? LiveInfinityLicense.currentLicense : null;
    const isValid = window.LiveInfinityLicense ? LiveInfinityLicense.isValid : false;

    const stLabel = shadow.getElementById('li-lic-status-label');
    const emailEl = shadow.getElementById('li-lic-email');
    const planEl = shadow.getElementById('li-lic-plan');
    const keyEl = shadow.getElementById('li-lic-key');
    const daysEl = shadow.getElementById('li-lic-days-remaining');
    const expEl = shadow.getElementById('li-lic-expires-at');
    const payEl = shadow.getElementById('li-lic-payment-status');
    const checkEl = shadow.getElementById('li-lic-last-checked');
    const warnBanner = shadow.getElementById('li-lic-warning-banner');

    if (!lic || !isValid) {
      if (stLabel) { stLabel.textContent = '● ASSINATURA VENCIDA / BLOQUEADA'; stLabel.style.color = '#FF2834'; }
      if (emailEl) emailEl.textContent = 'Não ativado';
      if (planEl) planEl.textContent = 'Desativado';
      if (keyEl) keyEl.textContent = 'Nenhuma chave ativa';
      if (daysEl) { daysEl.textContent = '0 dias'; daysEl.style.color = '#FF2834'; }
      if (expEl) expEl.textContent = 'Expirada';
      if (payEl) { payEl.textContent = 'Pendente'; payEl.style.color = '#FF2834'; }
      if (checkEl) checkEl.textContent = new Date().toLocaleTimeString().slice(0, 5);
      if (warnBanner) warnBanner.style.display = 'none';
      return;
    }

    const email = lic.email || 'cliente@gmail.com';
    const maskedKey = lic.masked_key || (window.LiveInfinityLicense ? LiveInfinityLicense.maskKey(lic.key) : 'LIVEINF-****-59AF4');
    const plan = lic.plan || 'Mensal — 30 dias';
    const days = typeof lic.days_remaining === 'number' ? Math.max(0, lic.days_remaining) : 30;
    const expiresFormatted = window.LiveInfinityLicense ? LiveInfinityLicense.formatDateBR(lic.expires_at) : '--/--/---- às --:--';
    const paymentStatus = lic.payment_status || 'Em dia';
    const lastChecked = lic.last_checked || new Date().toLocaleTimeString().slice(0, 5);

    if (stLabel) { stLabel.textContent = '● Licença válida'; stLabel.style.color = '#F4D675'; }
    if (emailEl) emailEl.textContent = email;
    if (planEl) planEl.textContent = plan;
    if (keyEl) keyEl.textContent = maskedKey;
    if (daysEl) {
      daysEl.textContent = `${days} ${days === 1 ? 'dia' : 'dias'}`;
      daysEl.style.color = days <= 7 ? '#FF2834' : '#F4D675';
    }
    if (expEl) expEl.textContent = expiresFormatted;
    if (payEl) {
      payEl.textContent = paymentStatus;
      payEl.style.color = paymentStatus === 'Em dia' || paymentStatus === 'paid' ? '#4ADE80' : '#FF2834';
    }
    if (checkEl) checkEl.textContent = lastChecked;

    if (warnBanner) {
      warnBanner.style.display = (days >= 1 && days <= 7) ? 'block' : 'none';
    }
  },

  /* ===== MOTOR REATIVO DE DERIVAÇÃO DE STATUS OPERACIONAL & ATUALIZAÇÃO VISUAL DE BOTÕES ===== */
  deriveOperationalStatus() {
    let runningCount = 0;
    let restoringCount = 0;
    let waitingCount = 0;
    let errorCount = 0;

    const isLicenseValid = window.LiveInfinityLicense && typeof LiveInfinityLicense.isCurrentValid === 'function' ? LiveInfinityLicense.isCurrentValid() : true;
    if (!isLicenseValid) {
      return {
        status: 'BLOCKED',
        label: '● BLOQUEADO',
        tooltip: 'Assinatura pendente ou bloqueada. Ative sua chave de acesso.',
        cssClass: 'li-status-blocked',
        runningCount: 0,
        waitingCount: 0,
        errorCount: 0
      };
    }

    const stateStore = window.LiveInfinityStateStore ? LiveInfinityStateStore.state : null;
    const autos = stateStore ? stateStore.automations : {};

    const automationsList = [
      { key: 'productPin', module: window.LiveInfinityProductPin },
      { key: 'flashDeal', module: window.LiveInfinityFlashDeal },
      { key: 'autoComments', module: window.LiveInfinityChat, check: () => window.LiveInfinityChat && LiveInfinityChat.commentActive },
      { key: 'autoReplies', module: window.LiveInfinityChat, check: () => window.LiveInfinityChat && LiveInfinityChat.replyActive },
      { key: 'buyerIntent', module: window.LiveInfinityBuyerIntent },
      { key: 'purchaseThanks', module: window.LiveInfinityPurchaseThanks },
      { key: 'nameBlock', module: window.LiveInfinityNameBlock },
      { key: 'mobileNotification', module: window.LiveInfinitySalesAlert }
    ];

    automationsList.forEach(item => {
      const isRunning = item.check ? item.check() : (item.module && item.module.active);
      const desired = autos && autos[item.key] ? autos[item.key].desiredEnabled : false;
      const runtime = autos && autos[item.key] ? autos[item.key].runtimeStatus : 'STOPPED';

      if (isRunning) {
        runningCount++;
      } else if (runtime === 'RESTORING' || runtime === 'STARTING') {
        restoringCount++;
      } else if (desired && (runtime === 'WAITING_FOR_LIVE' || runtime === 'WAITING_FOR_PAGE')) {
        waitingCount++;
      } else if (runtime === 'ERROR') {
        errorCount++;
      }
    });

    const timerRunning = window.LiveInfinityTimer && LiveInfinityTimer.fase === 'contando';
    if (timerRunning) {
      runningCount++;
    }

    if (runningCount > 0) {
      return {
        status: 'ACTIVE',
        label: '● ATIVO',
        tooltip: `Live Infinity operando com ${runningCount} automação(ões) em execução.`,
        cssClass: 'li-status-active',
        runningCount,
        waitingCount,
        errorCount
      };
    }

    if (restoringCount > 0) {
      return {
        status: 'STARTING',
        label: '● INICIANDO',
        tooltip: 'Inicializando automações operacionais...',
        cssClass: 'li-status-starting',
        runningCount: 0,
        waitingCount,
        errorCount
      };
    }

    if (waitingCount > 0) {
      return {
        status: 'WAITING_FOR_LIVE',
        label: '● AGUARDANDO',
        tooltip: 'Automações ativadas, aguardando a live.',
        cssClass: 'li-status-waiting',
        runningCount: 0,
        waitingCount,
        errorCount
      };
    }

    if (errorCount > 0) {
      return {
        status: 'ERROR',
        label: '● ERRO',
        tooltip: `${errorCount} módulo(s) em falha técnica.`,
        cssClass: 'li-status-error',
        runningCount: 0,
        waitingCount: 0,
        errorCount
      };
    }

    return {
      status: 'INACTIVE',
      label: '● INATIVO',
      tooltip: 'Nenhuma automação está em execução.',
      cssClass: 'li-status-inactive',
      runningCount: 0,
      waitingCount: 0,
      errorCount: 0
    };
  },

  updateOperationalStatus(activeCountFromCore = null) {
    const shadow = this.shadowRoot;
    if (!shadow) return;

    const snapshot = this.deriveOperationalStatus();

    const badge = shadow.getElementById('li-status-badge');
    const ring = shadow.getElementById('li-active-ring');
    const text = shadow.getElementById('li-active-count-text');
    const barCount = shadow.getElementById('li-bar-active-count');
    const btnOpIniciar = shadow.getElementById('li-btn-op-iniciar');
    const btnOpEncerrar = shadow.getElementById('li-btn-op-encerrar');

    if (badge) {
      badge.textContent = snapshot.label;
      badge.title = snapshot.tooltip;
      badge.className = `li-status-indicator ${snapshot.cssClass}`;
    }

    const effectiveRunning = activeCountFromCore !== null ? activeCountFromCore : snapshot.runningCount;
    if (ring) ring.textContent = String(effectiveRunning);
    if (barCount) barCount.textContent = effectiveRunning > 0 ? `${effectiveRunning} Ativas` : (snapshot.waitingCount > 0 ? `${snapshot.waitingCount} Aguardando` : '0 Ativas');

    if (text) {
      if (effectiveRunning > 0) {
        text.textContent = `${effectiveRunning} automação(ões) em execução`;
      } else if (snapshot.waitingCount > 0) {
        text.textContent = `${snapshot.waitingCount} automação(ões) aguardando live`;
      } else if (snapshot.status === 'STARTING') {
        text.textContent = 'Inicializando automações...';
      } else if (snapshot.status === 'BLOCKED') {
        text.textContent = 'Bloqueado por licenciamento';
      } else {
        text.textContent = 'Nenhuma automação rodando';
      }
    }

    if (btnOpIniciar) {
      if (snapshot.status === 'STARTING') {
        btnOpIniciar.textContent = '⏳ INICIANDO...';
        btnOpIniciar.disabled = true;
        btnOpIniciar.setAttribute('data-state', 'starting');
        btnOpIniciar.classList.add('is-starting');
      } else if (effectiveRunning > 0 || snapshot.waitingCount > 0) {
        btnOpIniciar.textContent = `⚙ GERENCIAR OPERAÇÃO — ${effectiveRunning} ATIVAS`;
        btnOpIniciar.disabled = false;
        btnOpIniciar.setAttribute('data-state', 'active');
        btnOpIniciar.classList.add('is-active');
        if (btnOpEncerrar) btnOpEncerrar.style.display = 'block';
      } else {
        btnOpIniciar.textContent = '🚀 INICIAR OPERAÇÃO';
        btnOpIniciar.disabled = false;
        btnOpIniciar.setAttribute('data-state', 'inactive');
        btnOpIniciar.classList.remove('is-active', 'is-starting');
        if (btnOpEncerrar) btnOpEncerrar.style.display = 'none';
      }
    }

    // ===== REATUALIZAÇÃO DE ESTADO VISUAL DOS BOTÕES OPERACIONAIS =====
    const btnRf = shadow.getElementById('li-rf-botao');
    const isRfActive = window.LiveInfinityProductPin && LiveInfinityProductPin.active;
    if (btnRf) {
      if (isRfActive) {
        btnRf.setAttribute('data-state', 'active');
        btnRf.setAttribute('aria-pressed', 'true');
        btnRf.classList.add('is-active');
        btnRf.textContent = '● Refixação ativa — ■ Parar';
      } else {
        btnRf.setAttribute('data-state', 'inactive');
        btnRf.setAttribute('aria-pressed', 'false');
        btnRf.classList.remove('is-active');
        btnRf.textContent = '▶ Iniciar Refixação';
      }
    }

    const btnRd = shadow.getElementById('li-rd-botao');
    const isRdActive = window.LiveInfinityFlashDeal && LiveInfinityFlashDeal.active;
    if (btnRd) {
      if (isRdActive) {
        btnRd.setAttribute('data-state', 'active');
        btnRd.setAttribute('aria-pressed', 'true');
        btnRd.classList.add('is-active');
        btnRd.textContent = '● Oferta Relâmpago ativa — ■ Parar';
      } else {
        btnRd.setAttribute('data-state', 'inactive');
        btnRd.setAttribute('aria-pressed', 'false');
        btnRd.classList.remove('is-active');
        btnRd.textContent = '▶ Iniciar Oferta Relâmpago';
      }
    }

    const btnBn = shadow.getElementById('li-bn-botao');
    const isBnActive = window.LiveInfinityNameBlock && LiveInfinityNameBlock.active;
    if (btnBn) {
      if (isBnActive) {
        btnBn.setAttribute('data-state', 'active');
        btnBn.setAttribute('aria-pressed', 'true');
        btnBn.classList.add('is-active');
        btnBn.textContent = '● Bloqueio de Nomes ativo — ■ Parar';
      } else {
        btnBn.setAttribute('data-state', 'inactive');
        btnBn.setAttribute('aria-pressed', 'false');
        btnBn.classList.remove('is-active');
        btnBn.textContent = '▶ Iniciar Bloqueio';
      }
    }

    if (window.LiveInfinityTimer && typeof LiveInfinityTimer.updateUI === 'function') {
      LiveInfinityTimer.updateUI();
    }

    const badgeRv = shadow.getElementById('li-rv-badge');
    if (badgeRv) {
      badgeRv.setAttribute('data-state', 'active');
      badgeRv.classList.add('li-status-active');
      badgeRv.textContent = '● PROTEÇÃO ATIVA';
    }

    if (this.lastOperationalStatus !== snapshot.status) {
      const prev = this.lastOperationalStatus || 'INICIAL';
      this.lastOperationalStatus = snapshot.status;
      if (prev !== 'INICIAL') {
        this.log('Status', `Status operacional: ${prev} → ${snapshot.status} (${effectiveRunning} automações em execução)`);
      }
    }

    this.syncConversationToggles();
  },

  updateActiveCount(count) {
    this.updateOperationalStatus(count);
  },

  restoreFullHub() {
    const shadow = this.shadowRoot;
    if (!shadow) return;
    const hub = shadow.getElementById('li-hub');
    const mini = shadow.getElementById('li-mini-panel');
    if (hub) hub.style.display = 'flex';
    if (mini) mini.style.display = 'none';
  },

  minimizeToMiniPanel() {
    const shadow = this.shadowRoot;
    if (!shadow) return;
    const hub = shadow.getElementById('li-hub');
    const mini = shadow.getElementById('li-mini-panel');
    if (hub) hub.style.display = 'none';
    if (mini) mini.style.display = 'flex';
    if (window.LiveInfinityDashboard) {
      window.LiveInfinityDashboard.update();
    }
  },

  renderProductLibrary() {
    const shadow = this.shadowRoot;
    if (!shadow) return;
    const container = shadow.getElementById('li-products-list');
    if (!container) return;

    if (!window.LiveInfinityProductLibrary) {
      container.innerHTML = `<div style="color:#C8BCA5">Carregando produtos...</div>`;
      return;
    }

    const prods = LiveInfinityProductLibrary.products;
    const activeId = LiveInfinityProductLibrary.activeProductId;

    const activeProd = LiveInfinityProductLibrary.getActiveProduct();
    const chatBannerName = shadow.getElementById('li-chat-active-prod-name');
    if (chatBannerName) {
      chatBannerName.textContent = activeProd ? activeProd.name : 'Nenhum produto ativo';
    }

    if (!prods.length) {
      container.innerHTML = `
        <div style="text-align:center; padding:20px; color:#C8BCA5">
          <div style="font-size:13px; font-weight:700; color:#F4D675; margin-bottom:4px">Nenhum produto cadastrado.</div>
          <div>Crie seu primeiro produto para adicionar comentários personalizados.</div>
          <button type="button" class="li-btn-go li-btn-secondary li-btn-create-first" style="margin:12px auto 0 auto; width:auto; padding:6px 14px">+ Novo produto</button>
        </div>
      `;
      const btnFirst = container.querySelector('.li-btn-create-first');
      if (btnFirst) btnFirst.addEventListener('click', () => this.openProductEditor(null));
      return;
    }

    container.innerHTML = prods.map((p) => {
      const isActive = p.id === activeId;
      const commentsCount = p.comments ? p.comments.length : 0;
      return `
        <div class="li-product-card ${isActive ? 'li-active' : ''}">
          <div class="li-product-card-head">
            <span class="li-product-card-title">${this.escapeHtml(p.name)}</span>
            <span class="li-status-indicator ${isActive ? 'li-status-active' : 'li-status-inactive'}">
              ${isActive ? '● ATIVO' : '○ INATIVO'}
            </span>
          </div>
          <div style="font-size:11px; color:#C8BCA5">${commentsCount} comentário(s) cadastrado(s)</div>
          
          <div class="li-product-actions">
            ${!isActive ? `<button type="button" class="li-btn-go li-btn-activate-prod" data-id="${p.id}" style="width:auto; padding:4px 10px; min-height:28px">Ativar produto</button>` : `<button type="button" class="li-btn-go is-active" data-state="active" disabled style="width:auto; padding:4px 10px; min-height:28px; cursor:default">● Produto Ativo</button>`}
            <button type="button" class="li-btn-go li-btn-secondary li-btn-edit-prod" data-id="${p.id}" style="width:auto; padding:4px 10px; min-height:28px">Editar</button>
            <button type="button" class="li-btn-go li-btn-secondary li-btn-dup-prod" data-id="${p.id}" style="width:auto; padding:4px 10px; min-height:28px">Duplicar</button>
            <button type="button" class="li-btn-go li-btn-stop li-btn-del-prod" data-id="${p.id}" style="width:auto; padding:4px 10px; min-height:28px">Excluir</button>
          </div>
        </div>
      `;
    }).join('');

    container.querySelectorAll('.li-btn-activate-prod').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        e.preventDefault(); e.stopPropagation();
        const id = btn.getAttribute('data-id');
        await LiveInfinityProductLibrary.setActiveProduct(id);
        this.renderProductLibrary();
      });
    });

    container.querySelectorAll('.li-btn-edit-prod').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        const id = btn.getAttribute('data-id');
        this.openProductEditor(id);
      });
    });

    container.querySelectorAll('.li-btn-dup-prod').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        e.preventDefault(); e.stopPropagation();
        const id = btn.getAttribute('data-id');
        await LiveInfinityProductLibrary.duplicateProduct(id);
        this.renderProductLibrary();
      });
    });

    container.querySelectorAll('.li-btn-del-prod').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        e.preventDefault(); e.stopPropagation();
        const id = btn.getAttribute('data-id');
        const prod = LiveInfinityProductLibrary.products.find(p => p.id === id);
        if (prod && confirm(`Deseja realmente excluir o produto "${prod.name}" e seus comentários?`)) {
          await LiveInfinityProductLibrary.deleteProduct(id);
          this.renderProductLibrary();
        }
      });
    });
  },

  openProductEditor(productId = null) {
    const shadow = this.shadowRoot;
    if (!shadow) return;

    this.editingProductId = productId;
    const overlay = shadow.getElementById('li-overlay-product-editor');
    const title = shadow.getElementById('li-ped-title');
    const inputName = shadow.getElementById('li-ped-name');
    const areaComments = shadow.getElementById('li-ped-comments');
    const errBox = shadow.getElementById('li-ped-error');
    const stBox = shadow.getElementById('li-ped-status');

    if (errBox) errBox.style.display = 'none';
    if (stBox) stBox.style.display = 'none';

    if (productId) {
      const prod = LiveInfinityProductLibrary.products.find(p => p.id === productId);
      if (prod) {
        if (title) title.textContent = `Editar Produto: ${prod.name}`;
        if (inputName) inputName.value = prod.name;
        if (areaComments) areaComments.value = (prod.comments || []).join('\n');
      }
    } else {
      if (title) title.textContent = 'Novo Produto';
      if (inputName) inputName.value = '';
      if (areaComments) areaComments.value = '';
    }

    if (overlay) overlay.classList.add('is-open');
  },

  closeProductEditor() {
    const shadow = this.shadowRoot;
    if (!shadow) return;
    const overlay = shadow.getElementById('li-overlay-product-editor');
    if (overlay) overlay.classList.remove('is-open');
    this.editingProductId = null;
  },

  escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  },

  setupDragAndDrop() {
    const hub = this.shadowRoot.getElementById('li-hub');
    const header = this.shadowRoot.getElementById('li-header');
    const miniPanel = this.shadowRoot.getElementById('li-mini-panel');
    if (!hub || !header || !miniPanel) return;

    const makeHubDraggable = (el, handle, storageKey) => {
      let isDown = false;
      let startX, startY, origX, origY;

      handle.addEventListener('mousedown', (e) => {
        isDown = true;
        startX = e.clientX;
        startY = e.clientY;
        const rect = el.getBoundingClientRect();
        origX = rect.left;
        origY = rect.top;
        e.preventDefault();
      });

      document.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        const newLeft = Math.max(0, Math.min(window.innerWidth - 60, origX + dx));
        const newTop = Math.max(0, Math.min(window.innerHeight - 60, origY + dy));
        el.style.left = `${newLeft}px`;
        el.style.top = `${newTop}px`;
        el.style.right = 'auto';
      });

      document.addEventListener('mouseup', () => {
        if (!isDown) return;
        isDown = false;
        try {
          const rect = el.getBoundingClientRect();
          localStorage.setItem(storageKey, JSON.stringify({ t: Math.round(rect.top), l: Math.round(rect.left) }));
        } catch (err) {}
      });
    };

    let isMiniDown = false;
    let miniStartX = 0, miniStartY = 0, miniOrigX = 0, miniOrigY = 0, maxMiniDelta = 0;

    miniPanel.addEventListener('pointerdown', (e) => {
      if (e.target.closest('#li-mini-restore-btn')) return;
      isMiniDown = true;
      maxMiniDelta = 0;
      miniStartX = e.clientX;
      miniStartY = e.clientY;
      const rect = miniPanel.getBoundingClientRect();
      miniOrigX = rect.left;
      miniOrigY = rect.top;
      try {
        miniPanel.setPointerCapture(e.pointerId);
      } catch (err) {}
      miniPanel.classList.add('is-dragging');
    });

    miniPanel.addEventListener('pointermove', (e) => {
      if (!isMiniDown) return;
      const dx = e.clientX - miniStartX;
      const dy = e.clientY - miniStartY;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist > maxMiniDelta) maxMiniDelta = dist;

      const newLeft = Math.max(10, Math.min(window.innerWidth - 280, miniOrigX + dx));
      const newTop = Math.max(10, Math.min(window.innerHeight - 90, miniOrigY + dy));
      miniPanel.style.left = `${newLeft}px`;
      miniPanel.style.top = `${newTop}px`;
      miniPanel.style.right = 'auto';
    });

    miniPanel.addEventListener('pointerup', (e) => {
      if (!isMiniDown) return;
      isMiniDown = false;
      miniPanel.classList.remove('is-dragging');
      try {
        miniPanel.releasePointerCapture(e.pointerId);
      } catch (err) {}

      const rect = miniPanel.getBoundingClientRect();
      try {
        localStorage.setItem(LIVE_INFINITY_CONFIG.STORAGE_KEYS.BUBBLE_POS, JSON.stringify({ t: Math.round(rect.top), l: Math.round(rect.left) }));
      } catch (err) {}

      if (maxMiniDelta < 5) {
        this.restoreFullHub();
      }
    });

    miniPanel.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        this.restoreFullHub();
      }
    });

    makeHubDraggable(hub, header, LIVE_INFINITY_CONFIG.STORAGE_KEYS.HUB_POS);
  },

  switchView(viewName) {
    if (viewName === 'agenda') viewName = 'overview';

    const shadow = this.shadowRoot;
    if (!shadow) return;

    const navIds = ['overview', 'products', 'chat', 'sales', 'security', 'settings'];
    navIds.forEach((id) => {
      const btn = shadow.getElementById(`li-nav-${id}`);
      const view = shadow.getElementById(`li-view-${id}`);
      if (btn) btn.classList.toggle('li-active', id === viewName);
      if (view) view.classList.toggle('li-view-active', id === viewName);
    });

    this.activeView = viewName;
    this.navigationState.currentSection = viewName;

    if (viewName === 'settings') {
      this.renderLicenseInfo();
    }
  },

  bindEvents() {
    const shadow = this.shadowRoot;
    if (!shadow) return;

    const openOverlay = (el) => { if (el) el.classList.add('is-open'); };
    const closeOverlay = (el) => { if (el) el.classList.remove('is-open'); };

    let isRenewing = false;

    // Delegação de eventos global no Shadow DOM
    shadow.addEventListener('click', (e) => {
      const path = e.composedPath ? e.composedPath() : [];
      for (const node of path) {
        if (node instanceof HTMLElement) {
          const action = node.dataset ? node.dataset.action : null;

          if (action === 'renew-subscription') {
            e.preventDefault();
            e.stopPropagation();
            if (isRenewing) return;
            isRenewing = true;
            if (window.LiveInfinityLicense) {
              LiveInfinityLicense.openRenewalPage();
            } else {
              window.open(LIVE_INFINITY_CONFIG.RENEWAL_URL, '_blank', 'noopener,noreferrer');
            }
            setTimeout(() => { isRenewing = false; }, 1000);
            return;
          }

          if (action === 'recover-key') {
            e.preventDefault();
            e.stopPropagation();
            if (window.LiveInfinityLicense) {
              LiveInfinityLicense.openRecoveryPage();
            } else {
              window.open(LIVE_INFINITY_CONFIG.RECOVERY_URL, '_blank', 'noopener,noreferrer');
            }
            return;
          }

          const presetMins = node.dataset ? (node.dataset.timerPresetMinutes || node.dataset.min) : null;
          if (presetMins && node.classList.contains('li-preset-pill')) {
            e.preventDefault();
            e.stopPropagation();
            if (window.LiveInfinityTimer) {
              LiveInfinityTimer.applyPreset(Number(presetMins));
            }
            return;
          }

          const prodTab = node.dataset ? node.dataset.productTab : null;

          if (prodTab) {
            e.preventDefault();
            e.stopPropagation();
            this.navigateToProducts(prodTab);
            return;
          }

          if (action === 'change-active-product' || action === 'open-product-library') {
            e.preventDefault();
            e.stopPropagation();
            this.navigateToProducts('library');
            return;
          }

          if (action === 'new-product') {
            e.preventDefault();
            e.stopPropagation();
            this.openProductEditor(null);
            return;
          }
        }
      }
    });

    ['overview', 'products', 'chat', 'sales', 'security', 'settings'].forEach((id) => {
      const btn = shadow.getElementById(`li-nav-${id}`);
      if (btn) btn.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        this.switchView(id);
      });
    });

    const btnChangeKey = shadow.getElementById('li-btn-change-key');

    if (btnChangeKey) {
      btnChangeKey.addEventListener('click', async (e) => {
        e.preventDefault(); e.stopPropagation();
        if (window.LiveInfinityLicense) {
          LiveInfinityLicense.renderLicenseGate('');
        }
      });
    }

    const ptabAuto = shadow.getElementById('li-ptab-automation');
    const ptabLib = shadow.getElementById('li-ptab-library');

    if (ptabAuto) {
      ptabAuto.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        this.switchProductTab('automation');
      });
    }

    if (ptabLib) {
      ptabLib.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        this.switchProductTab('library');
      });
    }

    const btnSwitchProduct = shadow.getElementById('li-btn-switch-product-library');
    if (btnSwitchProduct) {
      btnSwitchProduct.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        this.navigateToProducts('library');
      });
    }

    const btnNewProduct = shadow.getElementById('li-btn-new-product');
    if (btnNewProduct) {
      btnNewProduct.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        this.openProductEditor(null);
      });
    }

    const btnCancelProduct = shadow.getElementById('li-btn-cancel-product');
    const btnSaveProduct = shadow.getElementById('li-btn-save-product');

    if (btnCancelProduct) {
      btnCancelProduct.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        this.closeProductEditor();
      });
    }

    if (btnSaveProduct) {
      btnSaveProduct.addEventListener('click', async (e) => {
        e.preventDefault(); e.stopPropagation();
        const inputName = shadow.getElementById('li-ped-name');
        const areaComments = shadow.getElementById('li-ped-comments');
        const errBox = shadow.getElementById('li-ped-error');
        const stBox = shadow.getElementById('li-ped-status');

        const name = (inputName ? inputName.value : '').trim();
        const comments = (areaComments ? areaComments.value : '').split('\n').filter(t => t.trim());

        if (!name) {
          if (errBox) { errBox.textContent = 'Por favor, informe o nome do produto.'; errBox.style.display = 'block'; }
          return;
        }

        btnSaveProduct.disabled = true;
        btnSaveProduct.textContent = 'Salvando produto...';

        try {
          if (this.editingProductId) {
            await LiveInfinityProductLibrary.updateProduct(this.editingProductId, { name, comments });
          } else {
            await LiveInfinityProductLibrary.createProduct({ name, comments });
          }

          if (stBox) { stBox.textContent = 'Produto salvo com sucesso!'; stBox.style.display = 'block'; }
          await new Promise(r => setTimeout(r, 600));

          this.closeProductEditor();
          this.renderProductLibrary();
        } catch (err) {
          console.error('[Live Infinity] Erro ao salvar produto:', err);
          if (errBox) { errBox.textContent = 'Não foi possível salvar o produto. Tente novamente.'; errBox.style.display = 'block'; }
        } finally {
          btnSaveProduct.disabled = false;
          btnSaveProduct.textContent = 'Salvar produto';
        }
      });
    }

    const btnMin = shadow.getElementById('li-btn-min');
    const btnCfg = shadow.getElementById('li-btn-cfg');
    const btnMiniRestore = shadow.getElementById('li-mini-restore-btn');

    if (btnMin) btnMin.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); this.minimizeToMiniPanel(); });
    if (btnMiniRestore) btnMiniRestore.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); this.restoreFullHub(); });
    if (btnCfg) btnCfg.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); this.switchView('settings'); });

    const btnOpIniciar = shadow.getElementById('li-btn-op-iniciar');
    const btnOpEncerrar = shadow.getElementById('li-btn-op-encerrar');
    const overlayReview = shadow.getElementById('li-overlay-review');
    const btnConfirmOp = shadow.getElementById('li-btn-confirm-operation');
    const btnCancelReview = shadow.getElementById('li-btn-cancel-review');

    if (btnOpIniciar) {
      btnOpIniciar.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        const snap = this.deriveOperationalStatus();
        if (snap.status === 'ACTIVE' || snap.status === 'WAITING_FOR_LIVE') {
          this.switchView('chat');
          this.log('Operação', 'Navegando para o gerenciamento das automações ativas.');
        } else {
          openOverlay(overlayReview);
        }
      });
    }

    if (btnCancelReview) {
      btnCancelReview.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        closeOverlay(overlayReview);
      });
    }

    if (btnConfirmOp) {
      btnConfirmOp.addEventListener('click', async (e) => {
        e.preventDefault(); e.stopPropagation();
        closeOverlay(overlayReview);

        if (window.LiveInfinityStateStore) {
          await LiveInfinityStateStore.setRuntimeStatus('productPin', 'RESTORING');
        }
        this.updateOperationalStatus();

        const automationsToStart = [
          { id: 'li-rf-botao', action: () => LiveInfinityProductPin.start() },
          { id: 'li-rd-botao', action: () => LiveInfinityFlashDeal.start() },
          { id: 'li-box-toggle-comments', action: () => LiveInfinityChat.startComments() },
          { id: 'li-box-toggle-replies', action: () => LiveInfinityChat.startReplies() },
          { id: 'li-box-toggle-intent', action: () => LiveInfinityBuyerIntent.start() },
          { id: 'li-box-toggle-thanks', action: () => LiveInfinityPurchaseThanks.start() },
          { id: 'li-bn-botao', action: () => LiveInfinityNameBlock.start() }
        ];

        for (const item of automationsToStart) {
          const el = shadow.getElementById(item.id);
          if (el) {
            if (el.tagName === 'INPUT' && !el.checked) {
              await item.action();
            } else if (el.tagName === 'BUTTON' && el.textContent.indexOf('▶') === 0) {
              await item.action();
            }
          }
        }

        this.updateOperationalStatus();
        this.log('Operação', 'Operação confirmada e automações inicializadas! 🚀');
      });
    }

    if (btnOpEncerrar) {
      btnOpEncerrar.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        if (confirm('Deseja realmente encerrar todas as automações operacionais?')) {
          if (window.LiveInfinityCore) {
            LiveInfinityCore.stopAllAutomations();
          }
          this.updateOperationalStatus();
          this.log('Operação', 'Todas as automações foram encerradas pelo usuário.');
        }
      });
    }

    const toggleComments = shadow.getElementById('li-box-toggle-comments');
    const toggleReplies = shadow.getElementById('li-box-toggle-replies');
    const toggleIntent = shadow.getElementById('li-box-toggle-intent');
    const toggleThanks = shadow.getElementById('li-box-toggle-thanks');

    if (toggleComments) {
      toggleComments.addEventListener('change', async () => {
        if (window.LiveInfinityChat) {
          if (toggleComments.checked) await LiveInfinityChat.startComments();
          else await LiveInfinityChat.stopComments();
          this.updateOperationalStatus();
        }
      });
    }

    if (toggleReplies) {
      toggleReplies.addEventListener('change', async () => {
        if (window.LiveInfinityChat) {
          if (toggleReplies.checked) await LiveInfinityChat.startReplies();
          else await LiveInfinityChat.stopReplies();
          this.updateOperationalStatus();
        }
      });
    }

    if (toggleIntent) {
      toggleIntent.addEventListener('change', async () => {
        if (window.LiveInfinityBuyerIntent) {
          if (toggleIntent.checked) await LiveInfinityBuyerIntent.start();
          else await LiveInfinityBuyerIntent.stop();
          this.updateOperationalStatus();
        }
      });
    }

    if (toggleThanks) {
      toggleThanks.addEventListener('change', async () => {
        if (window.LiveInfinityPurchaseThanks) {
          if (toggleThanks.checked) await LiveInfinityPurchaseThanks.start();
          else await LiveInfinityPurchaseThanks.stop();
          this.updateOperationalStatus();
        }
      });
    }

    const btnArmarTimer = shadow.getElementById('li-rt-armar');
    const btnPausaTimer = shadow.getElementById('li-rt-pausa');
    const btnCancelTimer = shadow.getElementById('li-rt-cancel');

    if (btnArmarTimer) btnArmarTimer.addEventListener('click', async (e) => { e.preventDefault(); e.stopPropagation(); await LiveInfinityTimer.arm(); this.updateOperationalStatus(); });
    if (btnPausaTimer) btnPausaTimer.addEventListener('click', async (e) => { e.preventDefault(); e.stopPropagation(); await LiveInfinityTimer.pauseResume(); this.updateOperationalStatus(); });
    if (btnCancelTimer) btnCancelTimer.addEventListener('click', async (e) => { e.preventDefault(); e.stopPropagation(); await LiveInfinityTimer.cancel(); this.updateOperationalStatus(); });

    const inputHMS = shadow.getElementById('li-rt-hms');
    if (inputHMS) {
      inputHMS.addEventListener('input', () => {
        if (window.LiveInfinityTimer) {
          LiveInfinityTimer.onInputChange(inputHMS.value);
        }
      });

      inputHMS.addEventListener('blur', () => {
        if (window.LiveInfinityTimer) {
          LiveInfinityTimer.onInputBlur(inputHMS.value);
        }
      });

      inputHMS.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter') {
          ev.preventDefault();
          if (window.LiveInfinityTimer) {
            LiveInfinityTimer.onInputBlur(inputHMS.value);
          }
        }
      });
    }

    const btnRf = shadow.getElementById('li-rf-botao');
    const btnRd = shadow.getElementById('li-rd-botao');
    const btnBn = shadow.getElementById('li-bn-botao');

    if (btnRf) btnRf.addEventListener('click', async (e) => { e.preventDefault(); e.stopPropagation(); await LiveInfinityProductPin.toggle(); this.updateOperationalStatus(); });
    if (btnRd) btnRd.addEventListener('click', async (e) => { e.preventDefault(); e.stopPropagation(); await LiveInfinityFlashDeal.toggle(); this.updateOperationalStatus(); });
    if (btnBn) btnBn.addEventListener('click', async (e) => { e.preventDefault(); e.stopPropagation(); await LiveInfinityNameBlock.toggle(); this.updateOperationalStatus(); });

    // ===== LISTENERS DE ALERTAS DE VENDAS (SOM DE CAIXA REGISTRADORA E NTFY.SH) =====
    const btnTestSound = shadow.getElementById('li-nv-btn-test-sound');
    if (btnTestSound) {
      btnTestSound.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        if (window.LiveInfinitySalesAlert) {
          LiveInfinitySalesAlert.playCashRegisterSound();
          this.log('Vendas', 'Teste de som de caixa registradora acionado pelo usuário. 🔊');
        }
      });
    }

    const toggleSound = shadow.getElementById('li-nv-som');
    if (toggleSound) {
      toggleSound.addEventListener('change', async () => {
        if (window.LiveInfinitySalesAlert) {
          await LiveInfinitySalesAlert.toggleSound(toggleSound.checked);
          this.log('Vendas', `Som no computador: ${toggleSound.checked ? 'ATIVADO' : 'DESATIVADO'}`);
        }
      });
    }

    const btnSaveNtfy = shadow.getElementById('li-btn-save-ntfy-channel');
    if (btnSaveNtfy) {
      btnSaveNtfy.addEventListener('click', async (e) => {
        e.preventDefault(); e.stopPropagation();
        if (window.LiveInfinitySalesAlert) {
          btnSaveNtfy.disabled = true;
          btnSaveNtfy.textContent = 'Salvando...';
          const ok = await LiveInfinitySalesAlert.saveSettings();
          btnSaveNtfy.disabled = false;
          btnSaveNtfy.textContent = 'Salvar canal';
          if (ok) {
            this.log('Vendas', `Canal salvo com sucesso no storage: ${LiveInfinitySalesAlert.channel}`);
          }
        }
      });
    }

    const toggleNtfyCell = shadow.getElementById('li-nv-celular-toggle');
    if (toggleNtfyCell) {
      toggleNtfyCell.addEventListener('change', async () => {
        if (window.LiveInfinitySalesAlert) {
          await LiveInfinitySalesAlert.toggleActive(toggleNtfyCell.checked);
          this.log('Vendas', `Notificação no celular: ${toggleNtfyCell.checked ? 'ATIVADA' : 'DESATIVADA'}`);
        }
      });
    }

    const btnGenChannel = shadow.getElementById('li-btn-gen-ntfy-channel');
    if (btnGenChannel) {
      btnGenChannel.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        if (window.LiveInfinitySalesAlert) {
          const gen = LiveInfinitySalesAlert.generateSecureChannel();
          const input = shadow.getElementById('li-nv-canal');
          if (input) input.value = gen;
          LiveInfinitySalesAlert.draftChannel = gen;
          LiveInfinitySalesAlert.updateUI();
        }
      });
    }

    const btnTestNtfy = shadow.getElementById('li-nv-teste');
    if (btnTestNtfy) {
      btnTestNtfy.addEventListener('click', async (e) => {
        e.preventDefault(); e.stopPropagation();
        if (window.LiveInfinitySalesAlert) {
          await LiveInfinitySalesAlert.sendTestNotification();
        }
      });
    }

    const btnCopyNtfy = shadow.getElementById('li-btn-copy-ntfy');
    if (btnCopyNtfy) {
      btnCopyNtfy.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        if (window.LiveInfinitySalesAlert) {
          LiveInfinitySalesAlert.copySavedChannel();
        }
      });
    }

    const btnChangeNtfy = shadow.getElementById('li-btn-change-ntfy');
    if (btnChangeNtfy) {
      btnChangeNtfy.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        const input = shadow.getElementById('li-nv-canal');
        if (input) input.focus();
      });
    }

    // ===== LISTENERS DE VALIDAÇÃO E SALVAMENTO NA ABA CONVERSAS =====
    const btnSaveIntent = shadow.getElementById('li-ic-save-btn');
    if (btnSaveIntent) {
      btnSaveIntent.addEventListener('click', async (e) => {
        e.preventDefault(); e.stopPropagation();
        const input = shadow.getElementById('li-ic-cart');
        const statusEl = shadow.getElementById('li-ic-status');
        const val = input ? input.value.trim() : '';

        if (!val) {
          if (statusEl) statusEl.textContent = 'Digite uma mensagem antes de salvar.';
          return;
        }

        if (window.LiveInfinityStateStore) {
          await LiveInfinityStateStore.setCustomSetting('buyerIntentPhrase', val);
        }
        if (statusEl) statusEl.textContent = 'Mensagem salva com sucesso!';
      });
    }

    const btnSaveThanks = shadow.getElementById('li-vc-save-btn');
    if (btnSaveThanks) {
      btnSaveThanks.addEventListener('click', async (e) => {
        e.preventDefault(); e.stopPropagation();
        const input = shadow.getElementById('li-vc-msg');
        const statusEl = shadow.getElementById('li-vc-status');
        const val = input ? input.value.trim() : '';

        if (!val) {
          if (statusEl) statusEl.textContent = 'Digite uma mensagem antes de salvar.';
          return;
        }

        if (window.LiveInfinityStateStore) {
          await LiveInfinityStateStore.setCustomSetting('purchaseThanksPhrase', val);
        }
        if (statusEl) statusEl.textContent = 'Mensagem salva com sucesso!';
      });
    }

    const btnSaveReplies = shadow.getElementById('li-ra-save-btn');
    if (btnSaveReplies) {
      btnSaveReplies.addEventListener('click', async (e) => {
        e.preventDefault(); e.stopPropagation();
        const area = shadow.getElementById('li-ra-regras');
        const statusEl = shadow.getElementById('li-ra-status');
        const val = area ? area.value.trim() : '';
        const rules = window.LiveInfinityChat ? LiveInfinityChat.getRules() : [];

        if (!val || rules.length === 0) {
          if (statusEl) statusEl.textContent = 'Cadastre pelo menos uma regra antes de salvar.';
          return;
        }

        if (window.LiveInfinityStateStore) {
          await LiveInfinityStateStore.setCustomSetting('autoReplyRules', val);
        }
        if (statusEl) statusEl.textContent = 'Regras salvas com sucesso!';
      });
    }
  },

  migrateLegacyConversasTexts() {
    const shadow = this.shadowRoot;
    if (!shadow) return;

    const inputCart = shadow.getElementById('li-ic-cart');
    const inputThanks = shadow.getElementById('li-vc-msg');
    const areaRules = shadow.getElementById('li-ra-regras');

    const legacyCartTexts = ['garante o seu, finaliza a compra! 🛒'];
    const legacyThanksTexts = ['Parabéns pela sua compra! 🎉 Obrigado, volte sempre!'];
    const legacyRulesTexts = [
      'frete = O frete é grátis! 🚚\ncomprei, finalizei = Parabéns pela compra! 🎉 Obrigado!',
      'frete = O frete é grátis! 🚚',
      'comprei, finalizei = Parabéns pela compra! 🎉 Obrigado!'
    ];

    if (inputCart && legacyCartTexts.includes((inputCart.value || '').trim())) {
      inputCart.value = '';
    }

    if (inputThanks && legacyThanksTexts.includes((inputThanks.value || '').trim())) {
      inputThanks.value = '';
    }

    if (areaRules && legacyRulesTexts.includes((areaRules.value || '').trim())) {
      areaRules.value = '';
    }
  },

  syncConversationToggles() {
    const shadow = this.shadowRoot;
    if (!shadow) return;

    this.migrateLegacyConversasTexts();

    const tComments = shadow.getElementById('li-box-toggle-comments');
    const tReplies = shadow.getElementById('li-box-toggle-replies');
    const tIntent = shadow.getElementById('li-box-toggle-intent');
    const tThanks = shadow.getElementById('li-box-toggle-thanks');

    if (tComments && window.LiveInfinityChat) tComments.checked = LiveInfinityChat.commentActive;
    if (tReplies && window.LiveInfinityChat) tReplies.checked = LiveInfinityChat.replyActive;
    if (tIntent && window.LiveInfinityBuyerIntent) tIntent.checked = LiveInfinityBuyerIntent.active;
    if (tThanks && window.LiveInfinityPurchaseThanks) tThanks.checked = LiveInfinityPurchaseThanks.active;
  },

  log(tag, msg) {
    console.log(`[Live Infinity Log] [${tag}] ${msg}`);
    const timestamp = new Date().toTimeString().slice(0, 8);
    const line = `[${timestamp}] [${tag}] ${msg}`;
    this.eventLogs.push(line);
    if (this.eventLogs.length > 300) this.eventLogs.shift();

    const shadow = this.shadowRoot;
    if (shadow) {
      const box = shadow.getElementById('li-log-box');
      if (box) {
        box.textContent = this.eventLogs.join('\n');
        box.scrollTop = box.scrollHeight;
      }
      
      const feed = shadow.getElementById('li-timeline-feed');
      if (feed) {
        const item = document.createElement('div');
        item.className = 'li-timeline-item';
        item.innerHTML = `<div class="li-timeline-icon">⚡</div><div><b>[${tag}]</b> ${msg}</div>`;
        feed.insertBefore(item, feed.firstChild);
        if (feed.children.length > 15) feed.removeChild(feed.lastChild);
      }
    }
  },

  updateActiveCount(activeCount = 0) {
    const shadow = this.shadowRoot;
    if (!shadow) return;

    const countEl = shadow.getElementById('li-active-ring');
    const countText = shadow.getElementById('li-active-count-text');

    if (countEl) {
      countEl.textContent = String(activeCount);
      countEl.style.borderColor = activeCount > 0 ? '#D4AF37' : '#780B10';
      countEl.style.color = activeCount > 0 ? '#F4D675' : '#FF2834';
    }

    if (countText) {
      if (activeCount === 0) {
        countText.textContent = 'Nenhuma automação rodando';
      } else if (activeCount === 1) {
        countText.textContent = '1 automação em execução';
      } else {
        countText.textContent = `${activeCount} automações em execução`;
      }
    }

    if (window.LiveSessionStore && typeof window.LiveSessionStore.updateHeaderAndFooterUI === 'function') {
      try {
        LiveSessionStore.updateHeaderAndFooterUI();
      } catch (e) {}
    }
  },

  loadPersistedSettings() {
    try {
      const hubPos = JSON.parse(localStorage.getItem(LIVE_INFINITY_CONFIG.STORAGE_KEYS.HUB_POS));
      if (hubPos && this.shadowRoot) {
        const hub = this.shadowRoot.getElementById('li-hub');
        if (hub) {
          hub.style.top = `${hubPos.t}px`;
          hub.style.left = `${hubPos.l}px`;
          hub.style.right = 'auto';
        }
      }

      const miniPos = JSON.parse(localStorage.getItem(LIVE_INFINITY_CONFIG.STORAGE_KEYS.BUBBLE_POS));
      if (miniPos && this.shadowRoot) {
        const mini = this.shadowRoot.getElementById('li-mini-panel');
        if (mini) {
          mini.style.top = `${miniPos.t}px`;
          mini.style.left = `${miniPos.l}px`;
          mini.style.right = 'auto';
        }
      }
    } catch (e) {}
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityUI = LiveInfinityUI;
}
