'use strict';

/* ===== Live Infinity — Automação de Agradecimento pela Compra (Com Resolução Assíncrona & Identificação do Comprador) ===== */
const LIVE_INFINITY_PURCHASE_STORAGE_KEY = 'live_infinity_processed_purchases';

const LiveInfinityPurchaseThanks = {
  active: false,
  timer: null,
  processedKeys: new Set(),
  isScanning: false,
  resolutionQueue: [],
  isResolvingQueue: false,

  async start(isRestoration = false) {
    this.active = true;
    this.loadPersistedKeys();

    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('purchaseThanks', true);
    }

    this.markExistingEventsAsSeen();

    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => this.scan(), LIVE_INFINITY_CONFIG.DEFAULTS.SCAN_INTERVAL_MS);
    this.updateUI('Ativo — aguardando compra concluída');
    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Agradec.', `Automação ${isRestoration ? 'restaurada' : 'iniciada'}`);
    }
  },

  loadPersistedKeys() {
    try {
      const raw = localStorage.getItem(LIVE_INFINITY_PURCHASE_STORAGE_KEY);
      if (raw) {
        const arr = JSON.parse(raw);
        if (Array.isArray(arr)) {
          arr.forEach(k => this.processedKeys.add(k));
        }
      }
    } catch (e) {}
  },

  savePersistedKeys() {
    try {
      const arr = Array.from(this.processedKeys).slice(-300);
      localStorage.setItem(LIVE_INFINITY_PURCHASE_STORAGE_KEY, JSON.stringify(arr));
    } catch (e) {}
  },

  async stop() {
    this.active = false;
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('purchaseThanks', false);
    }
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.updateUI('Desligado.');
    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Agradec.', 'Automação parada');
    }
  },

  restore() {
    this.start(true);
  },

  toggle() {
    if (this.active) this.stop();
    else this.start();
  },

  updateUI(msg) {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;
    const el = shadow.getElementById('li-vc-status');
    const toggle = shadow.getElementById('li-box-toggle-thanks');
    if (el) el.textContent = msg;
    if (toggle) toggle.checked = this.active;
  },

  markExistingEventsAsSeen() {
    if (!window.LiveInfinityFeedMonitor) return;
    const events = LiveInfinityFeedMonitor.findPurchaseEvents();
    events.forEach(ev => {
      try { ev.row.dataset.liPurchaseSeen = '1'; } catch (e) {}
    });
  },

  getCustomPhrase() {
    const shadow = window.__liveInfinityShadow;
    const area = shadow ? shadow.getElementById('li-vc-msg') : null;
    let phrase = area ? (area.value || '').trim() : '';
    if (!phrase) phrase = '🎉 Parabéns pela sua compra! Volte aqui para dar o seu feedback quando o produto chegar!';
    return phrase;
  },

  // RESOLUÇÃO ASSÍNCRONA DO COMPRADOR COM ATÉ 5 TENTATIVAS CONTROLADAS (300-800ms)
  async resolvePurchaseBuyer(purchaseEvent) {
    if (!purchaseEvent || !purchaseEvent.row) return purchaseEvent;

    const eventId = purchaseEvent.eventId;
    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Agradec.', `[Purchase] Venda detectada: ${eventId}`);
    }

    let attempts = 0;
    const maxAttempts = 5;

    while (attempts < maxAttempts) {
      attempts++;
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Agradec.', `[Purchase] Tentativa ${attempts}/${maxAttempts}: Procurando comprador no nó do evento...`);
      }

      const verification = await LiveInfinityFeedMonitor.extractVerifiedUsername(purchaseEvent.row, true);

      if (verification && verification.ok && verification.confidence === 'VERIFIED' && verification.username) {
        purchaseEvent.buyerName = verification.username.replace(/^@/, '').trim();
        purchaseEvent.identityConfidence = 'verified';
        purchaseEvent.source = verification.source;

        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Agradec.', `[Purchase] Comprador extraído: ${purchaseEvent.buyerName}`);
          LiveInfinityCore.log('Agradec.', `[Purchase] Confiança da identidade: verified (Origem: ${verification.source})`);
        }
        return purchaseEvent;
      }

      const delayMs = 300 + (attempts * 80);
      await new Promise(r => setTimeout(r, delayMs));
    }

    purchaseEvent.identityConfidence = 'unverified';
    if (window.LiveInfinityCore) {
      LiveInfinityCore.log('Agradec.', `[Purchase] Confiança da identidade: unverified`);
      LiveInfinityCore.log('Agradec.', `[Purchase] Agradecimento genérico: comprador não identificado com segurança.`);
    }

    return purchaseEvent;
  },

  async scan() {
    if (!this.active || this.isScanning || !window.LiveInfinityFeedMonitor) return;
    this.isScanning = true;

    try {
      const events = LiveInfinityFeedMonitor.findPurchaseEvents();
      const newEvents = events.filter(ev => {
        const d = ev.row.dataset || {};
        return !d.liPurchaseSeen && !d.liPurchaseQueued;
      });

      for (const ev of newEvents) {
        if (!this.active) break;

        const eventId = 'purch_evt_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4);
        try { ev.row.dataset.liPurchaseQueued = '1'; } catch (e) {}

        const parsedData = LiveInfinityFeedMonitor.parseSalesEventData(ev.row, ev.text);

        const purchaseEvent = {
          type: 'PURCHASE_COMPLETED',
          eventId: eventId,
          row: ev.row,
          rowText: ev.text || (ev.row ? ev.row.textContent : ''),
          buyerName: null,
          productName: parsedData.productName,
          quantity: parsedData.quantity,
          unitPrice: parsedData.unitPrice,
          totalAmount: parsedData.totalAmount,
          amountSource: parsedData.amountSource,
          detectedAt: Date.now(),
          source: 'tiktok',
          identityConfidence: 'unverified'
        };

        this.resolutionQueue.push(purchaseEvent);
      }

      if (!this.isResolvingQueue && this.resolutionQueue.length > 0) {
        this.processResolutionQueue();
      }
    } catch (err) {
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Agradec.', 'Erro no scanner de compra: ' + (err.message || err));
      }
    } finally {
      this.isScanning = false;
    }
  },

  async processResolutionQueue() {
    if (this.isResolvingQueue || !this.resolutionQueue.length) return;
    this.isResolvingQueue = true;

    try {
      while (this.resolutionQueue.length > 0) {
        if (!this.active) break;
        const purchaseEvent = this.resolutionQueue.shift();
        if (!purchaseEvent) continue;

        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Agradec.', `[Purchase] Evento detectado: compra em ${new Date().toLocaleTimeString()}`);
        }

        const resolvedEvent = await this.resolvePurchaseBuyer(purchaseEvent);
        const buyerName = resolvedEvent.buyerName;
        const isVerified = resolvedEvent.identityConfidence === 'verified';
        const key = `purch:${buyerName || 'anon'}:${resolvedEvent.eventId}`;

        if (window.LiveInfinityCore) {
          LiveInfinityCore.log('Agradec.', `[Purchase] Comprador extraído: ${isVerified && buyerName ? '@' + buyerName : 'não identificado'}`);
        }

        if (this.processedKeys.has(key)) {
          if (window.LiveInfinityCore) {
            LiveInfinityCore.log('Agradec.', `[Sales] Evento de compra duplicado ignorado: ${key}`);
          }
          continue;
        }
        this.processedKeys.add(key);
        this.savePersistedKeys();

        const customPhrase = this.getCustomPhrase();

        if (isVerified && buyerName) {
          if (window.LiveInfinityChat && typeof window.LiveInfinityChat.sendChatMessageWithMention === 'function') {
            window.LiveInfinityChat.sendChatMessageWithMention({
              message: customPhrase,
              mentionName: buyerName,
              sourceEventId: key
            });
          } else if (window.LiveInfinityChat) {
            const mentionTag = `@${buyerName}`;
            let finalMsg = '';
            if (customPhrase.indexOf('{usuario}') > -1) {
              finalMsg = customPhrase.replace(/\{usuario\}/g, mentionTag);
            } else if (!customPhrase.startsWith(mentionTag)) {
              finalMsg = `${mentionTag} ${customPhrase.trim()}`;
            } else {
              finalMsg = customPhrase.trim();
            }
            if (finalMsg.length > 100) finalMsg = finalMsg.slice(0, 97) + '...';
            window.LiveInfinityChat.enqueueMessage(finalMsg, 1, `Agradecimento: ${mentionTag}`, key, buyerName);
          }

          if (window.LiveInfinityCore) {
            LiveInfinityCore.log('Agradec.', `[Purchase] Evento colocado na fila: agradecimento para @${buyerName}`);
          }

          this.updateUI(`Agradecimento enviado para @${buyerName} ✅ ` + new Date().toLocaleTimeString().slice(0, 5));
        } else {
          // COMPRADOR NÃO IDENTIFICADO COM SEGURANÇA -> ENVIAR MENSAGEM GENÉRICA UMA ÚNICA VEZ
          if (customPhrase.indexOf('{usuario}') === -1) {
            const cleanPhrase = customPhrase.replace(/@\{usuario\}/g, '').replace(/\{usuario\}/g, '').trim();
            if (window.LiveInfinityChat && cleanPhrase) {
              window.LiveInfinityChat.enqueueMessage(cleanPhrase, 1, 'Agradecimento Genérico', key);
            }
          }

          this.updateUI('COMPRA CONFIRMADA — Agradecimento genérico sem menção');
        }

        resolvedEvent.eventId = key;

        // Registrar venda no Dashboard e Alertas (áudio caixa registradora + ntfy.sh) com o evento central completo
        if (window.LiveInfinityDashboard) {
          LiveInfinityDashboard.registerSaleEvent(resolvedEvent);
        }
        if (window.LiveInfinitySalesAlert) {
          LiveInfinitySalesAlert.onSaleDetected(resolvedEvent);
        }
      }
    } catch (e) {
      if (window.LiveInfinityCore) {
        LiveInfinityCore.log('Agradec.', 'Erro na fila de resolução de compras: ' + (e.message || e));
      }
    } finally {
      this.isResolvingQueue = false;
    }
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityPurchaseThanks = LiveInfinityPurchaseThanks;
}
