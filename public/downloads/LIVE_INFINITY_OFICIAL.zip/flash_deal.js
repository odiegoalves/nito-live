'use strict';

/* ===== Live Infinity — Automação de Oferta Relâmpago ===== */
const LiveInfinityFlashDeal = {
  active: false,
  timer: null,

  async start(isRestoration = false) {
    this.active = true;
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('flashDeal', true);
    }

    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => this.scan(), 5000);
    this.updateStatus('Ativo — monitorando Oferta Relâmpago...');
    LiveInfinityCore.log('Oferta', `Automação ${isRestoration ? 'restaurada' : 'iniciada'}`);
  },

  async stop() {
    this.active = false;
    if (window.LiveInfinityStateStore) {
      await LiveInfinityStateStore.setDesiredState('flashDeal', false);
    }
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.updateStatus('Desligado.');
    LiveInfinityCore.log('Oferta', 'Automação parada');
  },

  restore() {
    this.start(true);
  },

  toggle() {
    if (this.active) this.stop();
    else this.start();
  },

  updateStatus(msg) {
    const shadow = window.__liveInfinityShadow;
    if (!shadow) return;
    const el = shadow.getElementById('li-rd-status');
    const btn = shadow.getElementById('li-rd-botao');
    if (el) el.textContent = msg;
    if (btn) {
      if (this.active) {
        btn.textContent = '⏸ Parar Oferta Relâmpago';
        btn.classList.add('li-btn-stop');
      } else {
        btn.textContent = '▶ Iniciar Oferta Relâmpago';
        btn.classList.remove('li-btn-stop');
      }
    }
  },

  scan() {
    if (!this.active) return;
    // Scanner de Oferta Relâmpago
  }
};

if (typeof window !== 'undefined') {
  window.LiveInfinityFlashDeal = LiveInfinityFlashDeal;
}
