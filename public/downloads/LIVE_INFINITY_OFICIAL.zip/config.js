'use strict';

/* ===== Live Infinity — Configurações & Constantes Globais ===== */
const LIVE_INFINITY_CONFIG = {
  APP_NAME: 'Live Infinity',
  VERSION: '1.0.0',
  
  // URL Oficial do Painel, Endpoint de Validação da API, Site de Renovação e Recuperação de Chave
  PANEL_URL: 'https://admin.valoranegocios.com.br/painel-seguro-liveinfinity/',
  API_VALIDATE_ENDPOINT: 'https://admin.valoranegocios.com.br/painel-seguro-liveinfinity/api/check',
  RENEWAL_URL: 'https://liveinfinitysite.vercel.app/',
  RECOVERY_URL: 'https://api.valoranegocios.com.br/ativar-liveinfinity',
  
  // Target URL do TikTok Shop Live Manager
  TIKTOK_SHOP_TARGET: 'https://shop.tiktok.com/streamer/live/product/dashboard',
  
  // Chaves de armazenamento congeladas no navegador (chrome.storage.local / localStorage)
  STORAGE_KEYS: Object.freeze({
    LICENSE: 'live_infinity_lic',
    PRESETS: 'live_infinity_presets',
    PRESETS_DATA: 'live_infinity_presets_data',
    ACTIVE_PRESET: 'live_infinity_active_preset',
    PRODUCTS_DATA: 'live_infinity_product_library',
    SALES_ALERT_CFG: 'liveInfinityNtfy',
    AUTOMATIONS_STATE: 'live_infinity_automations_state',
    SETTINGS: 'live_infinity_settings',
    LOGS: 'live_infinity_logs',
    HUB_POS: 'live_infinity_hub_pos',
    BUBBLE_POS: 'live_infinity_bubble_pos',
    TIMER_STATE: 'live_infinity_timer_state'
  }),
  
  // Intervalos padrão
  DEFAULTS: {
    REPIN_INTERVAL_SEC: 40,
    COMMENT_INTERVAL_SEC: 90,
    VIOLATION_DELAY_SEC: 0,
    CHAT_QUEUE_DELAY_MS: 4500,
    SCAN_INTERVAL_MS: 2000,
    LICENSE_CHECK_INTERVAL_MS: 15 * 60 * 1000 // Re-valida licença a cada 15 minutos automaticamente
  },
  
  // Paleta Oficial Red & Gold
  COLORS: {
    BG_MAIN: '#090909',
    BG_SEC: '#12100F',
    CARD_BG: '#191513',
    CARD_ELEVATED: '#211A16',
    RED_MAIN: '#D71920',
    RED_VIVID: '#FF2834',
    RED_DARK: '#780B10',
    GOLD_MAIN: '#D4AF37',
    GOLD_LIGHT: '#F4D675',
    GOLD_DARK: '#8E6918',
    TEXT_MAIN: '#FFF8E7',
    TEXT_MUTED: '#C8BCA5',
    BORDER_GOLD: 'rgba(212, 175, 55, 0.25)'
  }
};

if (typeof window !== 'undefined') {
  window.LIVE_INFINITY_CONFIG = LIVE_INFINITY_CONFIG;
}
