const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const extDir = path.resolve(__dirname, '..');
const baselineFile = path.join(extDir, 'FUNCTIONAL_BASELINE_SHA256.txt');

if (!fs.existsSync(baselineFile)) {
  console.error('❌ ARQUIVO DE BASELINE FUNCTIONAL_BASELINE_SHA256.TXT NÃO ENCONTRADO!');
  process.exit(1);
}

const lines = fs.readFileSync(baselineFile, 'utf8').split('\n').map(l => l.trim()).filter(Boolean);

let modifiedCount = 0;
let missingCount = 0;
let intactCount = 0;

console.log('🔍 VERIFICANDO INTEGRIDADE DA BASELINE FUNCIONAL DA LIVE INFINITY...\n');

lines.forEach(line => {
  const parts = line.split(/\s+/);
  if (parts.length < 2) return;
  const expectedHash = parts[0];
  const relPath = parts[1];

  const fullPath = path.join(extDir, relPath);
  if (!fs.existsSync(fullPath)) {
    console.error(`❌ AUSENTE: ${relPath}`);
    missingCount++;
    return;
  }

  const buf = fs.readFileSync(fullPath);
  const currentHash = crypto.createHash('sha256').update(buf).digest('hex');

  if (currentHash === expectedHash) {
    console.log(`✅ PRESERVADO: ${relPath}`);
    intactCount++;
  } else {
    console.error(`🚨 MODIFICADO: ${relPath}`);
    console.error(`   Esperado: ${expectedHash}`);
    console.error(`   Atual:    ${currentHash}`);
    modifiedCount++;
  }
});

console.log('\n------------------------------------------------------------');
if (modifiedCount === 0 && missingCount === 0) {
  console.log('FUNCTIONAL BASELINE: INTACT ✅');
  process.exit(0);
} else {
  console.error('FUNCTIONAL BASELINE: MODIFIED 🚨');
  console.error(`Modificados: ${modifiedCount} | Ausentes: ${missingCount} | Preservados: ${intactCount}`);
  process.exit(1);
}
